# Databricks notebook source
# MAGIC %md
# MAGIC # Week 21: Apache Airflow Fundamentals on MWAA - Authoring and Orchestrating the Fraud Classifier Pipeline
# MAGIC
# MAGIC ## Where we are
# MAGIC
# MAGIC You shipped the fraud classifier in Week 19. You wired up monitoring in Week 20. Last Tuesday the 3am pager went off because a manual notebook run failed. Today you replace those manual notebooks with Airflow DAGs that YOU author in a Databricks cell, upload to MWAA, and trigger from boto3. Every DAG you write today calls the same `fraud-classifier-endpoint` that is already serving traffic in SageMaker.
# MAGIC
# MAGIC ## Learning objectives
# MAGIC
# MAGIC By the end of this 2-hour session you will be able to:
# MAGIC
# MAGIC 1. AUTHOR a DAG as a Python string in your Databricks notebook, UPLOAD it to the MWAA DAGs bucket via `s3.put_object`, POLL MWAA via `mwaa.invoke_rest_api` until the DAG is registered, then TRIGGER it and read its task logs in the Airflow UI.
# MAGIC 2. Wire a multi-step PythonOperator chain that exercises the live `fraud-classifier-endpoint`: read transactions, score them, write predictions, all using XCom to pass S3 URIs (never DataFrames) between tasks.
# MAGIC 3. Use `BranchPythonOperator` to route a fraud-scoring DAG to either an alert path or a normal-logging path based on the observed fraud rate, and use the right join-task trigger rule (`none_failed_min_one_success`) so the join does not get silently skipped.
# MAGIC 4. Use `ShortCircuitOperator` with `ignore_downstream_trigger_rules=False` to gate a model-approval step on a CloudWatch accuracy metric, AND guarantee a cleanup task with `trigger_rule="all_done"` still runs on a no-go.
# MAGIC 5. Wire `on_failure_callback=send_sns_notification(...)` and a fan-in notification task so a failure anywhere in a parallel-scored DAG pages a human via SNS.
# MAGIC 6. Recognize when to swap the raw `boto3 sm_runtime.invoke_endpoint` PythonOperator pattern for the bundled `SageMakerTransformOperator` from `apache-airflow-providers-amazon==9.0.0`, and explain why one is the right teaching tool and the other is the right production tool.
# MAGIC
# MAGIC ## Important: every DAG today is YOURS
# MAGIC
# MAGIC Every DAG you trigger today, you also AUTHOR and UPLOAD in this notebook. The only pre-deployed DAG is the smoke DAG you will use as a sanity check. This is the foundation week; Week 22 closes the drift -> retrain -> redeploy loop on top of the DAG-authoring muscle you build today.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Mental model: Databricks authors, MWAA executes
# MAGIC
# MAGIC You are NOT running an Airflow scheduler in this notebook. You never `pip install apache-airflow`. The notebook is the AUTHOR + REMOTE-CONTROL surface; MWAA is the execution surface.
# MAGIC
# MAGIC ```
# MAGIC +-------------------+        +---------------------+        +-----------------+
# MAGIC |   Databricks      |  put   |   S3 DAGs bucket    |  sync  |     MWAA        |
# MAGIC |   (this notebook) | -----> | bread-academy-      | -----> | scheduler +     |
# MAGIC |                   | object | airflow-dags/dags/  | every  | parser +        |
# MAGIC |   - write DAG as  |        | participant-NN/labN.py  |  30s   | workers         |
# MAGIC |     Python string |        +---------------------+        +-----------------+
# MAGIC |   - upload via    |                                              |
# MAGIC |     s3.put_object |                                              | each task calls
# MAGIC |   - trigger via   |   invoke_rest_api    +----------------+      v
# MAGIC |     mwaa.invoke_  | -------------------> | Airflow REST   |   +-----------------+
# MAGIC |     rest_api      |   POST /dagRuns      | API on MWAA    |-->| SageMaker       |
# MAGIC |   - poll for      |                      +----------------+   | fraud-classif-  |
# MAGIC |     status        |                                           | ier-endpoint    |
# MAGIC +-------------------+                                           +-----------------+
# MAGIC                                                                        |
# MAGIC                                                               writes predictions
# MAGIC                                                                        v
# MAGIC                                                               +-----------------+
# MAGIC                                                               | s3://bread-     |
# MAGIC                                                               | academy-shared/ |
# MAGIC                                                               +-----------------+
# MAGIC ```
# MAGIC
# MAGIC The contract:
# MAGIC
# MAGIC - **DAGs live ONLY in MWAA.** The Databricks notebook never imports `airflow`. The DAG source is a Python string until it lands in S3.
# MAGIC - **MWAA syncs the DAGs S3 prefix every 30 seconds**, then the scheduler needs one more parse cycle. Expect 30 to 60 seconds total before a brand-new DAG appears in the API. The poll helper handles that wait.
# MAGIC - **Per-student `dag_id`** of `week21_lab{N}_{STUDENT_ID}` is mandatory. Two students using the same `dag_id` would silently overwrite each other in the scheduler's mind every 30 seconds. There would be no error - the tree view would just oscillate.
# MAGIC - **XCom passes S3 URIs, not data.** XCom values live in the Airflow metadata DB. Push small things (URIs, summary numbers). Use S3 as the data plane.
# MAGIC
# MAGIC ## The four-step authoring pattern you will use five times today
# MAGIC
# MAGIC ```
# MAGIC 1. dag_code = f'''<DAG source as a Python string with STUDENT_ID baked in>'''
# MAGIC 2. s3.put_object(Bucket=DAGS_BUCKET, Key=f"{DAG_PREFIX}/labN.py", Body=dag_code.encode())
# MAGIC 3. poll_until_registered(f"week21_labN_{STUDENT_ID}")   # GET /dags/{id} until 200
# MAGIC 4. trigger_dag(f"week21_labN_{STUDENT_ID}", conf={...}) # POST /dags/{id}/dagRuns
# MAGIC ```
# MAGIC
# MAGIC Every lab is a variation on this pattern with one new Airflow concept layered on top.
# MAGIC

# COMMAND ----------

# Standard Week 21 setup on Databricks: install the small client surface,
# pull secrets, build boto3 clients. SAME shape as Weeks 19 and 20 so the
# muscle memory carries over. We deliberately do NOT install apache-airflow
# or the Amazon provider here - those run on MWAA, not on Databricks.

%pip install \
    "numpy<2" "pandas<2" \
    "boto3>=1.36" \
    "sagemaker>=2.230,<3" \
    "mlflow-skinny>=2.13,<3" \
    "requests>=2.31"

dbutils.library.restartPython()


# COMMAND ----------

# Pull per-student AWS keys from the secret scope and build boto3 clients.
# Same secret-scope shape as Weeks 19-20: per-student credentials live in
# aws-course-creds-NN, class-wide config in aws-course-shared. No getpass,
# no sagemaker.Session(), no get_execution_role().

import os
import json
import time
import boto3

# Derive identity from the Databricks user. student-NN@... -> that student;
# anyone else (instructor-axel@..., your own login) -> the INSTRUCTOR identity,
# which uses its own creds scope, S3 folder, registry group, and dag_id suffix
# so instructor demo runs never collide with student-01.
_user = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook().getContext().userName().get()
)
# BREAD_SMOKE_STUDENT_ID forces a specific student number (used by the smoke
# runner). Empty in real runs.
_forced = os.environ.get("BREAD_SMOKE_STUDENT_ID")
IS_INSTRUCTOR = (not _forced) and (not _user.startswith("student-"))

if IS_INSTRUCTOR:
    _num         = "01"                       # instructor uses the cohort-1 endpoint
    USER_SLUG    = "instructor"
    creds_scope  = "aws-course-creds-instructor"
    PACKAGE_GROUP = "fraud-classifier-week19-instructor"
    _folder      = "instructor"
else:
    _num         = _forced or _user.split("@")[0].split("-")[1]
    USER_SLUG    = f"participant_{_num}"
    creds_scope  = f"aws-course-creds-{_num}"
    PACKAGE_GROUP = f"fraud-classifier-week19-student-{int(_num):02d}"
    _folder      = f"participant-{_num}"

AWS_ACCESS_KEY_ID     = dbutils.secrets.get(scope=creds_scope, key="aws-access-key-id")
AWS_SECRET_ACCESS_KEY = dbutils.secrets.get(scope=creds_scope, key="aws-secret-access-key")
AWS_REGION            = dbutils.secrets.get(scope="aws-course-shared", key="aws-region")

os.environ["AWS_ACCESS_KEY_ID"] = AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = AWS_SECRET_ACCESS_KEY
os.environ["AWS_REGION"] = AWS_REGION
os.environ["AWS_DEFAULT_REGION"] = AWS_REGION

# Clients we will use across the notebook.
mwaa             = boto3.client("mwaa", region_name=AWS_REGION)
s3               = boto3.client("s3", region_name=AWS_REGION)
sm_runtime       = boto3.client("sagemaker-runtime", region_name=AWS_REGION)
sagemaker_client = boto3.client("sagemaker", region_name=AWS_REGION)
cloudwatch       = boto3.client("cloudwatch", region_name=AWS_REGION)
sns              = boto3.client("sns", region_name=AWS_REGION)

# Constants. USER_SLUG / PACKAGE_GROUP / _folder were set above per identity.
MWAA_ENV       = "bread-academy-airflow"
# 3 cohorts of 20: students 1-20 -> cohort 1, 21-40 -> 2, 41-60 -> 3. Each
# cohort has its OWN endpoint fraud-classifier-endpoint-cohort-{1,2,3}.
# (The instructor identity maps to cohort 1.)
cohort = (int(_num) - 1) // 20 + 1
ENDPOINT_NAME_BASE = dbutils.secrets.get(scope="aws-course-shared", key="endpoint-name-base")
ENDPOINT_NAME  = f"{ENDPOINT_NAME_BASE}-{cohort}"
SHARED_BUCKET  = "bread-academy-shared"
DAGS_BUCKET    = "bread-academy-airflow-dags"

STUDENT_ID     = _num                       # number used inside baked DAGs / S3 keys
STUDENT_PREFIX = f"week21/{_folder}"        # participant-NN or instructor
DAG_PREFIX     = f"dags/{_folder}"

# SNS topic for Labs 2 and 4.
SNS_TOPIC_ARN  = dbutils.secrets.get(scope="aws-course-shared", key="sns-alerts-topic-arn")

print(f"Setup ok: identity={USER_SLUG}, cohort={cohort}, region={AWS_REGION}")
print(f"DAG upload prefix: s3://{DAGS_BUCKET}/{DAG_PREFIX}/")


# COMMAND ----------

# Pre-flight probes - fail loud now if anything we depend on is missing.
# Each probe is one tiny call; the error message tells you who to ask for help.

# (a) MWAA environment is AVAILABLE.
try:
    env = mwaa.get_environment(Name=MWAA_ENV)["Environment"]
    assert env["Status"] == "AVAILABLE", f"MWAA env status is {env['Status']}"
    print(f"MWAA env: AVAILABLE (Airflow {env.get('AirflowVersion')})")
except Exception as e:
    print(f"Ask your instructor to check MWAA environment {MWAA_ENV}.")
    raise

# (b) SageMaker fraud-classifier endpoint is InService.
try:
    resp = sagemaker_client.describe_endpoint(EndpointName=ENDPOINT_NAME)
    assert resp["EndpointStatus"] == "InService", (
        f"Endpoint {ENDPOINT_NAME} is {resp['EndpointStatus']}."
    )
    print(f"Endpoint {ENDPOINT_NAME}: InService")
except Exception as e:
    print(f"Ask your instructor to redeploy the Week 19 endpoint {ENDPOINT_NAME}.")
    raise

# (c) DAGs bucket exists and we can list our prefix.
try:
    s3.head_bucket(Bucket=DAGS_BUCKET)
    print(f"DAGs bucket {DAGS_BUCKET}: reachable")
except Exception as e:
    print(f"Ask your instructor to grant write access on s3://{DAGS_BUCKET}/{DAG_PREFIX}/.")
    raise

# (d) Model package group exists (Lab 3 needs it).
try:
    _pkgs = sagemaker_client.list_model_packages(
        ModelPackageGroupName=PACKAGE_GROUP, MaxResults=1
    )["ModelPackageSummaryList"]
    assert _pkgs, f"per-student group {PACKAGE_GROUP} has no packages"
    print(f"Model package group {PACKAGE_GROUP}: reachable, {len(_pkgs)}+ package(s)")
except Exception as e:
    print(f"Ask your instructor to verify the Week 19 model package group {PACKAGE_GROUP}.")
    raise

# (e) CloudWatch custom metric exists (Lab 3 reads it).
try:
    cloudwatch.list_metrics(Namespace="FraudClassifier", MetricName="Accuracy")
    print("CloudWatch metric FraudClassifier/Accuracy: reachable")
except Exception as e:
    print("Ask your instructor to verify the Week 20 CloudWatch metric.")
    raise

print()
print("Pre-flight checks passed. You are ready to author DAGs.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## The canonical authoring pattern
# MAGIC
# MAGIC Every lab today follows the same four steps. Learn them once; reuse five times.
# MAGIC
# MAGIC ### Step 1: write the DAG source as a Python string
# MAGIC
# MAGIC ```python
# MAGIC dag_code = f'''
# MAGIC from airflow import DAG
# MAGIC from airflow.operators.python import PythonOperator
# MAGIC from datetime import datetime
# MAGIC
# MAGIC STUDENT_ID = "{STUDENT_ID}"
# MAGIC
# MAGIC def hello(**context):
# MAGIC     print(f"hello from student {{STUDENT_ID}}")
# MAGIC
# MAGIC with DAG(
# MAGIC     dag_id=f"week21_lab1_{USER_SLUG}",
# MAGIC     start_date=datetime(2026, 1, 1),
# MAGIC     schedule=None,
# MAGIC     catchup=False,
# MAGIC ) as dag:
# MAGIC     PythonOperator(task_id="hello", python_callable=hello)
# MAGIC '''
# MAGIC ```
# MAGIC
# MAGIC The DAG source is an f-string at NOTEBOOK time. `{STUDENT_ID}` is interpolated in the notebook BEFORE upload, so by the time MWAA parses the file it sees a concrete dag_id like `week21_lab1_07`. Any literal `{` or `}` in the DAG source (Python dicts, Jinja templates like `{{ ts_nodash }}`) MUST be double-braced because the OUTER string is itself an f-string.
# MAGIC
# MAGIC ### Step 2: upload to S3 with `put_object`
# MAGIC
# MAGIC ```python
# MAGIC s3.put_object(
# MAGIC     Bucket=DAGS_BUCKET,
# MAGIC     Key=f"{DAG_PREFIX}/lab1.py",
# MAGIC     Body=dag_code.encode(),
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC Small file. No multipart. `put_object` is the right call.
# MAGIC
# MAGIC ### Step 3: poll until MWAA has registered the DAG
# MAGIC
# MAGIC ```python
# MAGIC poll_until_registered(f"week21_lab1_{USER_SLUG}")
# MAGIC ```
# MAGIC
# MAGIC MWAA syncs the S3 prefix every 30 seconds, then the scheduler needs one more parse cycle. Allow 30 to 60 seconds. The helper loops `GET /dags/{dag_id}` every 5 seconds, up to 20 iterations.
# MAGIC
# MAGIC ### Step 4: trigger via the Airflow REST API
# MAGIC
# MAGIC ```python
# MAGIC run_id = trigger_dag(f"week21_lab1_{USER_SLUG}", conf={"batch_size": 50})
# MAGIC wait_for_dag(f"week21_lab1_{USER_SLUG}", run_id)
# MAGIC ```
# MAGIC
# MAGIC Both calls go through `mwaa.invoke_rest_api`, which hits the same Airflow REST API you would use from a CI pipeline.
# MAGIC
# MAGIC ### The footgun every student hits at least once
# MAGIC
# MAGIC If `poll_until_registered` exits without seeing the DAG, your DAG probably has an IMPORT ERROR. Import errors do NOT bubble back to the boto3 call. They show up in the MWAA Airflow UI:
# MAGIC
# MAGIC > Browse -> DAG Import Errors
# MAGIC
# MAGIC Open that page first. The error text is usually a one-liner: a stray brace from f-string nesting, a typo, a missing comma.
# MAGIC

# COMMAND ----------

# The four helpers that implement the author-upload-poll-trigger pattern.
# Every lab today reuses these verbatim. Read them once now so the labs
# read as "build the dag_code string, call the four helpers".

import time

def _mwaa_rest(method, path, body=None, _tries=1):
    """Call mwaa.invoke_rest_api, tolerating transient errors.

    A brand-new DAG is not in the API for ~5 min after upload; GET /dags/{id}
    RAISES RestApiClientException (404) in that window rather than returning a
    non-200 status. We swallow that (and other transient REST/throttle errors)
    by returning {"RestApiStatusCode": 0, "RestApiResponse": {}} so the polling
    loops simply wait and retry. Fatal errors (AccessDenied, Validation) re-raise.
    """
    kw = {"Name": MWAA_ENV, "Method": method, "Path": path}
    if body is not None:
        kw["Body"] = body
    transient = (
        mwaa.exceptions.RestApiClientException,
        mwaa.exceptions.RestApiServerException,
        mwaa.exceptions.ResourceNotFoundException,
        mwaa.exceptions.InternalServerException,
        mwaa.exceptions.ServiceUnavailableException,
    )
    try:
        return mwaa.invoke_rest_api(**kw)
    except transient:
        return {"RestApiStatusCode": 0, "RestApiResponse": {}}
    # AccessDeniedException / ValidationException are NOT caught: they mean a
    # real permissions or request bug and should fail loud.



def upload_dag(student_id: str, lab_n: int, dag_code: str) -> str:
    """Write dag_code to s3://DAGS_BUCKET/dags/participant-NN/labN.py and return the key."""
    key = f"dags/student_{student_id}/lab{lab_n}.py"
    s3.put_object(Bucket=DAGS_BUCKET, Key=key, Body=dag_code.encode())
    print(f"Uploaded DAG to s3://{DAGS_BUCKET}/{key} ({len(dag_code)} bytes)")
    return key


def poll_until_registered(dag_id: str, max_iters: int = 40, sleep_s: int = 5) -> None:
    """Block until GET /dags/{dag_id} returns 200, or raise after max_iters * sleep_s seconds.

    MWAA syncs S3 every 30s + 1 parse cycle, so 100s is a safe budget. If we time
    out, the DAG most likely has an import error - check the Airflow UI's
    Browse -> DAG Import Errors panel.
    """
    for i in range(max_iters):
        resp = _mwaa_rest("GET", f"/dags/{dag_id}")
        status = resp["RestApiStatusCode"]
        if status == 200:
            print(f"DAG {dag_id} registered after ~{i * sleep_s}s")
            return
        time.sleep(sleep_s)
    raise RuntimeError(
        f"DAG {dag_id} not registered in {max_iters * sleep_s}s. "
        "Open the MWAA Airflow UI and check Browse -> DAG Import Errors."
    )


def unpause_dag(dag_id: str) -> None:
    """Unpause a DAG via PATCH /dags/{dag_id}. MWAA creates new DAGs PAUSED, so
    a trigger does nothing until the DAG is unpaused. Idempotent - safe to call
    every time."""
    for _attempt in range(6):
        resp = _mwaa_rest("PATCH", f"/dags/{dag_id}", {"is_paused": False})
        if resp["RestApiStatusCode"] == 200:
            print(f"Unpaused {dag_id}")
            return
        time.sleep(5)  # transient (e.g. not-yet-parsed); retry
    raise RuntimeError(f"unpause_dag failed for {dag_id}: {resp}")


def trigger_dag(dag_id: str, conf: dict | None = None) -> str:
    """POST /dags/{dag_id}/dagRuns with a unique dag_run_id; return the run id."""
    run_id = f"student-{STUDENT_ID}-{int(time.time())}"
    unpause_dag(dag_id)  # MWAA creates DAGs paused; unpause before triggering
    body = {"dag_run_id": run_id}
    if conf is not None:
        body["conf"] = conf
    resp = _mwaa_rest("POST", f"/dags/{dag_id}/dagRuns", body)
    if resp["RestApiStatusCode"] not in (200, 201):
        raise RuntimeError(f"trigger_dag failed: {resp}")
    print(f"Triggered {dag_id} run_id={run_id}")
    return run_id


def wait_for_dag(dag_id: str, run_id: str, cap_s: int = 900, sleep_s: int = 10) -> str:
    """Poll the run state every sleep_s until it is success or failed, or cap_s elapses."""
    waited = 0
    while waited < cap_s:
        resp = _mwaa_rest("GET", f"/dags/{dag_id}/dagRuns/{run_id}")
        state = resp["RestApiResponse"].get("state")
        if state in ("success", "failed"):
            print(f"Run {run_id} finished: {state} (after ~{waited}s)")
            return state
        time.sleep(sleep_s)
        waited += sleep_s
    raise RuntimeError(f"Run {run_id} did not finish in {cap_s}s; still running.")


print("Helpers defined: upload_dag, poll_until_registered, trigger_dag, wait_for_dag")


# COMMAND ----------

# Sanity check: trigger the instructor-deployed smoke DAG and wait for it.
# This is the ONLY DAG today that you did not author yourself - it lives at
# scripts/smoke/dags/week21_smoke_dag.py and is already deployed by your
# instructor. If this works, your four helpers are wired correctly and you
# are ready to start authoring.
#
# The smoke DAG contract: pass `input_s3_key` in dag_run.conf pointing at a
# CSV the DAG can read. The DAG counts rows + fraud-rate and writes a
# _SUCCESS marker back to S3. We synthesize a tiny CSV here so we exercise
# the full round-trip (S3 write -> MWAA reads -> S3 marker -> we read it).

import time

smoke_dag_id = "week21_smoke_dag"

# 1. Upload a tiny synthetic CSV so the DAG has something to read.
synthetic_csv = (
    "transaction_id,amount,is_fraud\n"
    "t1,12.50,0\n"
    "t2,5400.00,1\n"
    "t3,42.10,0\n"
    "t4,89.00,0\n"
)
input_s3_key = f"airflow-smoke/input/student-{STUDENT_ID}-{int(time.time())}.csv"
s3.put_object(
    Bucket=SHARED_BUCKET,
    Key=input_s3_key,
    Body=synthetic_csv.encode("utf-8"),
)
print(f"Uploaded synthetic CSV to s3://{SHARED_BUCKET}/{input_s3_key}")

# 2. Trigger the smoke DAG with the conf shape it expects.
# (No DAG upload, no DAG-discovery poll - the smoke DAG is already registered.)
smoke_run_id = trigger_dag(smoke_dag_id, conf={"input_s3_key": input_s3_key})
smoke_state  = wait_for_dag(smoke_dag_id, smoke_run_id, cap_s=300)

assert smoke_state == "success", f"Smoke DAG failed (state={smoke_state})"

# 3. The smoke DAG writes a marker to S3 - confirm we can read it back.
marker_key = f"airflow-smoke/markers/{smoke_run_id}/_SUCCESS"
try:
    s3.head_object(Bucket=SHARED_BUCKET, Key=marker_key)
    print(f"Smoke marker present: s3://{SHARED_BUCKET}/{marker_key}")
except Exception:
    print(f"Smoke marker NOT found at s3://{SHARED_BUCKET}/{marker_key}")
    print("Run succeeded but marker is missing - tell your instructor.")

print()
print("Helpers + MWAA + S3 round-trip all working. Time to author your own DAGs.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Topic 1: PythonOperator, `>>`, and the XCom S3-URI rule
# MAGIC
# MAGIC A DAG is a Python file at parse time and a graph of TaskInstances at run time. The minimum-viable shape:
# MAGIC
# MAGIC ```python
# MAGIC from airflow import DAG
# MAGIC from airflow.operators.python import PythonOperator
# MAGIC from datetime import datetime
# MAGIC
# MAGIC def step_one(**context):
# MAGIC     return "some small value"  # auto-pushed to XCom under key 'return_value'
# MAGIC
# MAGIC def step_two(**context):
# MAGIC     ti = context["ti"]
# MAGIC     upstream = ti.xcom_pull(task_ids="step_one")
# MAGIC     print(f"got: {upstream}")
# MAGIC
# MAGIC with DAG(
# MAGIC     dag_id="example",
# MAGIC     start_date=datetime(2026, 1, 1),
# MAGIC     schedule=None,
# MAGIC     catchup=False,
# MAGIC ) as dag:
# MAGIC     one = PythonOperator(task_id="step_one", python_callable=step_one)
# MAGIC     two = PythonOperator(task_id="step_two", python_callable=step_two)
# MAGIC     one >> two   # set dependency: step_two runs AFTER step_one
# MAGIC ```
# MAGIC
# MAGIC Two rules to internalize before Lab 1:
# MAGIC
# MAGIC ### Rule 1: PythonOperator callables receive `**context`
# MAGIC
# MAGIC ```python
# MAGIC def my_task(**context):
# MAGIC     conf      = context["dag_run"].conf      # dict you passed to trigger_dag
# MAGIC     ti        = context["ti"]                # TaskInstance, used for xcom_pull/push
# MAGIC     logical   = context["logical_date"]      # the run's logical timestamp
# MAGIC ```
# MAGIC
# MAGIC You do not have to declare these arguments explicitly - Airflow injects them.
# MAGIC
# MAGIC ### Rule 2: XCom carries S3 URIs, not DataFrames
# MAGIC
# MAGIC XCom values live in the Airflow metadata DB (Postgres on MWAA). The rule of thumb is "anything bigger than ~1 MB is too big". A pandas DataFrame of 50 predictions might fit; a DataFrame of 50 million rows certainly will not. Use S3 as the data plane, XCom as the control plane:
# MAGIC
# MAGIC ```python
# MAGIC def pull_batch(**context):
# MAGIC     rows = read_csv_from_s3("s3://...")
# MAGIC     slice_uri = write_csv_to_s3(rows[:50])
# MAGIC     return slice_uri   # one short string in XCom
# MAGIC
# MAGIC def score_batch(**context):
# MAGIC     ti = context["ti"]
# MAGIC     slice_uri = ti.xcom_pull(task_ids="pull_batch")
# MAGIC     rows = read_csv_from_s3(slice_uri)
# MAGIC     predictions = score_each_row(rows)
# MAGIC     out_uri = write_jsonl_to_s3(predictions)
# MAGIC     return out_uri
# MAGIC ```
# MAGIC
# MAGIC The `@dag` decorator exists and is fine. We use `with DAG(...) as dag:` today because it puts the DAG-construction call in the foreground and matches the Airflow documentation samples 1:1.
# MAGIC

# COMMAND ----------

# Demo: the EXACT Python source the Lab 1 DAG should produce after you
# f-string-interpolate STUDENT_ID. Read this once, then write your own
# version of it in the Lab 1 starter cell below.
#
# Two tasks:
#   pull_batch  - read 500 rows from s3://bread-academy-shared/lab-inputs/fraud_sample_500.csv,
#                 write a 50-row slice to per-student S3, return that key.
#   score_batch - xcom_pull the slice URI, call sm_runtime.invoke_endpoint per row,
#                 write predictions JSONL back to S3, return the predictions URI.
#
# Inside dag_code the OUTER triple-quoted string is an f-string. Any literal
# Python brace (dicts, Jinja templates like {{ ts_nodash }}) is DOUBLED.

demo_lab1_dag_code = f'''
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import boto3, csv, io, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
ENDPOINT_NAME = "{ENDPOINT_NAME}"
SHARED_BUCKET = "{SHARED_BUCKET}"
REGION        = "{AWS_REGION}"

INPUT_KEY     = "lab-inputs/fraud_sample_500.csv"
SLICE_KEY     = f"week21/student-{{STUDENT_ID}}/lab1/slice.csv"
PRED_KEY      = f"week21/student-{{STUDENT_ID}}/lab1/predictions.jsonl"


def pull_batch(**context):
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=SHARED_BUCKET, Key=INPUT_KEY)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body))
    rows = list(reader)[:50]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)
    s3.put_object(Bucket=SHARED_BUCKET, Key=SLICE_KEY, Body=out.getvalue().encode())
    return f"s3://{{SHARED_BUCKET}}/{{SLICE_KEY}}"


def score_batch(**context):
    ti = context["ti"]
    slice_uri = ti.xcom_pull(task_ids="pull_batch")
    bucket, _, key = slice_uri.replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body))
    sm = boto3.client("sagemaker-runtime", region_name=REGION)
    preds = []
    for row in reader:
        resp = sm.invoke_endpoint(
            EndpointName=ENDPOINT_NAME,
            ContentType="application/json",
            Body=json.dumps({{"inputs": row["narrative"]}}).encode(),
        )
        out = json.loads(resp["Body"].read().decode())
        preds.append({{"narrative": row["narrative"], "prediction": out}})
    s3.put_object(
        Bucket=SHARED_BUCKET,
        Key=PRED_KEY,
        Body=("\\n".join(json.dumps(p) for p in preds)).encode(),
    )
    return f"s3://{{SHARED_BUCKET}}/{{PRED_KEY}}"


with DAG(
    dag_id=f"week21_lab1_{USER_SLUG}",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
) as dag:
    t_pull  = PythonOperator(task_id="pull_batch",  python_callable=pull_batch)
    t_score = PythonOperator(task_id="score_batch", python_callable=score_batch)
    t_pull >> t_score
'''

print(demo_lab1_dag_code[:500])
print("... (truncated) ...")
print(f"Total length: {len(demo_lab1_dag_code)} bytes")


# COMMAND ----------

# Demo push (Lab 1): watch the WHOLE pipeline work before you build your own.
# Take the demo source above, point its dag_id at a SEPARATE week21_demo1_<you>
# dag (so demo and lab do not collide), isolate its S3 output, then
# upload -> register -> trigger (unpauses) -> wait. Open the Airflow UI to watch.
#
# USER_SLUG / STUDENT_ID / _folder all come from the setup cell. Do NOT redefine
# them here - that is what broke earlier (the swap below keys off the dag_id
# PREFIX, which is the same no matter what your slug is).
demo1_dag_id = f"week21_demo1_{USER_SLUG}"

# Swap the dag_id PREFIX (week21_lab1_ -> week21_demo1_); slug-agnostic so it
# works for any identity. Then isolate output to week21/<folder>/demo1/.
_demo1_src = demo_lab1_dag_code.replace("week21_lab1_", "week21_demo1_")
_demo1_src = _demo1_src.replace(
    "week21/student-{STUDENT_ID}/lab1/", f"week21/{_folder}/demo1/"
)

# Upload under this identity's own folder, register, trigger (unpauses first), wait.
s3.put_object(
    Bucket=DAGS_BUCKET,
    Key=f"{DAG_PREFIX}/demo1.py",
    Body=_demo1_src.encode(),
)
print(f"Uploaded demo to s3://{DAGS_BUCKET}/{DAG_PREFIX}/demo1.py")
poll_until_registered(demo1_dag_id)
demo1_run = trigger_dag(demo1_dag_id)   # trigger_dag unpauses first
demo1_state = wait_for_dag(demo1_dag_id, demo1_run)
print(f"Demo 1 finished: {demo1_state} (dag_id={demo1_dag_id})")
print("Open the Airflow UI and find this dag to see the graph + task logs.")
print("Now go build YOUR version in the lab below.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 1: Author and upload your first DAG (~15 min)
# MAGIC
# MAGIC Your turn. You will author, upload, and trigger a two-task DAG that pulls 50 fraud-transaction rows from S3 and scores them through the live `fraud-classifier-endpoint`.
# MAGIC
# MAGIC ### Goal
# MAGIC
# MAGIC Build a Python f-string `lab1_dag_code` whose `dag_id` is `week21_lab1_{USER_SLUG}` (with your student id baked in). The DAG has two PythonOperator tasks - `pull_batch` and `score_batch` - chained by `>>`. Upload via `upload_dag`, poll via `poll_until_registered`, trigger via `trigger_dag`, wait via `wait_for_dag`. Then read the predictions JSONL from S3 and compute the fraud rate.
# MAGIC
# MAGIC ### Steps
# MAGIC
# MAGIC 1. Build the f-string. Look at the demo cell above and reproduce its shape. Bake your `STUDENT_ID` into the source.
# MAGIC 2. `upload_dag(STUDENT_ID, 1, lab1_dag_code)`.
# MAGIC 3. `poll_until_registered(f"week21_lab1_{USER_SLUG}")`. Expect 30 to 60 seconds.
# MAGIC 4. `lab1_run_id = trigger_dag(f"week21_lab1_{USER_SLUG}")`.
# MAGIC 5. `wait_for_dag(...)` and assert the final state is `"success"`.
# MAGIC 6. Read the predictions JSONL from `s3://bread-academy-shared/week21/participant-NN/lab1/predictions.jsonl`. Compute `lab1_fraud_rate` as the fraction of rows whose prediction label is `"fraud"`.
# MAGIC 7. Optionally also pull the `score_batch` task's XCom return value via the REST API:
# MAGIC
# MAGIC    ```
# MAGIC    GET /dags/{dag_id}/dagRuns/{run_id}/taskInstances/score_batch/xcomEntries/return_value
# MAGIC    ```
# MAGIC
# MAGIC ### Final assertions
# MAGIC
# MAGIC - The predictions JSONL has exactly 50 lines.
# MAGIC - `0.0 <= lab1_fraud_rate <= 1.0`.
# MAGIC
# MAGIC ### Stretch (in class, if you have time)
# MAGIC
# MAGIC Trigger the Lab 1 DAG a second time. Notice that re-running `upload_dag` overwrites the same `.py` file in S3 and the dag_id stays the same; the scheduler picks up the new file but does NOT create a new dag. This is the right mental model for "deploy a new version of the DAG".
# MAGIC
# MAGIC ### Homework extension
# MAGIC
# MAGIC Extend `score_batch` to also write a Parquet copy of the predictions alongside the JSONL. Use `pyarrow` (already on the MWAA workers). Re-upload and re-trigger. What does this teach you about the cost of changing a DAG vs the cost of changing a downstream consumer?
# MAGIC

# COMMAND ----------

# Lab 1 starter (scaffolded). The DAG skeleton is given. You fill the TWO
# task BODIES marked YOUR CODE - you do NOT need to retype the whole file.
# Do NOT run the safety-net cell below if you finish this on your own.
#
# Reminder: dag_code is an f-string, so STUDENT_ID etc. are baked at upload
# time. Any LITERAL brace inside (dicts, Jinja) must be DOUBLED: {{ }}.

lab1_dag_code = f"""
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import boto3, csv, io, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
ENDPOINT_NAME = "{ENDPOINT_NAME}"
SHARED_BUCKET = "{SHARED_BUCKET}"
REGION        = "{AWS_REGION}"

INPUT_KEY = "lab-inputs/fraud_sample_500.csv"
SLICE_KEY = f"week21/student-{{STUDENT_ID}}/lab1/slice.csv"
PRED_KEY  = f"week21/student-{{STUDENT_ID}}/lab1/predictions.jsonl"


def pull_batch(**context):
    # YOUR CODE
    # Read INPUT_KEY from SHARED_BUCKET, keep the first 50 rows, write them
    # to SLICE_KEY, and return f"s3://{{SHARED_BUCKET}}/{{SLICE_KEY}}".
    pass


def score_batch(**context):
    # YOUR CODE
    # xcom_pull the slice URI from pull_batch, read the CSV, call
    # sm_runtime.invoke_endpoint on each row's narrative, write the
    # predictions to PRED_KEY as JSONL, return its s3:// URI.
    pass


with DAG(
    dag_id=f"week21_lab1_{USER_SLUG}",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
) as dag:
    t_pull  = PythonOperator(task_id="pull_batch",  python_callable=pull_batch)
    t_score = PythonOperator(task_id="score_batch", python_callable=score_batch)
    t_pull >> t_score
"""

# Upload, poll, trigger, wait. Then collect the run id and predictions URI.
lab1_run_id = None  # YOUR CODE
lab1_predictions_uri = None  # YOUR CODE

# Read the predictions JSONL and compute the fraud rate.
lab1_fraud_rate = None  # YOUR CODE

# Final assertions (uncomment when ready):
# assert lab1_dag_code is not None and "week21_lab1_" in lab1_dag_code
# assert lab1_run_id is not None
# assert lab1_predictions_uri and lab1_predictions_uri.startswith("s3://")
# assert 0.0 <= lab1_fraud_rate <= 1.0
# print(f"Lab 1 PASS: fraud_rate={lab1_fraud_rate:.3f}")


# COMMAND ----------

# Lab 1 SAFETY-NET: run this if you didn't finish Lab 1 so the rest of the
# notebook still works. SKIP this cell if you DID finish Lab 1.

if lab1_run_id is None:
    print("Using Lab 1 safety-net so the rest of the notebook can run.")
    lab1_dag_code = demo_lab1_dag_code   # the demo above is the reference solution
    upload_dag(STUDENT_ID, 1, lab1_dag_code)
    poll_until_registered(f"week21_lab1_{USER_SLUG}")
    lab1_run_id = trigger_dag(f"week21_lab1_{USER_SLUG}")
    state = wait_for_dag(f"week21_lab1_{USER_SLUG}", lab1_run_id)
    assert state == "success", f"Lab 1 DAG ended in state {state}"

    lab1_predictions_uri = f"s3://{SHARED_BUCKET}/week21/student-{STUDENT_ID}/lab1/predictions.jsonl"
    body = s3.get_object(
        Bucket=SHARED_BUCKET,
        Key=f"week21/student-{STUDENT_ID}/lab1/predictions.jsonl",
    )["Body"].read().decode()
    lines = [json.loads(line) for line in body.strip().splitlines()]

    def _is_fraud(p):
        pred = p["prediction"]
        if isinstance(pred, list) and pred:
            pred = pred[0]
        return isinstance(pred, dict) and pred.get("label") == "LABEL_1"

    lab1_fraud_rate = sum(1 for p in lines if _is_fraud(p)) / max(len(lines), 1)
    print(f"Safety-net Lab 1 PASS: predictions={len(lines)}, fraud_rate={lab1_fraud_rate:.3f}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Think About It
# MAGIC
# MAGIC Two short reflections - jot down your answers; we will not collect them.
# MAGIC
# MAGIC 1. **XCom carries S3 URIs, not DataFrames.** Why is passing the S3 URI through XCom safer than passing the predictions DataFrame directly? Imagine a downstream team also wants the predictions for an audit pipeline next quarter - which design is easier to extend?
# MAGIC
# MAGIC 2. **dag_id collisions are silent.** Your DAG is `week21_lab1_{USER_SLUG}`. What would the Airflow scheduler do if two students used the literal `week21_lab1` without the suffix and both uploaded to the same prefix? Hint: there is no error log. The Airflow GitHub issue tracker calls this "silently overrides DAGs with duplicate dag_id" - the tree view oscillates between definitions every 30 seconds. Why is the per-student suffix the right answer for a 60-student class?
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Topic 2: BranchPythonOperator and the join trigger-rule footgun
# MAGIC
# MAGIC A DAG often has to make a runtime decision: "if fraud rate is high, page someone; otherwise, just log it." `BranchPythonOperator`'s callable returns a `task_id` (or list of task_ids); the chosen branch arms run, and the UNCHOSEN arms become `skipped`.
# MAGIC
# MAGIC ```
# MAGIC                   pull_batch
# MAGIC                      |
# MAGIC                  score_batch
# MAGIC                      |
# MAGIC               compute_fraud_rate
# MAGIC                      |
# MAGIC                 decide_route        <- BranchPythonOperator
# MAGIC                 /         \
# MAGIC         high_risk          normal
# MAGIC               \           /
# MAGIC                  join             <- the footgun lives here
# MAGIC ```
# MAGIC
# MAGIC ### The footgun
# MAGIC
# MAGIC The default trigger rule on every task is `all_success`. That rule fires only when ALL upstream tasks succeeded. After a branch, at least one upstream is `skipped` (not `success`), so a join task with the default trigger rule is ALSO skipped. Silently. The DAG looks green but `join` never ran.
# MAGIC
# MAGIC ### The fix
# MAGIC
# MAGIC Set the join task's `trigger_rule` to `none_failed_min_one_success`:
# MAGIC
# MAGIC ```python
# MAGIC from airflow.utils.trigger_rule import TriggerRule
# MAGIC
# MAGIC join = EmptyOperator(
# MAGIC     task_id="join",
# MAGIC     trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC This means: fire if no upstream FAILED AND at least one upstream succeeded. A `skipped` upstream is fine. This is the canonical fix documented in Airflow GitHub issue #19222.
# MAGIC
# MAGIC ### Lab 2 shape
# MAGIC
# MAGIC `pull_batch >> score_batch >> compute_fraud_rate >> decide_route` branches to either `high_risk` (writes a marker to `s3://bread-academy-shared/high-risk/...` AND publishes SNS) or `normal` (just logs). Both arms then converge on `join`, an `EmptyOperator` with the trigger rule above. Run it twice - once with a low threshold so `high_risk` fires, once with a high threshold so `normal` fires.
# MAGIC

# COMMAND ----------

# Demo: the Lab 2 DAG. Same pull/score pattern as Lab 1, plus a fraud-rate
# computation, a BranchPythonOperator, two branch arms, and a join with the
# all-important none_failed_min_one_success trigger rule.
#
# The threshold lives in dag_run.conf so we can flip the branch decision
# from the trigger call without re-uploading the DAG.

demo_lab2_dag_code = f'''
from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.utils.trigger_rule import TriggerRule
from datetime import datetime
import boto3, csv, io, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
ENDPOINT_NAME = "{ENDPOINT_NAME}"
SHARED_BUCKET = "{SHARED_BUCKET}"
REGION        = "{AWS_REGION}"
SNS_TOPIC_ARN = "{SNS_TOPIC_ARN}"

INPUT_KEY  = "lab-inputs/fraud_sample_500.csv"
SLICE_KEY  = f"week21/student-{{STUDENT_ID}}/lab2/slice.csv"
PRED_KEY   = f"week21/student-{{STUDENT_ID}}/lab2/predictions.jsonl"
HIGH_RISK_KEY = f"high-risk/student-{{STUDENT_ID}}/marker.json"


def pull_batch(**context):
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=SHARED_BUCKET, Key=INPUT_KEY)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body))
    rows = list(reader)[:50]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)
    s3.put_object(Bucket=SHARED_BUCKET, Key=SLICE_KEY, Body=out.getvalue().encode())
    return f"s3://{{SHARED_BUCKET}}/{{SLICE_KEY}}"


def score_batch(**context):
    ti = context["ti"]
    slice_uri = ti.xcom_pull(task_ids="pull_batch")
    bucket, _, key = slice_uri.replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body))
    sm = boto3.client("sagemaker-runtime", region_name=REGION)
    preds = []
    for row in reader:
        resp = sm.invoke_endpoint(
            EndpointName=ENDPOINT_NAME,
            ContentType="application/json",
            Body=json.dumps({{"inputs": row["narrative"]}}).encode(),
        )
        out = json.loads(resp["Body"].read().decode())
        preds.append({{"narrative": row["narrative"], "prediction": out}})
    s3.put_object(
        Bucket=SHARED_BUCKET,
        Key=PRED_KEY,
        Body=("\\n".join(json.dumps(p) for p in preds)).encode(),
    )
    return f"s3://{{SHARED_BUCKET}}/{{PRED_KEY}}"


def compute_fraud_rate(**context):
    ti = context["ti"]
    pred_uri = ti.xcom_pull(task_ids="score_batch")
    bucket, _, key = pred_uri.replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode()
    lines = [json.loads(line) for line in body.strip().splitlines()]
    def is_fraud(p):
        pred = p["prediction"]
        if isinstance(pred, list) and pred:
            pred = pred[0]
        return isinstance(pred, dict) and pred.get("label") == "LABEL_1"
    rate = sum(1 for p in lines if is_fraud(p)) / max(len(lines), 1)
    return rate


def decide_route(**context):
    ti = context["ti"]
    rate = ti.xcom_pull(task_ids="compute_fraud_rate")
    threshold = context["dag_run"].conf.get("fraud_rate_threshold", 0.05)
    return "high_risk" if rate > threshold else "normal"


def high_risk(**context):
    ti = context["ti"]
    rate = ti.xcom_pull(task_ids="compute_fraud_rate")
    s3 = boto3.client("s3", region_name=REGION)
    s3.put_object(
        Bucket=SHARED_BUCKET,
        Key=HIGH_RISK_KEY,
        Body=json.dumps({{"fraud_rate": rate, "student_id": STUDENT_ID}}).encode(),
    )
    sns = boto3.client("sns", region_name=REGION)
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject="High fraud rate detected",
        Message=f"student {{STUDENT_ID}} fraud_rate={{rate:.3f}}",
    )
    print(f"HIGH RISK: rate={{rate:.3f}}")


def normal(**context):
    ti = context["ti"]
    rate = ti.xcom_pull(task_ids="compute_fraud_rate")
    print(f"NORMAL: rate={{rate:.3f}}")


with DAG(
    dag_id=f"week21_lab2_{USER_SLUG}",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
) as dag:
    t_pull   = PythonOperator(task_id="pull_batch",  python_callable=pull_batch)
    t_score  = PythonOperator(task_id="score_batch", python_callable=score_batch)
    t_rate   = PythonOperator(task_id="compute_fraud_rate", python_callable=compute_fraud_rate)
    t_decide = BranchPythonOperator(task_id="decide_route", python_callable=decide_route)
    t_high   = PythonOperator(task_id="high_risk", python_callable=high_risk)
    t_norm   = PythonOperator(task_id="normal",    python_callable=normal)
    # Remove the trigger_rule below to see the join silently skip on every run.
    t_join   = EmptyOperator(
        task_id="join",
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
    )
    t_pull >> t_score >> t_rate >> t_decide >> [t_high, t_norm] >> t_join
'''

print(f"Lab 2 DAG source length: {len(demo_lab2_dag_code)} bytes")


# COMMAND ----------

# Demo push (Lab 2): watch the WHOLE pipeline work before you build your own.
# Take the demo source above, point its dag_id at a SEPARATE week21_demo2_<you>
# dag (so demo and lab do not collide), isolate its S3 output, then
# upload -> register -> trigger (unpauses) -> wait. Open the Airflow UI to watch.
#
# USER_SLUG / STUDENT_ID / _folder all come from the setup cell. Do NOT redefine
# them here - that is what broke earlier (the swap below keys off the dag_id
# PREFIX, which is the same no matter what your slug is).
demo2_dag_id = f"week21_demo2_{USER_SLUG}"

# Swap the dag_id PREFIX (week21_lab2_ -> week21_demo2_); slug-agnostic so it
# works for any identity. Then isolate output to week21/<folder>/demo2/.
_demo2_src = demo_lab2_dag_code.replace("week21_lab2_", "week21_demo2_")
_demo2_src = _demo2_src.replace(
    "week21/student-{STUDENT_ID}/lab2/", f"week21/{_folder}/demo2/"
)

# Upload under this identity's own folder, register, trigger (unpauses first), wait.
s3.put_object(
    Bucket=DAGS_BUCKET,
    Key=f"{DAG_PREFIX}/demo2.py",
    Body=_demo2_src.encode(),
)
print(f"Uploaded demo to s3://{DAGS_BUCKET}/{DAG_PREFIX}/demo2.py")
poll_until_registered(demo2_dag_id)
demo2_run = trigger_dag(demo2_dag_id)   # trigger_dag unpauses first
demo2_state = wait_for_dag(demo2_dag_id, demo2_run)
print(f"Demo 2 finished: {demo2_state} (dag_id={demo2_dag_id})")
print("Open the Airflow UI and find this dag to see the graph + task logs.")
print("Now go build YOUR version in the lab below.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 2: Author the branching DAG (~15 min)
# MAGIC
# MAGIC You will author a DAG that runs the same `pull_batch >> score_batch` chain, then computes the fraud rate, then BRANCHES based on it.
# MAGIC
# MAGIC ### Goal
# MAGIC
# MAGIC Build `lab2_dag_code` whose `dag_id` is `week21_lab2_{USER_SLUG}` and shape is:
# MAGIC
# MAGIC ```
# MAGIC pull_batch >> score_batch >> compute_fraud_rate >> decide_route -> [high_risk, normal] >> join
# MAGIC ```
# MAGIC
# MAGIC - `decide_route` is a `BranchPythonOperator` that reads `dag_run.conf["fraud_rate_threshold"]` (default 0.05) and returns `"high_risk"` if the observed rate exceeds it, else `"normal"`.
# MAGIC - `high_risk` writes a marker to `s3://bread-academy-shared/high-risk/participant-NN/marker.json` AND publishes SNS.
# MAGIC - `normal` just prints.
# MAGIC - `join` is an `EmptyOperator` with `trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS`.
# MAGIC
# MAGIC ### Steps
# MAGIC
# MAGIC 1. Author the DAG (look at the demo above), upload via `upload_dag(..., 2, ...)`, poll until registered.
# MAGIC 2. `lab2_high_risk_run_id = trigger_dag(..., conf={"fraud_rate_threshold": 0.05})`. The pre-loaded input is engineered to have ~7-10% fraud, so `high_risk` should fire. Wait for success.
# MAGIC 3. `lab2_normal_run_id = trigger_dag(..., conf={"fraud_rate_threshold": 0.99})`. With this threshold no observed rate can exceed it, so `normal` should fire. Wait for success.
# MAGIC 4. Open the MWAA Airflow UI graph view for both runs and confirm visually which branch ran and which is `skipped`. The `join` task should be `success` in BOTH runs.
# MAGIC
# MAGIC ### Final assertions
# MAGIC
# MAGIC - Both runs ended in state `"success"`.
# MAGIC - In the high-risk run, `s3://bread-academy-shared/high-risk/participant-NN/marker.json` exists.
# MAGIC - In the normal run, the marker is unchanged from the high-risk run (because the `high_risk` task did not execute in the normal run).
# MAGIC
# MAGIC ### Stretch (in class)
# MAGIC
# MAGIC Edit your `lab2_dag_code` to REMOVE the `trigger_rule=...` line on the `join` task (so it defaults to `all_success`). Re-upload and re-trigger either flavor. Open the UI graph view: `join` will be `skipped` even though the rest of the DAG succeeded. Revert the change before moving on.
# MAGIC
# MAGIC ### Homework extension
# MAGIC
# MAGIC Turn `decide_route` into a 3-way branch (`low`, `medium`, `high`) and write the corresponding `>>` graph. What new trigger rule does the join need? Hint: it does not change - `none_failed_min_one_success` already handles "one of three arms ran".
# MAGIC

# COMMAND ----------

# Lab 2 starter. Author the branching DAG, upload it, and trigger it twice
# with different thresholds.

# (1) Author the DAG source. Make sure 'join' has trigger_rule=NONE_FAILED_MIN_ONE_SUCCESS.
lab2_dag_code = None  # YOUR CODE

# (2) Trigger with the low threshold to make high_risk fire.
lab2_high_risk_run_id = None  # YOUR CODE

# (3) Trigger with the high threshold to make normal fire.
lab2_normal_run_id = None  # YOUR CODE

# Final assertions (uncomment when ready):
# assert lab2_dag_code is not None and "BranchPythonOperator" in lab2_dag_code
# assert lab2_high_risk_run_id is not None
# assert lab2_normal_run_id is not None
# print("Lab 2 PASS: both runs completed; check the UI graph view to confirm branches.")


# COMMAND ----------

# Lab 2 SAFETY-NET: run this if you didn't finish Lab 2 so the rest of the
# notebook still works. SKIP this cell if you DID finish Lab 2.

if lab2_high_risk_run_id is None:
    print("Using Lab 2 safety-net so the rest of the notebook can run.")
    lab2_dag_code = demo_lab2_dag_code
    upload_dag(STUDENT_ID, 2, lab2_dag_code)
    poll_until_registered(f"week21_lab2_{USER_SLUG}")

    lab2_high_risk_run_id = trigger_dag(
        f"week21_lab2_{USER_SLUG}", conf={"fraud_rate_threshold": 0.05}
    )
    s1 = wait_for_dag(f"week21_lab2_{USER_SLUG}", lab2_high_risk_run_id)
    assert s1 == "success", f"high-risk run ended in {s1}"

    lab2_normal_run_id = trigger_dag(
        f"week21_lab2_{USER_SLUG}", conf={"fraud_rate_threshold": 0.99}
    )
    s2 = wait_for_dag(f"week21_lab2_{USER_SLUG}", lab2_normal_run_id)
    assert s2 == "success", f"normal run ended in {s2}"

    print("Safety-net Lab 2 PASS: both runs success; high_risk and normal each ran once.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Topic 3: ShortCircuit gates and the cleanup-task trigger rule
# MAGIC
# MAGIC A common ML-Ops pattern: gate a deployment on a recent quality metric. "Approve the new model package ONLY if the live endpoint's CloudWatch accuracy was above 0.85 over the last hour. Otherwise, skip the approval - but still record what happened."
# MAGIC
# MAGIC `ShortCircuitOperator` is built for this:
# MAGIC
# MAGIC ```python
# MAGIC from airflow.operators.python import ShortCircuitOperator
# MAGIC
# MAGIC gate = ShortCircuitOperator(
# MAGIC     task_id="gate_on_accuracy",
# MAGIC     python_callable=should_approve,           # returns True/False
# MAGIC     ignore_downstream_trigger_rules=False,    # <- critical, see below
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC When the callable returns truthy, downstream tasks proceed normally. When it returns falsy, downstream tasks are SKIPPED.
# MAGIC
# MAGIC ### The footgun
# MAGIC
# MAGIC `ignore_downstream_trigger_rules` defaults to `True`. With that default, a falsy gate skips EVERY downstream task in the DAG, recursively, regardless of their `trigger_rule`. Your `all_done` cleanup task that you carefully designed to run on success OR failure? Skipped. Silently.
# MAGIC
# MAGIC ### The fix
# MAGIC
# MAGIC Set `ignore_downstream_trigger_rules=False`. Now the skip only propagates to DIRECT downstream tasks; indirect downstreams get to honor their own trigger rules.
# MAGIC
# MAGIC ### The Lab 3 shape
# MAGIC
# MAGIC ```
# MAGIC fetch_accuracy_from_cloudwatch
# MAGIC             |
# MAGIC        gate_on_accuracy         <- ShortCircuit, ignore_downstream_trigger_rules=False
# MAGIC             |
# MAGIC    approve_model_package        <- skipped on no-go
# MAGIC             |
# MAGIC        notify_outcome           <- trigger_rule="all_done" - runs even on gate skip
# MAGIC ```
# MAGIC
# MAGIC `notify_outcome` writes a marker to S3 saying either `"approved"` or `"gated"`. Run the DAG twice - once with a low accuracy threshold (gate passes, both downstream tasks run), once with a very high threshold (gate fails, `approve_model_package` is skipped, `notify_outcome` STILL runs and records `"gated"`).
# MAGIC

# COMMAND ----------

# Demo: the Lab 3 DAG. Three tasks - fetch the latest CloudWatch accuracy,
# gate on it, approve the most recent model package - plus an always-running
# notify_outcome cleanup task with trigger_rule="all_done". The whole point
# of this DAG is to demonstrate ignore_downstream_trigger_rules=False working
# correctly: notify_outcome MUST fire in both the approved and gated branches.

demo_lab3_dag_code = f'''
from airflow import DAG
from airflow.operators.python import PythonOperator, ShortCircuitOperator
from airflow.utils.trigger_rule import TriggerRule
from datetime import datetime, timedelta, timezone
import boto3, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
REGION        = "{AWS_REGION}"
SHARED_BUCKET = "{SHARED_BUCKET}"
PACKAGE_GROUP = "{PACKAGE_GROUP}"

OUTCOME_KEY = f"week21/student-{{STUDENT_ID}}/lab3/outcome.json"


def fetch_accuracy(**context):
    cw = boto3.client("cloudwatch", region_name=REGION)
    now = datetime.now(timezone.utc)
    resp = cw.get_metric_statistics(
        Namespace="FraudClassifier",
        MetricName="Accuracy",
        StartTime=now - timedelta(hours=1),
        EndTime=now,
        Period=300,
        Statistics=["Average"],
    )
    datapoints = sorted(resp.get("Datapoints", []), key=lambda d: d["Timestamp"])
    if not datapoints:
        # Pre-class fallback so the lab is robust even if the metric is fresh.
        return 0.90
    return float(datapoints[-1]["Average"])


def gate_on_accuracy(**context):
    ti = context["ti"]
    acc = ti.xcom_pull(task_ids="fetch_accuracy")
    threshold = context["dag_run"].conf.get("min_accuracy", 0.85)
    print(f"accuracy={{acc:.3f}} threshold={{threshold:.3f}}")
    return acc > threshold


def approve_model_package(**context):
    sm = boto3.client("sagemaker", region_name=REGION)
    pkgs = sm.list_model_packages(
        ModelPackageGroupName=PACKAGE_GROUP,
        MaxResults=1,
        SortBy="CreationTime",
        SortOrder="Descending",
    )["ModelPackageSummaryList"]
    if not pkgs:
        raise RuntimeError(f"No packages in group {{PACKAGE_GROUP}}")
    arn = pkgs[0]["ModelPackageArn"]
    sm.update_model_package(
        ModelPackageArn=arn,
        ModelApprovalStatus="Approved",
        ApprovalDescription=f"Approved by week21_lab3_{{USER_SLUG}}",
    )
    print(f"Approved {{arn}}")


def notify_outcome(**context):
    ti = context["ti"]
    approved_state = ti.xcom_pull(task_ids="approve_model_package", default=None)
    gate_result = ti.xcom_pull(task_ids="gate_on_accuracy")
    outcome = "approved" if gate_result else "gated"
    s3 = boto3.client("s3", region_name=REGION)
    s3.put_object(
        Bucket=SHARED_BUCKET,
        Key=OUTCOME_KEY,
        Body=json.dumps({{"outcome": outcome, "student_id": STUDENT_ID}}).encode(),
    )
    print(f"notify_outcome wrote outcome={{outcome}}")


with DAG(
    dag_id=f"week21_lab3_{USER_SLUG}",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
) as dag:
    t_fetch  = PythonOperator(task_id="fetch_accuracy",  python_callable=fetch_accuracy)
    t_gate   = ShortCircuitOperator(
        task_id="gate_on_accuracy",
        python_callable=gate_on_accuracy,
        ignore_downstream_trigger_rules=False,   # the whole point
    )
    t_approve = PythonOperator(task_id="approve_model_package", python_callable=approve_model_package)
    t_notify  = PythonOperator(
        task_id="notify_outcome",
        python_callable=notify_outcome,
        trigger_rule=TriggerRule.ALL_DONE,
    )
    t_fetch >> t_gate >> t_approve >> t_notify
    t_gate >> t_notify   # also wire gate directly to notify so the all_done rule has an upstream even on skip
'''

print(f"Lab 3 DAG source length: {len(demo_lab3_dag_code)} bytes")


# COMMAND ----------

# Demo push (Lab 3): watch the WHOLE pipeline work before you build your own.
# Take the demo source above, point its dag_id at a SEPARATE week21_demo3_<you>
# dag (so demo and lab do not collide), isolate its S3 output, then
# upload -> register -> trigger (unpauses) -> wait. Open the Airflow UI to watch.
#
# USER_SLUG / STUDENT_ID / _folder all come from the setup cell. Do NOT redefine
# them here - that is what broke earlier (the swap below keys off the dag_id
# PREFIX, which is the same no matter what your slug is).
demo3_dag_id = f"week21_demo3_{USER_SLUG}"

# Swap the dag_id PREFIX (week21_lab3_ -> week21_demo3_); slug-agnostic so it
# works for any identity. Then isolate output to week21/<folder>/demo3/.
_demo3_src = demo_lab3_dag_code.replace("week21_lab3_", "week21_demo3_")
_demo3_src = _demo3_src.replace(
    "week21/student-{STUDENT_ID}/lab3/", f"week21/{_folder}/demo3/"
)

# Upload under this identity's own folder, register, trigger (unpauses first), wait.
s3.put_object(
    Bucket=DAGS_BUCKET,
    Key=f"{DAG_PREFIX}/demo3.py",
    Body=_demo3_src.encode(),
)
print(f"Uploaded demo to s3://{DAGS_BUCKET}/{DAG_PREFIX}/demo3.py")
poll_until_registered(demo3_dag_id)
demo3_run = trigger_dag(demo3_dag_id)   # trigger_dag unpauses first
demo3_state = wait_for_dag(demo3_dag_id, demo3_run)
print(f"Demo 3 finished: {demo3_state} (dag_id={demo3_dag_id})")
print("Open the Airflow UI and find this dag to see the graph + task logs.")
print("Now go build YOUR version in the lab below.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 3: Author the accuracy gate DAG (~15 min)
# MAGIC
# MAGIC You will author a DAG that fetches the live CloudWatch accuracy metric, gates a model-package approval on it, and ALWAYS records the outcome via a cleanup task.
# MAGIC
# MAGIC ### Goal
# MAGIC
# MAGIC Build `lab3_dag_code` whose `dag_id` is `week21_lab3_{USER_SLUG}` and shape is:
# MAGIC
# MAGIC ```
# MAGIC fetch_accuracy >> gate_on_accuracy >> approve_model_package >> notify_outcome
# MAGIC                                 |__________________________________^
# MAGIC ```
# MAGIC
# MAGIC - `gate_on_accuracy` is a `ShortCircuitOperator` with `ignore_downstream_trigger_rules=False`. Its callable returns `True` if the fetched accuracy is above `dag_run.conf["min_accuracy"]`.
# MAGIC - `approve_model_package` calls `sagemaker.update_model_package` on the most recent package in your per-student group `fraud-classifier-week19-student-NN` with `ModelApprovalStatus="Approved"`.
# MAGIC - `notify_outcome` has `trigger_rule="all_done"` and writes a JSON marker to `s3://bread-academy-shared/week21/participant-NN/lab3/outcome.json` containing `{"outcome": "approved" or "gated"}`.
# MAGIC
# MAGIC ### Steps
# MAGIC
# MAGIC 1. Author the DAG, upload via `upload_dag(..., 3, ...)`, poll until registered.
# MAGIC 2. **Pass run**: `trigger_dag(..., conf={"min_accuracy": 0.5})`. Wait for success. Read the outcome marker; it should be `"approved"`.
# MAGIC 3. **Gated run**: `trigger_dag(..., conf={"min_accuracy": 0.99})`. Wait for success (the DAG itself does NOT fail just because the gate skipped downstream). Read the outcome marker; it should be `"gated"`.
# MAGIC
# MAGIC ### Final assertions
# MAGIC
# MAGIC - `lab3_pass_outcome == "approved"`.
# MAGIC - `lab3_gated_outcome == "gated"`.
# MAGIC
# MAGIC ### Stretch (in class)
# MAGIC
# MAGIC Re-author the DAG with `ignore_downstream_trigger_rules=True` (the default), re-upload, re-trigger the gated run. Look at the UI: `notify_outcome` is `skipped` even though it has `trigger_rule="all_done"`. THIS is the silent footgun that just lost you the cleanup write.
# MAGIC
# MAGIC ### Homework extension
# MAGIC
# MAGIC Replace `ShortCircuitOperator` with a `BranchPythonOperator` whose callable returns `"approve"`, `"reject"`, or `"pending"` based on the accuracy value, where each option leads to a different downstream task. Now you have a 3-state gate with a proper audit trail (different markers per outcome).
# MAGIC

# COMMAND ----------

# Lab 3 starter. Author the gate DAG and trigger it twice with different
# accuracy thresholds.

# (1) Author the DAG source. Remember ignore_downstream_trigger_rules=False on the gate.
lab3_dag_code = None  # YOUR CODE

# (2) Pass run (low threshold).
lab3_pass_run = None  # YOUR CODE

# (3) Gated run (high threshold).
lab3_gated_run = None  # YOUR CODE

# (4) Read both outcome markers from S3.
lab3_pass_outcome  = None  # YOUR CODE
lab3_gated_outcome = None  # YOUR CODE

# Final assertions (uncomment when ready):
# assert lab3_pass_outcome == "approved"
# assert lab3_gated_outcome == "gated"
# print("Lab 3 PASS: gate respected ignore_downstream_trigger_rules=False")


# COMMAND ----------

# Lab 3 SAFETY-NET: run this if you didn't finish Lab 3 so the rest of the
# notebook still works. SKIP this cell if you DID finish Lab 3.

if lab3_pass_run is None:
    print("Using Lab 3 safety-net so the rest of the notebook can run.")
    lab3_dag_code = demo_lab3_dag_code
    upload_dag(STUDENT_ID, 3, lab3_dag_code)
    poll_until_registered(f"week21_lab3_{USER_SLUG}")

    lab3_pass_run = trigger_dag(
        f"week21_lab3_{USER_SLUG}", conf={"min_accuracy": 0.5}
    )
    sp = wait_for_dag(f"week21_lab3_{USER_SLUG}", lab3_pass_run)
    assert sp == "success", f"pass run ended in {sp}"
    body = s3.get_object(
        Bucket=SHARED_BUCKET,
        Key=f"week21/student-{STUDENT_ID}/lab3/outcome.json",
    )["Body"].read().decode()
    lab3_pass_outcome = json.loads(body)["outcome"]

    lab3_gated_run = trigger_dag(
        f"week21_lab3_{USER_SLUG}", conf={"min_accuracy": 0.99}
    )
    sg = wait_for_dag(f"week21_lab3_{USER_SLUG}", lab3_gated_run)
    assert sg == "success", f"gated run ended in {sg}"
    body = s3.get_object(
        Bucket=SHARED_BUCKET,
        Key=f"week21/student-{STUDENT_ID}/lab3/outcome.json",
    )["Body"].read().decode()
    lab3_gated_outcome = json.loads(body)["outcome"]

    print(f"Safety-net Lab 3 PASS: pass_outcome={lab3_pass_outcome}, gated_outcome={lab3_gated_outcome}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Think About It
# MAGIC
# MAGIC 1. **Gating on the right signal.** Your gate is on a CloudWatch accuracy metric, which captures live model quality. What other signals could a Bread Financial team gate on? Examples: false-positive rate over the last day, chargeback rate from the operations team, a downstream feature-store freshness metric. What is the operational cost of each signal - how often does it update, who maintains it, how long does staleness lie undetected?
# MAGIC
# MAGIC 2. **The cost of a silent cleanup skip.** Why is `ignore_downstream_trigger_rules=False` mandatory when you have an `all_done` cleanup task? Imagine your cleanup writes an audit row to a compliance table. What does an "I forgot to set that flag" outage look like three months later when a regulator asks for the audit trail?
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Topic 4: Parallelism, fan-in, and `on_failure_callback`
# MAGIC
# MAGIC Airflow lets you express fan-out + fan-in in one line:
# MAGIC
# MAGIC ```
# MAGIC pull_batch >> [score_a, score_b, score_c] >> notify_done
# MAGIC ```
# MAGIC
# MAGIC The three `score_*` tasks run in parallel (up to your worker slot cap; MWAA `mw1.small` is 5 concurrent slots, so 3 parallel scorers is well within budget). `notify_done` fan-ins them.
# MAGIC
# MAGIC ### Two trigger-rule choices for the fan-in
# MAGIC
# MAGIC - `trigger_rule="all_success"` (the default): `notify_done` only fires if all three scorers succeeded.
# MAGIC - `trigger_rule="none_failed"`: `notify_done` fires as long as no scorer outright failed. Skipped scorers are tolerated.
# MAGIC
# MAGIC For Lab 4 we want `notify_done` to fire on a fully-green run but NOT on a run where one partition failed (we want the SNS failure callback to be the only signal in that case). So `none_failed` is correct.
# MAGIC
# MAGIC ### Page a human on ANY task failure
# MAGIC
# MAGIC `default_args` propagates to every task:
# MAGIC
# MAGIC ```python
# MAGIC from airflow.providers.amazon.aws.notifications.sns import send_sns_notification
# MAGIC
# MAGIC notifier = send_sns_notification(
# MAGIC     aws_conn_id="aws_default",
# MAGIC     region_name="us-west-2",
# MAGIC     target_arn=SNS_TOPIC_ARN,
# MAGIC     message="Task {{ ti.task_id }} in {{ dag.dag_id }} failed at {{ ts }}",
# MAGIC )
# MAGIC
# MAGIC default_args = {
# MAGIC     "on_failure_callback": [notifier],   # MUST be a list in provider 9.0.0
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC Now any task that ends in `failed` triggers an SNS publish via Airflow's callback machinery. The Jinja-templated message includes the task id, dag id, and timestamp.
# MAGIC
# MAGIC ### The Lab 4 shape
# MAGIC
# MAGIC ```
# MAGIC pull_batch >> [score_partition_a, score_partition_b, score_partition_c] >> notify_done
# MAGIC ```
# MAGIC
# MAGIC `score_partition_b` deliberately raises `RuntimeError` when `dag_run.conf["force_fail"] is True`. Trigger the DAG once with `force_fail=False` (everyone succeeds, notify_done publishes the "all complete" SNS) and once with `force_fail=True` (partition B fails, `on_failure_callback` fires the failure SNS, `notify_done` is skipped because of `trigger_rule="none_failed"`).
# MAGIC

# COMMAND ----------

# Demo: the Lab 4 DAG. Fan-out into three partition scorers, fan-in into
# notify_done. on_failure_callback at the DAG level fires SNS on any task
# failure. Partition B has an injectable failure via dag_run.conf["force_fail"].

demo_lab4_dag_code = f'''
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.notifications.sns import send_sns_notification
from airflow.utils.trigger_rule import TriggerRule
from datetime import datetime
import boto3, csv, io, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
ENDPOINT_NAME = "{ENDPOINT_NAME}"
SHARED_BUCKET = "{SHARED_BUCKET}"
REGION        = "{AWS_REGION}"
SNS_TOPIC_ARN = "{SNS_TOPIC_ARN}"

INPUT_KEY = "lab-inputs/fraud_sample_500.csv"
SLICE_KEY = f"week21/student-{{STUDENT_ID}}/lab4/slice.csv"


def pull_batch(**context):
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=SHARED_BUCKET, Key=INPUT_KEY)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body))
    rows = list(reader)[:90]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)
    s3.put_object(Bucket=SHARED_BUCKET, Key=SLICE_KEY, Body=out.getvalue().encode())
    return f"s3://{{SHARED_BUCKET}}/{{SLICE_KEY}}"


def _score_partition(start, end, partition_name, **context):
    ti = context["ti"]
    slice_uri = ti.xcom_pull(task_ids="pull_batch")
    bucket, _, key = slice_uri.replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode()
    reader = list(csv.DictReader(io.StringIO(body)))[start:end]
    sm = boto3.client("sagemaker-runtime", region_name=REGION)
    preds = []
    for row in reader:
        resp = sm.invoke_endpoint(
            EndpointName=ENDPOINT_NAME,
            ContentType="application/json",
            Body=json.dumps({{"inputs": row["narrative"]}}).encode(),
        )
        out = json.loads(resp["Body"].read().decode())
        preds.append({{"narrative": row["narrative"], "prediction": out}})
    out_key = f"week21/student-{{STUDENT_ID}}/lab4/{{partition_name}}.jsonl"
    s3.put_object(
        Bucket=SHARED_BUCKET,
        Key=out_key,
        Body=("\\n".join(json.dumps(p) for p in preds)).encode(),
    )
    return f"s3://{{SHARED_BUCKET}}/{{out_key}}"


def score_partition_a(**context):
    return _score_partition(0, 30, "a", **context)


def score_partition_b(**context):
    if context["dag_run"].conf.get("force_fail", False):
        raise RuntimeError("forced failure in partition B for the alert demo")
    return _score_partition(30, 60, "b", **context)


def score_partition_c(**context):
    return _score_partition(60, 90, "c", **context)


def notify_done(**context):
    sns = boto3.client("sns", region_name=REGION)
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject="Lab 4 fan-in complete",
        Message=f"student {{STUDENT_ID}}: all 3 partitions scored",
    )
    print("notify_done published SNS")


sns_failure = send_sns_notification(
    aws_conn_id="aws_default",
    region_name=REGION,
    target_arn=SNS_TOPIC_ARN,
    message="Task {{{{ ti.task_id }}}} in {{{{ dag.dag_id }}}} failed at {{{{ ts }}}}",
)

default_args = {{
    "on_failure_callback": [sns_failure],
}}


with DAG(
    dag_id=f"week21_lab4_{USER_SLUG}",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
    default_args=default_args,
) as dag:
    t_pull = PythonOperator(task_id="pull_batch", python_callable=pull_batch)
    t_a = PythonOperator(task_id="score_partition_a", python_callable=score_partition_a)
    t_b = PythonOperator(task_id="score_partition_b", python_callable=score_partition_b)
    t_c = PythonOperator(task_id="score_partition_c", python_callable=score_partition_c)
    t_notify = PythonOperator(
        task_id="notify_done",
        python_callable=notify_done,
        trigger_rule=TriggerRule.NONE_FAILED,
    )
    t_pull >> [t_a, t_b, t_c] >> t_notify
'''

print(f"Lab 4 DAG source length: {len(demo_lab4_dag_code)} bytes")


# COMMAND ----------

# Demo push (Lab 4): watch the WHOLE pipeline work before you build your own.
# Take the demo source above, point its dag_id at a SEPARATE week21_demo4_<you>
# dag (so demo and lab do not collide), isolate its S3 output, then
# upload -> register -> trigger (unpauses) -> wait. Open the Airflow UI to watch.
#
# USER_SLUG / STUDENT_ID / _folder all come from the setup cell. Do NOT redefine
# them here - that is what broke earlier (the swap below keys off the dag_id
# PREFIX, which is the same no matter what your slug is).
demo4_dag_id = f"week21_demo4_{USER_SLUG}"

# Swap the dag_id PREFIX (week21_lab4_ -> week21_demo4_); slug-agnostic so it
# works for any identity. Then isolate output to week21/<folder>/demo4/.
_demo4_src = demo_lab4_dag_code.replace("week21_lab4_", "week21_demo4_")
_demo4_src = _demo4_src.replace(
    "week21/student-{STUDENT_ID}/lab4/", f"week21/{_folder}/demo4/"
)

# Upload under this identity's own folder, register, trigger (unpauses first), wait.
s3.put_object(
    Bucket=DAGS_BUCKET,
    Key=f"{DAG_PREFIX}/demo4.py",
    Body=_demo4_src.encode(),
)
print(f"Uploaded demo to s3://{DAGS_BUCKET}/{DAG_PREFIX}/demo4.py")
poll_until_registered(demo4_dag_id)
demo4_run = trigger_dag(demo4_dag_id)   # trigger_dag unpauses first
demo4_state = wait_for_dag(demo4_dag_id, demo4_run)
print(f"Demo 4 finished: {demo4_state} (dag_id={demo4_dag_id})")
print("Open the Airflow UI and find this dag to see the graph + task logs.")
print("Now go build YOUR version in the lab below.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 4: Author the fan-in alerting DAG (~15 min)
# MAGIC
# MAGIC You will author a DAG that scores transactions in three parallel partitions, fans in to a notification task, and pages a human via SNS on ANY task failure.
# MAGIC
# MAGIC ### Goal
# MAGIC
# MAGIC Build `lab4_dag_code` whose `dag_id` is `week21_lab4_{USER_SLUG}` and shape is:
# MAGIC
# MAGIC ```
# MAGIC pull_batch >> [score_partition_a, score_partition_b, score_partition_c] >> notify_done
# MAGIC ```
# MAGIC
# MAGIC - `default_args={"on_failure_callback": [send_sns_notification(...)]}` so every task wires the failure SNS automatically.
# MAGIC - `notify_done` has `trigger_rule="none_failed"`.
# MAGIC - `score_partition_b` raises `RuntimeError` when `dag_run.conf["force_fail"]` is True.
# MAGIC
# MAGIC ### Steps
# MAGIC
# MAGIC 1. Make sure your email is subscribed to the SNS topic (your instructor may have done this for the class - ask if you are unsure).
# MAGIC 2. Author the DAG, upload via `upload_dag(..., 4, ...)`, poll until registered.
# MAGIC 3. **OK run**: `trigger_dag(..., conf={"force_fail": False})`. Wait for success. You should receive a "Lab 4 fan-in complete" email.
# MAGIC 4. **Fail run**: `trigger_dag(..., conf={"force_fail": True})`. Wait for the final state, which should be `"failed"`. You should receive a "Task score_partition_b in week21_lab4_NN failed at ..." email.
# MAGIC
# MAGIC ### Final assertions
# MAGIC
# MAGIC - `lab4_ok_run` ended in `"success"`.
# MAGIC - `lab4_fail_run` ended in `"failed"`.
# MAGIC
# MAGIC ### Stretch (in class)
# MAGIC
# MAGIC Change `notify_done`'s `trigger_rule` to `"all_done"` and re-upload. Re-trigger the fail run. Now `notify_done` also runs after the partition failure - and publishes the success SNS. This is exactly the alert-storm risk we are trying to avoid. Revert.
# MAGIC
# MAGIC ### Homework extension
# MAGIC
# MAGIC Add `on_failure_callback=[send_sns_notification(...)]` to your Lab 1 DAG. Trigger it once normally and once with a deliberate failure (e.g. make `score_batch` call an endpoint that does not exist). What alert-storm risks do you create if every DAG in your team publishes to the same SNS topic? How would you triage which alerts mean "wake up at 3am" vs "look at it tomorrow"?
# MAGIC

# COMMAND ----------

# Lab 4 starter. Author the fan-in DAG with on_failure_callback at the
# default_args level, then trigger it twice (clean and force_fail).

# (1) Author the DAG source.
lab4_dag_code = None  # YOUR CODE

# (2) Clean run.
lab4_ok_run = None  # YOUR CODE

# (3) Force-fail run.
lab4_fail_run = None  # YOUR CODE

# Final assertions (uncomment when ready):
# assert lab4_dag_code is not None and "on_failure_callback" in lab4_dag_code
# assert lab4_ok_run is not None
# assert lab4_fail_run is not None
# print("Lab 4 PASS: check your inbox for two SNS emails (success and failure).")


# COMMAND ----------

# Lab 4 SAFETY-NET: run this if you didn't finish Lab 4 so the rest of the
# notebook still works. SKIP this cell if you DID finish Lab 4.

if lab4_ok_run is None:
    print("Using Lab 4 safety-net so the rest of the notebook can run.")
    lab4_dag_code = demo_lab4_dag_code
    upload_dag(STUDENT_ID, 4, lab4_dag_code)
    poll_until_registered(f"week21_lab4_{USER_SLUG}")

    lab4_ok_run = trigger_dag(
        f"week21_lab4_{USER_SLUG}", conf={"force_fail": False}
    )
    sok = wait_for_dag(f"week21_lab4_{USER_SLUG}", lab4_ok_run)
    print(f"ok run state: {sok}")

    lab4_fail_run = trigger_dag(
        f"week21_lab4_{USER_SLUG}", conf={"force_fail": True}
    )
    sfail = wait_for_dag(f"week21_lab4_{USER_SLUG}", lab4_fail_run)
    print(f"fail run state: {sfail}")

    print("Safety-net Lab 4 PASS: check your inbox for two SNS emails (success and failure).")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Topic 5: When to reach for the SageMaker provider operator
# MAGIC
# MAGIC Labs 1 through 4 all scored transactions by calling `boto3 sm_runtime.invoke_endpoint` inside a `PythonOperator`. That is the right tool for REALTIME, per-record inference - and it is the only choice because `apache-airflow-providers-amazon` does NOT ship a realtime-invoke operator.
# MAGIC
# MAGIC For BATCH inference, the provider DOES ship a purpose-built operator:
# MAGIC
# MAGIC ### The provider 9.0.0 SageMaker operator catalog (highlights)
# MAGIC
# MAGIC - `SageMakerTrainingOperator` - run a training job.
# MAGIC - `SageMakerProcessingOperator` - run a processing job (feature engineering, evaluation).
# MAGIC - `SageMakerTransformOperator` - run a batch transform (read S3 input, score, write S3 output).
# MAGIC - `SageMakerEndpointOperator` - CREATE or UPDATE an endpoint. **Does NOT invoke endpoints.**
# MAGIC - `SageMakerRegisterModelVersionOperator` - register a new model package version (Week 22 will lean on this).
# MAGIC
# MAGIC ### The rule of thumb
# MAGIC
# MAGIC | Pattern | Operator |
# MAGIC |---|---|
# MAGIC | Realtime, per-record inference | `PythonOperator` + `boto3 sm_runtime.invoke_endpoint` |
# MAGIC | Batch inference on a file in S3 | `SageMakerTransformOperator` |
# MAGIC | Training a model | `SageMakerTrainingOperator` |
# MAGIC | Promoting a model version | `SageMakerRegisterModelVersionOperator` |
# MAGIC
# MAGIC ### Why this matters
# MAGIC
# MAGIC `SageMakerTransformOperator` handles the create-transform-job + wait-for-completion + check-status mechanics for you. With `PythonOperator + boto3` you would write those three calls by hand (and likely forget the wait loop). The provider operator is the same amount of code in your DAG but trades "your bug surface" for "Airflow community's tested code".
# MAGIC
# MAGIC In Lab 5 you will rewrite Lab 1 using `SageMakerTransformOperator` against a batch input file.
# MAGIC

# COMMAND ----------

# Demo: the Lab 5 DAG. Three tasks - build the transform input, run the
# SageMakerTransformOperator, summarize the output. Notice we never call
# sm_runtime.invoke_endpoint - the operator handles create_transform_job +
# wait_for_completion behind the scenes. Import path is:
#   from airflow.providers.amazon.aws.operators.sagemaker import SageMakerTransformOperator
#
# ModelName here ("fraud-classifier-week19-model") is the SageMaker Model
# resource your instructor created from the Week 19 model package. The
# Transform operator needs a Model resource, NOT an endpoint name.

demo_lab5_dag_code = f'''
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.sagemaker import SageMakerTransformOperator
from datetime import datetime
import boto3, csv, io, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
SHARED_BUCKET = "{SHARED_BUCKET}"
REGION        = "{AWS_REGION}"
MODEL_NAME    = "fraud-classifier-week19-model"

INPUT_KEY  = "lab-inputs/fraud_sample_500.csv"
LAB5_INPUT_KEY  = f"week21/student-{{STUDENT_ID}}/lab5/input/input.csv"
LAB5_OUTPUT_PREFIX = f"week21/student-{{STUDENT_ID}}/lab5/output/"


def build_transform_input(**context):
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=SHARED_BUCKET, Key=INPUT_KEY)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body))
    rows = list(reader)[:50]
    out = io.StringIO()
    writer = csv.writer(out)
    for r in rows:
        writer.writerow([r["narrative"]])
    s3.put_object(Bucket=SHARED_BUCKET, Key=LAB5_INPUT_KEY, Body=out.getvalue().encode())
    return f"s3://{{SHARED_BUCKET}}/{{LAB5_INPUT_KEY}}"


def summarize_results(**context):
    s3 = boto3.client("s3", region_name=REGION)
    objs = s3.list_objects_v2(
        Bucket=SHARED_BUCKET, Prefix=LAB5_OUTPUT_PREFIX
    ).get("Contents", [])
    if not objs:
        raise RuntimeError(f"No transform output under s3://{{SHARED_BUCKET}}/{{LAB5_OUTPUT_PREFIX}}")
    total_rows = 0
    fraud_rows = 0
    for o in objs:
        body = s3.get_object(Bucket=SHARED_BUCKET, Key=o["Key"])["Body"].read().decode()
        for line in body.strip().splitlines():
            total_rows += 1
            try:
                rec = json.loads(line)
                pred = rec[0] if isinstance(rec, list) and rec else rec
                if isinstance(pred, dict) and pred.get("label") == "LABEL_1":
                    fraud_rows += 1
            except Exception:
                pass
    print(f"transform output: {{total_rows}} rows, fraud_rate={{fraud_rows / max(total_rows, 1):.3f}}")


transform_config = {{
    "TransformJobName": f"week21-lab5-{STUDENT_ID}-{{{{ ts_nodash }}}}",
    "ModelName": MODEL_NAME,
    "TransformInput": {{
        "DataSource": {{
            "S3DataSource": {{
                "S3DataType": "S3Prefix",
                "S3Uri": f"s3://{{SHARED_BUCKET}}/week21/student-{{STUDENT_ID}}/lab5/input/",
            }}
        }},
        "ContentType": "text/csv",
        "SplitType": "Line",
    }},
    "TransformOutput": {{
        "S3OutputPath": f"s3://{{SHARED_BUCKET}}/week21/student-{{STUDENT_ID}}/lab5/output/",
        "AssembleWith": "Line",
    }},
    "TransformResources": {{
        "InstanceCount": 1,
        "InstanceType": "ml.m5.large",
    }},
}}


with DAG(
    dag_id=f"week21_lab5_{USER_SLUG}",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
) as dag:
    t_build   = PythonOperator(task_id="build_transform_input", python_callable=build_transform_input)
    t_transform = SageMakerTransformOperator(
        task_id="run_transform",
        config=transform_config,
        wait_for_completion=True,
    )
    t_summarize = PythonOperator(task_id="summarize_results", python_callable=summarize_results)
    t_build >> t_transform >> t_summarize
'''

print(f"Lab 5 DAG source length: {len(demo_lab5_dag_code)} bytes")


# COMMAND ----------

# Demo push (Lab 5): watch the WHOLE pipeline work before you build your own.
# Take the demo source above, point its dag_id at a SEPARATE week21_demo5_<you>
# dag (so demo and lab do not collide), isolate its S3 output, then
# upload -> register -> trigger (unpauses) -> wait. Open the Airflow UI to watch.
#
# USER_SLUG / STUDENT_ID / _folder all come from the setup cell. Do NOT redefine
# them here - that is what broke earlier (the swap below keys off the dag_id
# PREFIX, which is the same no matter what your slug is).
demo5_dag_id = f"week21_demo5_{USER_SLUG}"

# Swap the dag_id PREFIX (week21_lab5_ -> week21_demo5_); slug-agnostic so it
# works for any identity. Then isolate output to week21/<folder>/demo5/.
_demo5_src = demo_lab5_dag_code.replace("week21_lab5_", "week21_demo5_")
_demo5_src = _demo5_src.replace(
    "week21/student-{STUDENT_ID}/lab5/", f"week21/{_folder}/demo5/"
)

# Upload under this identity's own folder, register, trigger (unpauses first), wait.
s3.put_object(
    Bucket=DAGS_BUCKET,
    Key=f"{DAG_PREFIX}/demo5.py",
    Body=_demo5_src.encode(),
)
print(f"Uploaded demo to s3://{DAGS_BUCKET}/{DAG_PREFIX}/demo5.py")
poll_until_registered(demo5_dag_id)
demo5_run = trigger_dag(demo5_dag_id)   # trigger_dag unpauses first
demo5_state = wait_for_dag(demo5_dag_id, demo5_run)
print(f"Demo 5 finished: {demo5_state} (dag_id={demo5_dag_id})")
print("Open the Airflow UI and find this dag to see the graph + task logs.")
print("Now go build YOUR version in the lab below.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 5: Rewrite Lab 1 with the provider operator (~10 min)
# MAGIC
# MAGIC You will rewrite Lab 1 using `SageMakerTransformOperator` instead of `PythonOperator + boto3 sm_runtime.invoke_endpoint`. The DAG goes from "realtime per-record" to "batch over an S3 file" - the right shape when you are scoring a whole CSV.
# MAGIC
# MAGIC ### Goal
# MAGIC
# MAGIC Build `lab5_dag_code` whose `dag_id` is `week21_lab5_{USER_SLUG}` and shape is:
# MAGIC
# MAGIC ```
# MAGIC build_transform_input >> run_transform >> summarize_results
# MAGIC ```
# MAGIC
# MAGIC - `build_transform_input` writes a one-column CSV of `narrative` text to `s3://bread-academy-shared/week21/participant-NN/lab5/input/input.csv`.
# MAGIC - `run_transform` is a `SageMakerTransformOperator` with `ModelName="fraud-classifier-week19-model"`, S3 input/output, `InstanceType="ml.m5.large"`, `wait_for_completion=True`.
# MAGIC - `summarize_results` reads the output JSONL from `s3://bread-academy-shared/week21/participant-NN/lab5/output/` and prints the fraud rate.
# MAGIC
# MAGIC ### Steps
# MAGIC
# MAGIC 1. Author the DAG, upload via `upload_dag(..., 5, ...)`, poll until registered.
# MAGIC 2. `lab5_run_id = trigger_dag(...)`. Wait for success (the transform job takes ~3-5 minutes; bump `cap_s` in `wait_for_dag` to 1200).
# MAGIC 3. List the output prefix in S3 and set `lab5_output_uri` to one of the result keys.
# MAGIC
# MAGIC ### Final assertions
# MAGIC
# MAGIC - `lab5_run_id` ended in `"success"`.
# MAGIC - `lab5_output_uri` exists in S3 (use `s3.head_object` to verify).
# MAGIC
# MAGIC ### Stretch (in class)
# MAGIC
# MAGIC Change `InstanceType` to `ml.m5.xlarge` in the config. Re-upload, re-trigger. Watch the Airflow task log - the transform finishes faster but costs more per minute. This is a real-world cost-vs-latency knob.
# MAGIC
# MAGIC ### Homework extension
# MAGIC
# MAGIC Write a one-paragraph answer (in your notes) to: "When would I reach for `SageMakerTransformOperator` vs `PythonOperator + boto3 sm_runtime.invoke_endpoint`?" Give three specific examples from a Bread Financial context. Hint: think about batch nightly scoring vs realtime decisioning at the point of sale.
# MAGIC

# COMMAND ----------

# Lab 5 starter. Rewrite Lab 1 with SageMakerTransformOperator.

# (1) Author the DAG source.
lab5_dag_code = None  # YOUR CODE

# (2) Trigger and wait (transform jobs can take 3-5 min; use cap_s=1200).
lab5_run_id = None  # YOUR CODE

# (3) Confirm an output object exists.
lab5_output_uri = None  # YOUR CODE

# Final assertions (uncomment when ready):
# assert lab5_dag_code is not None and "SageMakerTransformOperator" in lab5_dag_code
# assert lab5_run_id is not None
# assert lab5_output_uri and lab5_output_uri.startswith("s3://")
# print("Lab 5 PASS: provider-operator batch transform completed.")


# COMMAND ----------

# Lab 5 SAFETY-NET: run this if you didn't finish Lab 5 so the rest of the
# notebook still works. SKIP this cell if you DID finish Lab 5.

if lab5_run_id is None:
    print("Using Lab 5 safety-net so the rest of the notebook can run.")
    lab5_dag_code = demo_lab5_dag_code
    upload_dag(STUDENT_ID, 5, lab5_dag_code)
    poll_until_registered(f"week21_lab5_{USER_SLUG}")
    lab5_run_id = trigger_dag(f"week21_lab5_{USER_SLUG}")
    state = wait_for_dag(f"week21_lab5_{USER_SLUG}", lab5_run_id, cap_s=1200)
    assert state == "success", f"Lab 5 DAG ended in state {state}"

    objs = s3.list_objects_v2(
        Bucket=SHARED_BUCKET,
        Prefix=f"week21/student-{STUDENT_ID}/lab5/output/",
    ).get("Contents", [])
    assert objs, "Transform output prefix is empty"
    lab5_output_uri = f"s3://{SHARED_BUCKET}/{objs[0]['Key']}"
    print(f"Safety-net Lab 5 PASS: output_uri={lab5_output_uri}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Wrap-up
# MAGIC
# MAGIC ### What we did today
# MAGIC
# MAGIC In one 2-hour session you AUTHORED, UPLOADED, and TRIGGERED five DAGs that exercise the live `fraud-classifier-endpoint`. Every DAG you wrote landed at `s3://bread-academy-airflow-dags/dags/student_{STUDENT_ID}/lab{N}.py` and showed up in the MWAA Airflow UI under a per-student `dag_id`. The author-upload-poll-trigger pattern is now muscle memory.
# MAGIC
# MAGIC ### What is in your toolbox now
# MAGIC
# MAGIC 1. The four-step author-upload-poll-trigger pattern with `s3.put_object` + `mwaa.invoke_rest_api`.
# MAGIC 2. `PythonOperator` chains with `>>`, and the XCom S3-URI rule.
# MAGIC 3. `BranchPythonOperator` plus the `none_failed_min_one_success` join trigger rule that prevents silent join skips.
# MAGIC 4. `ShortCircuitOperator` with `ignore_downstream_trigger_rules=False` plus an `all_done` cleanup task.
# MAGIC 5. `default_args["on_failure_callback"] = [send_sns_notification(...)]` for paging, plus `trigger_rule="none_failed"` for clean fan-in.
# MAGIC 6. `SageMakerTransformOperator` from `apache-airflow-providers-amazon` for batch inference - and the rule of thumb for when to reach for it vs PythonOperator + boto3.
# MAGIC
# MAGIC ### Homework recap
# MAGIC
# MAGIC 1. **Lab 1**: Extend `score_batch` to also write a Parquet copy alongside the JSONL.
# MAGIC 2. **Lab 2**: Turn `decide_route` into a 3-way branch (`low`, `medium`, `high`).
# MAGIC 3. **Lab 3**: Replace the ShortCircuit gate with a `BranchPythonOperator` that has three outcomes (`approve`, `reject`, `pending`).
# MAGIC 4. **Lab 4**: Add `on_failure_callback` to your Lab 1 DAG and reflect on alert-storm risks.
# MAGIC 5. **Lab 5**: Write a paragraph on when to reach for `SageMakerTransformOperator` vs `PythonOperator + boto3 sm_runtime.invoke_endpoint`. Three specific Bread Financial examples.
# MAGIC
# MAGIC ### Next week (Week 22)
# MAGIC
# MAGIC You will close the loop: a single DAG that detects drift, retrains the model, and redeploys the endpoint - all built on top of the same author-upload-poll-trigger muscle you have today. You will use `SageMakerRegisterModelVersionOperator`, the Datasets / data-aware scheduling primitive (covered in the optional notebook for this week), and the same gate pattern from Lab 3.
# MAGIC
# MAGIC ### Reference reading
# MAGIC
# MAGIC - AWS MWAA "Adding or updating DAGs" - the S3 sync contract.
# MAGIC - Astronomer "Best practices for orchestrating MLOps pipelines with Airflow".
# MAGIC - Apache Airflow stable REST API reference - `/dags/{dag_id}` and `/dags/{dag_id}/dagRuns`.
# MAGIC - `apache-airflow-providers-amazon` 9.0.0 SageMaker operator catalog.
# MAGIC