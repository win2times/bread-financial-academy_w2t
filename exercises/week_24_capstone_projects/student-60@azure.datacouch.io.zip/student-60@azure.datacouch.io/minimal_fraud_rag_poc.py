# Databricks notebook source
# MAGIC %md
# MAGIC # Minimal Fraud Detection with RAG POC
# MAGIC
# MAGIC This notebook builds a **single-notebook** fraud detection proof of concept with a small local rules knowledge base, in-memory retrieval, lightweight scoring, classifier-then-escalate triage, and an optional LLM-style decision step.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Notebook Section Outline
# MAGIC
# MAGIC 1. Goal and architecture
# MAGIC 2. Minimal setup
# MAGIC 3. Simulated transaction stream
# MAGIC 4. Local fraud rules knowledge base
# MAGIC 5. In-memory retrieval and retrieval quality
# MAGIC 6. Heuristic classifier and triage
# MAGIC 7. Agent-style escalation
# MAGIC 8. End-to-end transaction processing
# MAGIC 9. Batch simulation and alerts
# MAGIC 10. SageMaker / Databricks run notes

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Goal and architecture
# MAGIC
# MAGIC We keep the POC intentionally small:
# MAGIC
# MAGIC - Everything runs in notebook cells.
# MAGIC - No vector DB, no external services, no project scaffolding.
# MAGIC - Fraud rules live in Python data structures.
# MAGIC - Retrieval is local and in memory.
# MAGIC - A fast heuristic classifier handles obvious cases.
# MAGIC - Borderline or suspicious cases escalate to an agent-style decision function.
# MAGIC - An optional LLM hook can be enabled later, but the default path makes no outside-world calls.
# MAGIC
# MAGIC Design ideas reused and simplified from the course materials:
# MAGIC
# MAGIC - Tool-based agent flow.
# MAGIC - Retrieval as a callable tool rather than a fixed one-shot step.
# MAGIC - Retrieval quality inspection.
# MAGIC - Cheap classifier first, escalate only when needed.

# COMMAND ----------

# Minimal dependencies: Python standard library only.
# Optional: pandas is used only for prettier result display if available.

import math
import random
import re
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from pprint import pprint
from typing import List, Dict, Any, Tuple

try:
    import pandas as pd
except Exception:
    pd = None

random.seed(42)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Minimal setup
# MAGIC
# MAGIC This notebook is designed to run as-is in SageMaker Studio or Databricks with default Python support.

# COMMAND ----------

APPROVE = "approve"
REVIEW = "review"
BLOCK = "block"

RISK_APPROVE_MAX = 29
RISK_REVIEW_MAX = 69
ESCALATE_REVIEW_MIN = 45
ESCALATE_BLOCK_MIN = 75

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Simulated transaction stream
# MAGIC
# MAGIC We simulate near-real-time transactions with a small customer profile table and synthetic events.

# COMMAND ----------

CUSTOMERS = {
    "C001": {
        "home_country": "US",
        "home_state": "OH",
        "avg_amount": 65.0,
        "active_hours": (7, 22),
        "usual_mcc": {"grocery", "streaming", "fuel", "retail", "restaurant"},
        "known_devices": {"ios_1", "web_1"},
    },
    "C002": {
        "home_country": "US",
        "home_state": "CA",
        "avg_amount": 180.0,
        "active_hours": (6, 23),
        "usual_mcc": {"travel", "retail", "restaurant", "electronics"},
        "known_devices": {"android_7", "web_9"},
    },
    "C003": {
        "home_country": "US",
        "home_state": "TX",
        "avg_amount": 40.0,
        "active_hours": (8, 21),
        "usual_mcc": {"grocery", "fuel", "discount", "pharmacy"},
        "known_devices": {"ios_3"},
    },
}


def make_txn(txn_id, customer_id, amount, merchant, mcc, country, state, hour, device_id,
             channel="card_present", velocity_1h=1, chargebacks_90d=0, ip_risk=False,
             shipping_mismatch=False, new_payee=False):
    return {
        "txn_id": txn_id,
        "event_time": f"2026-05-23T{hour:02d}:00:00",
        "customer_id": customer_id,
        "amount": float(amount),
        "merchant": merchant,
        "mcc": mcc,
        "country": country,
        "state": state,
        "hour": int(hour),
        "device_id": device_id,
        "channel": channel,
        "velocity_1h": int(velocity_1h),
        "chargebacks_90d": int(chargebacks_90d),
        "ip_risk": bool(ip_risk),
        "shipping_mismatch": bool(shipping_mismatch),
        "new_payee": bool(new_payee),
        "description": f"{channel} transaction at {merchant} in {country}/{state} for ${amount:.2f}",
    }

TRANSACTIONS = [
    make_txn("T001", "C001", 12.99, "StreamFlix", "streaming", "US", "OH", 19, "ios_1"),
    make_txn("T002", "C001", 23.10, "QuickFuel", "fuel", "US", "OH", 8, "ios_1"),
    make_txn("T003", "C001", 980.00, "LuxuryHub", "luxury", "US", "FL", 3, "android_new", channel="card_not_present", velocity_1h=4, ip_risk=True, shipping_mismatch=True),
    make_txn("T004", "C002", 220.00, "SkyFly", "travel", "US", "CA", 14, "web_9"),
    make_txn("T005", "C002", 6200.00, "WireFast", "wire", "GB", "LN", 2, "web_new", channel="wire", velocity_1h=1, ip_risk=True, new_payee=True),
    make_txn("T006", "C003", 9.25, "BudgetMart", "discount", "US", "TX", 17, "ios_3"),
    make_txn("T007", "C003", 499.99, "GizmoWorld", "electronics", "US", "NV", 1, "ios_unknown", channel="card_not_present", velocity_1h=6, ip_risk=True, shipping_mismatch=True),
    make_txn("T008", "C001", 44.00, "FreshFoods", "grocery", "US", "OH", 18, "web_1"),
]

TRANSACTIONS[:2]

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Local fraud rules knowledge base
# MAGIC
# MAGIC Rules are stored directly in notebook memory as compact documents with tags and action guidance.

# COMMAND ----------

RULES = [
    {
        "rule_id": "R1",
        "title": "High amount anomaly",
        "text": "Escalate when amount is far above customer baseline, especially above 5x average spend.",
        "tags": ["amount", "anomaly", "baseline"],
        "severity": 20,
        "action_hint": REVIEW,
    },
    {
        "rule_id": "R2",
        "title": "Unusual hour activity",
        "text": "Increase risk for transactions outside the customer's normal active hours, especially overnight.",
        "tags": ["hour", "overnight", "behavior"],
        "severity": 10,
        "action_hint": REVIEW,
    },
    {
        "rule_id": "R3",
        "title": "New device with mismatch",
        "text": "Block or review when a new device appears together with shipping mismatch or IP risk signals.",
        "tags": ["device", "ip", "shipping", "mismatch"],
        "severity": 25,
        "action_hint": BLOCK,
    },
    {
        "rule_id": "R4",
        "title": "High velocity spending",
        "text": "Rapid transaction bursts in one hour suggest takeover or card testing.",
        "tags": ["velocity", "card testing", "takeover"],
        "severity": 20,
        "action_hint": REVIEW,
    },
    {
        "rule_id": "R5",
        "title": "Cross-border wire risk",
        "text": "International wire transfers to new payees or unusual geographies require strong review and may be blocked.",
        "tags": ["wire", "international", "new payee", "cross-border"],
        "severity": 30,
        "action_hint": BLOCK,
    },
    {
        "rule_id": "R6",
        "title": "High-risk merchant category",
        "text": "Electronics, luxury goods, and cash-like or wire categories carry elevated fraud risk when behavior is unusual.",
        "tags": ["mcc", "electronics", "luxury", "wire"],
        "severity": 15,
        "action_hint": REVIEW,
    },
    {
        "rule_id": "R7",
        "title": "Known good recurring behavior",
        "text": "Recurring low-dollar spend on known device and usual merchant category can reduce risk.",
        "tags": ["recurring", "low dollar", "known device", "usual behavior"],
        "severity": -10,
        "action_hint": APPROVE,
    },
]

len(RULES)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. In-memory retrieval and retrieval quality
# MAGIC
# MAGIC We use a tiny lexical retriever. It is enough for a notebook demo and makes retrieval behavior easy to inspect.

# COMMAND ----------

STOPWORDS = {
    "the", "a", "an", "and", "or", "to", "of", "for", "with", "when", "is", "be", "on",
    "in", "at", "by", "from", "up", "new", "can"
}


def tokenize(text: str) -> List[str]:
    terms = re.findall(r"[a-zA-Z_]+", text.lower())
    return [t for t in terms if t not in STOPWORDS and len(t) > 2]


def build_query_from_txn(txn: Dict[str, Any], customer: Dict[str, Any]) -> str:
    features = [txn["mcc"], txn["channel"], txn["country"].lower(), txn["state"].lower()]
    if txn["amount"] > customer["avg_amount"] * 3:
        features += ["amount", "anomaly", "baseline"]
    if txn["hour"] < customer["active_hours"][0] or txn["hour"] > customer["active_hours"][1]:
        features += ["overnight", "hour", "behavior"]
    if txn["device_id"] not in customer["known_devices"]:
        features += ["device"]
    if txn["velocity_1h"] >= 4:
        features += ["velocity", "takeover"]
    if txn["ip_risk"]:
        features += ["ip"]
    if txn["shipping_mismatch"]:
        features += ["shipping", "mismatch"]
    if txn["new_payee"]:
        features += ["new", "payee"]
    return " ".join(features)


def retrieve_rules(query: str, rules: List[Dict[str, Any]], top_k: int = 3) -> List[Dict[str, Any]]:
    q = set(tokenize(query))
    scored = []
    for rule in rules:
        doc_terms = set(tokenize(rule["title"] + " " + rule["text"] + " " + " ".join(rule["tags"])))
        overlap = len(q & doc_terms)
        score = overlap / max(len(q), 1)
        scored.append({**rule, "retrieval_score": round(score, 3), "matched_terms": sorted(q & doc_terms)})
    scored.sort(key=lambda x: (x["retrieval_score"], x["severity"]), reverse=True)
    return [r for r in scored if r["retrieval_score"] > 0][:top_k]


def retrieval_quality(retrieved: List[Dict[str, Any]], min_score: float = 0.15) -> Dict[str, Any]:
    if not retrieved:
        return {"good": False, "reason": "no_rules", "avg_score": 0.0}
    avg_score = sum(r["retrieval_score"] for r in retrieved) / len(retrieved)
    return {
        "good": avg_score >= min_score,
        "reason": "ok" if avg_score >= min_score else "weak_match",
        "avg_score": round(avg_score, 3),
    }

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Heuristic classifier and triage
# MAGIC
# MAGIC This is the cheap first-pass stage. It mirrors the classifier-then-escalate pattern but keeps the classifier fully local.

# COMMAND ----------

HIGH_RISK_MCC = {"luxury", "electronics", "wire"}


def score_transaction(txn: Dict[str, Any], customer: Dict[str, Any], retrieved_rules: List[Dict[str, Any]]) -> Tuple[int, List[str]]:
    score = 0
    reasons = []

    amount_ratio = txn["amount"] / max(customer["avg_amount"], 1)
    if amount_ratio >= 5:
        score += 30
        reasons.append(f"amount is {amount_ratio:.1f}x customer baseline")
    elif amount_ratio >= 3:
        score += 18
        reasons.append(f"amount is {amount_ratio:.1f}x customer baseline")

    if txn["hour"] < customer["active_hours"][0] or txn["hour"] > customer["active_hours"][1]:
        score += 12
        reasons.append("transaction occurred outside normal active hours")

    if txn["device_id"] not in customer["known_devices"]:
        score += 15
        reasons.append("new or unseen device")

    if txn["velocity_1h"] >= 5:
        score += 20
        reasons.append("high one-hour transaction velocity")
    elif txn["velocity_1h"] >= 3:
        score += 10
        reasons.append("elevated one-hour transaction velocity")

    if txn["country"] != customer["home_country"]:
        score += 20
        reasons.append("cross-border transaction")

    if txn["ip_risk"]:
        score += 12
        reasons.append("IP or network risk signal present")

    if txn["shipping_mismatch"]:
        score += 15
        reasons.append("shipping mismatch")

    if txn["new_payee"]:
        score += 18
        reasons.append("new payee")

    if txn["mcc"] in HIGH_RISK_MCC:
        score += 10
        reasons.append(f"high-risk MCC: {txn['mcc']}")

    score += sum(r["severity"] for r in retrieved_rules)
    if retrieved_rules:
        reasons.append("retrieved fraud rules increased confidence in the pattern match")

    score = max(0, min(100, score))
    return score, reasons


def initial_triage(score: int) -> str:
    if score <= RISK_APPROVE_MAX:
        return APPROVE
    if score <= RISK_REVIEW_MAX:
        return REVIEW
    return BLOCK

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Agent-style escalation
# MAGIC
# MAGIC Instead of a full framework, we use a small tool-based loop inside one function. This keeps the demo close to an agent pattern while staying notebook-friendly.

# COMMAND ----------

TOOLS = {}


def tool(fn):
    TOOLS[fn.__name__] = fn
    return fn


@tool
def lookup_customer(customer_id: str) -> Dict[str, Any]:
    return CUSTOMERS[customer_id]


@tool
def retrieve_fraud_rules(query: str) -> List[Dict[str, Any]]:
    return retrieve_rules(query, RULES, top_k=3)


@tool
def evaluate_retrieval(retrieved_rules: List[Dict[str, Any]]) -> Dict[str, Any]:
    return retrieval_quality(retrieved_rules)


@tool
def heuristic_score(txn: Dict[str, Any], customer: Dict[str, Any], retrieved_rules: List[Dict[str, Any]]) -> Dict[str, Any]:
    score, reasons = score_transaction(txn, customer, retrieved_rules)
    return {"risk_score": score, "reasons": reasons, "initial_decision": initial_triage(score)}


@tool
def optional_llm_decision(prompt: str = "") -> Dict[str, Any]:
    return {
        "used": False,
        "note": "Optional LLM step disabled by default. Local deterministic fallback used instead."
    }


def local_agent_decision(txn: Dict[str, Any], base_result: Dict[str, Any], retrieved_rules: List[Dict[str, Any]]) -> Dict[str, Any]:
    score = base_result["risk_score"]
    reasons = list(base_result["reasons"])
    triggered_rules = [r["rule_id"] for r in retrieved_rules]

    decision = base_result["initial_decision"]

    if score >= ESCALATE_BLOCK_MIN and (txn["ip_risk"] or txn["shipping_mismatch"] or txn["new_payee"]):
        decision = BLOCK
        reasons.append("agent escalation confirmed strong combined risk signals")
    elif score >= ESCALATE_REVIEW_MIN:
        decision = REVIEW
        reasons.append("agent escalation requested manual review for borderline or compound risk")
    else:
        decision = APPROVE
        reasons.append("agent escalation found low residual risk")

    return {
        "decision": decision,
        "risk_score": score,
        "reason": "; ".join(reasons[:5]),
        "triggered_rules": triggered_rules,
        "retrieval_used": True,
    }

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. End-to-end transaction processing
# MAGIC
# MAGIC This function runs the whole flow: build query, retrieve rules, check retrieval quality, score, triage, escalate if needed, and emit an alert.

# COMMAND ----------

def process_transaction(txn: Dict[str, Any], use_optional_llm: bool = False) -> Dict[str, Any]:
    customer = lookup_customer(txn["customer_id"])
    query = build_query_from_txn(txn, customer)
    retrieved = retrieve_fraud_rules(query)
    retrieval_eval = evaluate_retrieval(retrieved)
    base = heuristic_score(txn, customer, retrieved)

    needs_escalation = (
        base["initial_decision"] != APPROVE
        or retrieval_eval["reason"] == "weak_match"
        or base["risk_score"] >= ESCALATE_REVIEW_MIN
    )

    if needs_escalation:
        agent_result = local_agent_decision(txn, base, retrieved)
        llm_result = optional_llm_decision() if use_optional_llm else {"used": False}
        final_decision = agent_result["decision"]
        final_reason = agent_result["reason"]
        triggered_rules = agent_result["triggered_rules"]
    else:
        llm_result = {"used": False}
        final_decision = base["initial_decision"]
        final_reason = "; ".join(base["reasons"][:4]) if base["reasons"] else "low observed risk"
        triggered_rules = [r["rule_id"] for r in retrieved]

    alert = {
        "txn_id": txn["txn_id"],
        "customer_id": txn["customer_id"],
        "decision": final_decision,
        "risk_score": base["risk_score"],
        "reason": final_reason,
        "triggered_rules": triggered_rules,
        "retrieval_query": query,
        "retrieval_quality": retrieval_eval,
        "retrieved_rule_titles": [r["title"] for r in retrieved],
        "llm_step": llm_result,
    }
    return alert


single_alert = process_transaction(TRANSACTIONS[2])
pprint(single_alert)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Batch simulation and alerts
# MAGIC
# MAGIC We now run the POC over a simulated stream and produce approve/review/block decisions plus compact alert records.

# COMMAND ----------

results = [process_transaction(txn) for txn in TRANSACTIONS]

if pd is not None:
    df = pd.DataFrame(results)
    display(df[["txn_id", "customer_id", "decision", "risk_score", "triggered_rules", "reason"]])
else:
    pprint(results)

# COMMAND ----------

summary = {}
for r in results:
    summary[r["decision"]] = summary.get(r["decision"], 0) + 1
summary

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Example real-time loop
# MAGIC
# MAGIC This small loop demonstrates how the notebook can process events one at a time, similar to a streaming consumer.

# COMMAND ----------

for txn in TRANSACTIONS[:3]:
    alert = process_transaction(txn)
    print(f"[{txn['txn_id']}] decision={alert['decision']:<7} risk={alert['risk_score']:<3} rules={alert['triggered_rules']}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 11. What to customize next
# MAGIC
# MAGIC Easy extensions that still keep the notebook small:
# MAGIC
# MAGIC - Add more rules or richer customer history.
# MAGIC - Replace lexical retrieval with TF-IDF or embeddings later.
# MAGIC - Swap the heuristic classifier for a local model.
# MAGIC - Turn on an optional LLM only for REVIEW cases.
# MAGIC - Log alerts to Delta, Parquet, or a feature store.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 12. Running in SageMaker or Databricks
# MAGIC
# MAGIC ### SageMaker Studio
# MAGIC
# MAGIC - Create a new notebook with a standard Python image.
# MAGIC - Paste or upload this `.ipynb` file.
# MAGIC - Run all cells top to bottom.
# MAGIC - No AWS service calls are required for the default path.
# MAGIC
# MAGIC ### Databricks
# MAGIC
# MAGIC - Import the notebook file into a workspace.
# MAGIC - Attach a standard cluster with Python support.
# MAGIC - Run all cells.
# MAGIC - The notebook uses only standard-library code by default, so no extra cluster libraries are required.
# MAGIC
# MAGIC ### Optional LLM step
# MAGIC
# MAGIC - Leave `use_optional_llm=False` for a fully local demo.
# MAGIC - If you later wire in an LLM, keep it only in the escalation branch.