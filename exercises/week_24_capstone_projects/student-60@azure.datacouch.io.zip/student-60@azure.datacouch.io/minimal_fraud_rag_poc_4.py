# Databricks notebook source
# MAGIC %md
# MAGIC # Fraud Detection with Agentic RAG POC v4
# MAGIC
# MAGIC This notebook refactors `fraud_rag_poc_1.ipynb` to use the same **Agent + LLM + vector database** ideas used in `week_17_rag_fundamentals.ipynb` where they fit the fraud use case.
# MAGIC
# MAGIC ## What changed
# MAGIC
# MAGIC 1. The original synthetic fraud transactions and risk scoring remain.
# MAGIC 2. The in-memory lexical retriever is replaced with a FAISS-backed vector store over fraud rules.
# MAGIC 3. A shared Bedrock LLM is configured with `BedrockModel`, following the Week 17 Strands pattern.
# MAGIC 4. Retrieval and scoring are wrapped as Strands tools, and specialist agents plus a lightweight supervisor are added.
# MAGIC 5. The deterministic batch-processing path still works, so the notebook stays easy to teach and debug.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Environment setup for Databricks + AWS
# MAGIC
# MAGIC This keeps the Databricks secret-scope pattern from v1 while importing the Strands classes used in Week 17.
# MAGIC

# COMMAND ----------

# MAGIC %pip install --quiet "boto3>=1.35" "sagemaker>=2.230,<3" "sagemaker-mlflow>=0.1.0" "mlflow>=2.13" "strands-agents>=1.37,<2" "strands-agents-tools>=0.2.10" "faiss-cpu>=1.9,<2" "numpy<2" "langchain-aws>=0.2"
# MAGIC
# MAGIC import os
# MAGIC import re
# MAGIC import json
# MAGIC import random
# MAGIC from pprint import pprint
# MAGIC from typing import List, Dict, Any, Tuple
# MAGIC from importlib.metadata import version
# MAGIC
# MAGIC import boto3
# MAGIC import numpy as np
# MAGIC import faiss
# MAGIC
# MAGIC try:
# MAGIC     import pandas as pd
# MAGIC except Exception:
# MAGIC     pd = None
# MAGIC
# MAGIC from strands import Agent, tool
# MAGIC from strands.models import BedrockModel
# MAGIC
# MAGIC for pkg in ["boto3", "sagemaker", "mlflow", "sagemaker-mlflow", "strands-agents", "strands-agents-tools", "faiss-cpu", "numpy"]:
# MAGIC     try:
# MAGIC         print(f"{pkg:28s} {version(pkg)}")
# MAGIC     except Exception as e:
# MAGIC         print(f"{pkg:28s} NOT INSTALLED ({e})")
# MAGIC
# MAGIC random.seed(42)
# MAGIC np.random.seed(42)
# MAGIC

# COMMAND ----------

# Per-student AWS keys live in aws-course-creds-NN; class-wide config is in
# aws-course-shared. Derive this student's scope from the Databricks identity.
_user = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook().getContext().userName().get()
)
_num = _user.split("@")[0].split("-")[1] if _user.startswith("student-") else "01"
creds_scope = f"aws-course-creds-{_num}"

AWS_ACCESS_KEY_ID = dbutils.secrets.get(scope=creds_scope, key="aws-access-key-id")
AWS_SECRET_ACCESS_KEY = dbutils.secrets.get(scope=creds_scope, key="aws-secret-access-key")
AWS_REGION = "us-east-1"

# These course credentials are long-lived IAM keys, so there is no session
# token. (The previous version assigned the region string to the session
# token, which made Bedrock reject every request with
# UnrecognizedClientException: "The security token included is invalid".)
# If your scope instead holds *temporary* STS creds, fetch the real token:
#     AWS_SESSION_TOKEN = dbutils.secrets.get(scope=creds_scope, key="aws-session-token")
AWS_SESSION_TOKEN = None

# SAGEMAKER_ROLE_ARN = dbutils.secrets.get(scope="aws-course-creds", key="sagemaker-execution-role-arn")
# MLFLOW_TRACKING_ARN = dbutils.secrets.get(scope="aws-course-creds", key="mlflow-tracking-server-arn")

os.environ["AWS_ACCESS_KEY_ID"] = AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = AWS_SECRET_ACCESS_KEY
os.environ["AWS_REGION"] = AWS_REGION
os.environ["AWS_DEFAULT_REGION"] = AWS_REGION
if AWS_SESSION_TOKEN:
    os.environ["AWS_SESSION_TOKEN"] = AWS_SESSION_TOKEN
else:
    # Clear any stale token left in the environment by an earlier run.
    os.environ.pop("AWS_SESSION_TOKEN", None)

session = boto3.Session(
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    aws_session_token=AWS_SESSION_TOKEN,
    region_name=AWS_REGION,
)
s3_client = session.client("s3")
sagemaker_client = session.client("sagemaker")
sagemaker_runtime = session.client("sagemaker-runtime")
sts_client = session.client("sts")
bedrock_client = session.client("bedrock")
bedrock_runtime = session.client("bedrock-runtime")

# Fail fast with a clear message if the credentials are not valid.
try:
    _ident = sts_client.get_caller_identity()
    print("Caller identity OK:", _ident["Arn"])
except Exception as e:
    print("WARNING: AWS credentials are not valid:", e)
    print("Check the access key / secret (and session token if using temporary creds).")


# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Shared AWS resource configuration
# MAGIC

# COMMAND ----------

S3_BUCKET = "bread-academy-week19-shared"

# get_caller_identity() depends on valid AWS credentials. If it is not yet
# configured, fall back to a stable prefix so the deterministic fraud path
# (which does not need AWS) can still run end-to-end.
try:
    _caller_id = sts_client.get_caller_identity()["UserId"][:8]
except Exception as e:
    print(f"STS get_caller_identity failed ({e}); using fallback prefix.")
    _caller_id = "local-dev"

S3_PREFIX = f"students/{_caller_id}/fraud-rag-poc"
ARTIFACTS_S3 = f"s3://{S3_BUCKET}/{S3_PREFIX}/artifacts"
RESULTS_S3 = f"s3://{S3_BUCKET}/{S3_PREFIX}/results"

try:
    s3_client.head_bucket(Bucket=S3_BUCKET)
    print(f"S3 OK: s3://{S3_BUCKET}")
except Exception as e:
    # Warn but do not raise: the deterministic vector-RAG flow does not use S3.
    print(f"S3 FAIL: {e}")
    print(f"Ask your instructor to grant access to {S3_BUCKET}.")

print(f"Artifacts prefix: {ARTIFACTS_S3}")
print(f"Results prefix: {RESULTS_S3}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Bedrock LLM setup
# MAGIC
# MAGIC This follows the Week 17 pattern: define a shared Bedrock model once and reuse it across agents.
# MAGIC

# COMMAND ----------

MODEL_ID = os.environ.get("FRAUD_AGENT_MODEL_ID", "us.anthropic.claude-sonnet-4-5-20250929-v1:0")
EMBED_MODEL_ID = os.environ.get("FRAUD_EMBED_MODEL_ID", "local-faiss-hash-embeddings")

llm = BedrockModel(model_id=MODEL_ID, region_name=AWS_REGION)

try:
    probe = bedrock_runtime.converse(
        modelId=MODEL_ID,
        messages=[{"role": "user", "content": [{"text": "ping"}]}],
        inferenceConfig={"maxTokens": 10, "temperature": 0},
    )
    print("LLM probe OK:", probe["output"]["message"]["content"][0]["text"])
except Exception as e:
    print("LLM probe failed:", e)
    print("The deterministic vector-RAG fraud path can still run without the optional agent demos.")

print("Agent LLM:", MODEL_ID)
print("Vector store:", EMBED_MODEL_ID)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Fraud triage constants
# MAGIC

# COMMAND ----------

APPROVE = "approve"
REVIEW = "review"
BLOCK = "block"

RISK_APPROVE_MAX = 29
RISK_REVIEW_MAX = 69
ESCALATE_REVIEW_MIN = 45
ESCALATE_BLOCK_MIN = 75


# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Simulated transaction stream
# MAGIC

# COMMAND ----------

CUSTOMERS = {
    "C001": {"home_country": "US", "home_state": "OH", "avg_amount": 65.0, "active_hours": (7, 22), "usual_mcc": {"grocery", "streaming", "fuel", "retail", "restaurant"}, "known_devices": {"ios_1", "web_1"}},
    "C002": {"home_country": "US", "home_state": "CA", "avg_amount": 180.0, "active_hours": (6, 23), "usual_mcc": {"travel", "retail", "restaurant", "electronics"}, "known_devices": {"android_7", "web_9"}},
    "C003": {"home_country": "US", "home_state": "TX", "avg_amount": 40.0, "active_hours": (8, 21), "usual_mcc": {"grocery", "fuel", "discount", "pharmacy"}, "known_devices": {"ios_3"}},
}

def make_txn(txn_id, customer_id, amount, merchant, mcc, country, state, hour, device_id, channel="card_present", velocity_1h=1, chargebacks_90d=0, ip_risk=False, shipping_mismatch=False, new_payee=False):
    return {
        "txn_id": txn_id, "event_time": f"2026-05-23T{hour:02d}:00:00", "customer_id": customer_id,
        "amount": float(amount), "merchant": merchant, "mcc": mcc, "country": country, "state": state,
        "hour": int(hour), "device_id": device_id, "channel": channel, "velocity_1h": int(velocity_1h),
        "chargebacks_90d": int(chargebacks_90d), "ip_risk": bool(ip_risk), "shipping_mismatch": bool(shipping_mismatch),
        "new_payee": bool(new_payee), "description": f"{channel} transaction at {merchant} in {country}/{state} for ${amount:.2f}",
    }

TRANSACTIONS = [
    make_txn("T001", "C001", 12.99, "StreamFlix", "streaming", "US", "OH", 19, "ios_1"),
    make_txn("T002", "C001", 23.10, "QuickFuel", "fuel", "US", "OH", 8, "ios_1"),
    make_txn("T003", "C001", 980.00, "LuxuryHub", "luxury", "US", "FL", 3, "android_new", channel="card_not_present", velocity_1h=4, ip_risk=True, shipping_mismatch=True),
    make_txn("T004", "C002", 220.00, "SkyFly", "travel", "US", "CA", 14, "web_9"),
    make_txn("T005", "C002", 6200.00, "WireFast", "wire", "GB", "LN", 2, "web_new", channel="wire", velocity_1h=1, ip_risk=True, new_payee=True),
    make_txn("T006", "C003", 9.25, "BudgetMart", "discount", "US", "TX", 17, "ios_3"),
    make_txn("T007", "C003", 499.99, "GizmoWorld", "electronics", "US", "NV", 1, "ios_unknown", channel="card_not_present", velocity_1h=6, ip_risk=True, shipping_mismatch=True),
    make_txn("T008", "C001", 44.00, "FreshFoods", "grocery", "US", "OH", 18, "web_1"),
]

TRANSACTIONS[:2]


# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Fraud rules knowledge base
# MAGIC
# MAGIC The rule content still lives in the notebook, but it is now indexed into a vector database so retrieval matches the Week 17 architecture more closely.
# MAGIC

# COMMAND ----------

RULES = [
    {"rule_id": "R1", "title": "High amount anomaly", "text": "Escalate when amount is far above customer baseline, especially above 5x average spend.", "tags": ["amount", "anomaly", "baseline"], "severity": 20, "action_hint": REVIEW},
    {"rule_id": "R2", "title": "Unusual hour activity", "text": "Increase risk for transactions outside the customer's normal active hours, especially overnight.", "tags": ["hour", "overnight", "behavior"], "severity": 10, "action_hint": REVIEW},
    {"rule_id": "R3", "title": "New device with mismatch", "text": "Block or review when a new device appears together with shipping mismatch or IP risk signals.", "tags": ["device", "ip", "shipping", "mismatch"], "severity": 25, "action_hint": BLOCK},
    {"rule_id": "R4", "title": "High velocity spending", "text": "Rapid transaction bursts in one hour suggest takeover or card testing.", "tags": ["velocity", "card testing", "takeover"], "severity": 20, "action_hint": REVIEW},
    {"rule_id": "R5", "title": "Cross-border wire risk", "text": "International wire transfers to new payees or unusual geographies require strong review and may be blocked.", "tags": ["wire", "international", "new payee", "cross-border"], "severity": 30, "action_hint": BLOCK},
    {"rule_id": "R6", "title": "High-risk merchant category", "text": "Electronics, luxury goods, and cash-like or wire categories carry elevated fraud risk when behavior is unusual.", "tags": ["mcc", "electronics", "luxury", "wire"], "severity": 15, "action_hint": REVIEW},
    {"rule_id": "R7", "title": "Known good recurring behavior", "text": "Recurring low-dollar spend on known device and usual merchant category can reduce risk.", "tags": ["recurring", "low dollar", "known device", "usual behavior"], "severity": -10, "action_hint": APPROVE},
]

len(RULES)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Build the vector database
# MAGIC
# MAGIC Week 17 uses vector retrieval through Bedrock KBs and FAISS-backed memory. Here we use a notebook-local FAISS index over the fraud rule corpus, which is the simplest fit for this POC.
# MAGIC

# COMMAND ----------

import hashlib

STOPWORDS = {"the", "a", "an", "and", "or", "to", "of", "for", "with", "when", "is", "be", "on", "in", "at", "by", "from", "up", "new", "can"}

def tokenize(text: str) -> List[str]:
    terms = re.findall(r"[a-zA-Z_]+", text.lower())
    return [t for t in terms if t not in STOPWORDS and len(t) > 2]

def _stable_hash(term: str) -> int:
    # Python's builtin hash() is salted per process (PYTHONHASHSEED), so the
    # embeddings would change across kernel restarts. Use a deterministic hash
    # so indexing and querying are reproducible run to run.
    return int.from_bytes(hashlib.md5(term.encode("utf-8")).digest()[:8], "little")

def hash_embed(text: str, dim: int = 256) -> np.ndarray:
    vec = np.zeros(dim, dtype="float32")
    for term in tokenize(text):
        vec[_stable_hash(term) % dim] += 1.0
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec /= norm
    return vec

def rule_document(rule: Dict[str, Any]) -> str:
    return " ".join([rule["rule_id"], rule["title"], rule["text"], " ".join(rule["tags"]), rule["action_hint"]])

RULE_DOCS = [rule_document(rule) for rule in RULES]
RULE_EMBEDDINGS = np.vstack([hash_embed(doc) for doc in RULE_DOCS]).astype("float32")
RULE_INDEX = faiss.IndexFlatIP(RULE_EMBEDDINGS.shape[1])
RULE_INDEX.add(RULE_EMBEDDINGS)

print(f"Indexed {RULE_INDEX.ntotal} fraud rules into local FAISS vector store.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Retrieval helpers
# MAGIC

# COMMAND ----------

def build_query_from_txn(txn: Dict[str, Any], customer: Dict[str, Any]) -> str:
    features = [txn["mcc"], txn["channel"], txn["country"].lower(), txn["state"].lower()]
    if txn["amount"] > customer["avg_amount"] * 3:
        features += ["amount", "anomaly", "baseline"]
    if txn["hour"] < customer["active_hours"][0] or txn["hour"] > customer["active_hours"][1]:
        features += ["overnight", "hour", "behavior"]
    if txn["device_id"] not in customer["known_devices"]:
        features += ["device"]
    if txn["velocity_1h"] >= 4:
        features += ["velocity", "takeover"]
    if txn["ip_risk"]:
        features += ["ip"]
    if txn["shipping_mismatch"]:
        features += ["shipping", "mismatch"]
    if txn["new_payee"]:
        features += ["new", "payee"]
    return " ".join(features)

def retrieve_rules_vector(query: str, top_k: int = 3) -> List[Dict[str, Any]]:
    q = hash_embed(query).reshape(1, -1)
    scores, idxs = RULE_INDEX.search(q, min(top_k, len(RULES)))
    results = []
    for score, idx in zip(scores[0], idxs[0]):
        if idx < 0:
            continue
        rule = dict(RULES[idx])
        rule["retrieval_score"] = round(float(score), 3)
        rule["matched_terms"] = sorted(set(tokenize(query)) & set(tokenize(RULE_DOCS[idx])))
        results.append(rule)
    return [r for r in results if r["retrieval_score"] > 0]

def retrieval_quality(retrieved: List[Dict[str, Any]], min_score: float = 0.18) -> Dict[str, Any]:
    if not retrieved:
        return {"good": False, "reason": "no_rules", "avg_score": 0.0}
    avg_score = sum(r["retrieval_score"] for r in retrieved) / len(retrieved)
    return {"good": avg_score >= min_score, "reason": "ok" if avg_score >= min_score else "weak_match", "avg_score": round(avg_score, 3)}

sample_query = build_query_from_txn(TRANSACTIONS[2], CUSTOMERS[TRANSACTIONS[2]["customer_id"]])
retrieve_rules_vector(sample_query)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Heuristic scorer
# MAGIC

# COMMAND ----------

HIGH_RISK_MCC = {"luxury", "electronics", "wire"}

def score_transaction(txn: Dict[str, Any], customer: Dict[str, Any], retrieved_rules: List[Dict[str, Any]]) -> Tuple[int, List[str]]:
    score = 0
    reasons = []
    amount_ratio = txn["amount"] / max(customer["avg_amount"], 1)
    if amount_ratio >= 5:
        score += 30
        reasons.append(f"amount is {amount_ratio:.1f}x customer baseline")
    elif amount_ratio >= 3:
        score += 18
        reasons.append(f"amount is {amount_ratio:.1f}x customer baseline")
    if txn["hour"] < customer["active_hours"][0] or txn["hour"] > customer["active_hours"][1]:
        score += 12
        reasons.append("transaction occurred outside normal active hours")
    if txn["device_id"] not in customer["known_devices"]:
        score += 15
        reasons.append("new or unseen device")
    if txn["velocity_1h"] >= 5:
        score += 20
        reasons.append("high one-hour transaction velocity")
    elif txn["velocity_1h"] >= 3:
        score += 10
        reasons.append("elevated one-hour transaction velocity")
    if txn["country"] != customer["home_country"]:
        score += 20
        reasons.append("cross-border transaction")
    if txn["ip_risk"]:
        score += 12
        reasons.append("IP or network risk signal present")
    if txn["shipping_mismatch"]:
        score += 15
        reasons.append("shipping mismatch")
    if txn["new_payee"]:
        score += 18
        reasons.append("new payee")
    if txn["mcc"] in HIGH_RISK_MCC:
        score += 10
        reasons.append(f"high-risk MCC: {txn['mcc']}")
    score += sum(r["severity"] for r in retrieved_rules)
    if retrieved_rules:
        reasons.append("retrieved fraud rules increased confidence in the pattern match")
    score = max(0, min(100, score))
    return score, reasons

def initial_triage(score: int) -> str:
    if score <= RISK_APPROVE_MAX:
        return APPROVE
    if score <= RISK_REVIEW_MAX:
        return REVIEW
    return BLOCK


# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Strands tools and specialist agents
# MAGIC
# MAGIC This is the main Week 17-style refactor: retrieval and scoring helpers become tools, and those tools are grouped into specialist agents plus a supervisor.
# MAGIC

# COMMAND ----------

@tool
def lookup_customer(customer_id: str) -> str:
    """Look up a customer fraud profile by ID."""
    return json.dumps(CUSTOMERS[customer_id], indent=2)

@tool
def lookup_transaction_by_id(txn_id: str) -> str:
    """Look up a transaction by transaction ID."""
    txn = next((t for t in TRANSACTIONS if t["txn_id"] == txn_id), None)
    return json.dumps(txn, indent=2) if txn else f"Transaction {txn_id} not found."

@tool
def retrieve_fraud_rules(query: str, top_k: int = 3) -> str:
    """Retrieve fraud rules from the local FAISS vector database."""
    return json.dumps(retrieve_rules_vector(query, top_k=top_k), indent=2)

@tool
def score_transaction_tool(txn_json: str, customer_json: str, retrieved_rules_json: str) -> str:
    """Score a transaction using customer context and retrieved rules."""
    txn = json.loads(txn_json)
    customer = json.loads(customer_json)
    retrieved_rules = json.loads(retrieved_rules_json)
    risk_score, reasons = score_transaction(txn, customer, retrieved_rules)
    return json.dumps({"risk_score": risk_score, "reasons": reasons, "initial_decision": initial_triage(risk_score)}, indent=2)

policy_retriever_agent = Agent(
    model=llm,
    tools=[retrieve_fraud_rules],
    system_prompt=(
        "You are a fraud policy specialist. Always call retrieve_fraud_rules before answering. "
        "Answer only from the retrieved rules. If nothing relevant is returned, say the fraud rule base does not cover the question."
    ),
    callback_handler=None,
)

triage_agent = Agent(
    model=llm,
    tools=[lookup_transaction_by_id, lookup_customer, retrieve_fraud_rules, score_transaction_tool],
    system_prompt=(
        "You are a fraud triage specialist. Look up the transaction, customer, retrieve relevant fraud rules, "
        "score the transaction, and return the risk score and initial decision."
    ),
    callback_handler=None,
)

@tool
def run_policy_retriever(question: str) -> str:
    """Ask the fraud policy retriever a policy or rule question."""
    return str(policy_retriever_agent(question))

@tool
def run_triage_agent(transaction_id: str) -> str:
    """Run the fraud triage specialist on a transaction ID."""
    txn = next(t for t in TRANSACTIONS if t["txn_id"] == transaction_id)
    customer = CUSTOMERS[txn["customer_id"]]
    query = build_query_from_txn(txn, customer)
    retrieved = retrieve_rules_vector(query)
    score, reasons = score_transaction(txn, customer, retrieved)
    return json.dumps({
        "txn_id": txn["txn_id"],
        "customer_id": txn["customer_id"],
        "retrieval_query": query,
        "retrieved_rules": [r["rule_id"] for r in retrieved],
        "risk_score": score,
        "reasons": reasons,
        "initial_decision": initial_triage(score),
    }, indent=2)

supervisor_agent = Agent(
    model=llm,
    tools=[run_policy_retriever, run_triage_agent],
    system_prompt=(
        "You are the fraud operations supervisor. "
        "For policy or fraud-rule questions, call run_policy_retriever. "
        "For transaction investigations, call run_triage_agent. "
        "Be concise and do not invent facts not present in tool outputs."
    ),
    callback_handler=None,
)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 11. Deterministic end-to-end processing
# MAGIC

# COMMAND ----------

def local_agent_decision(txn: Dict[str, Any], base_result: Dict[str, Any], retrieved_rules: List[Dict[str, Any]]) -> Dict[str, Any]:
    score = base_result["risk_score"]
    reasons = list(base_result["reasons"])
    triggered_rules = [r["rule_id"] for r in retrieved_rules]
    if score >= ESCALATE_BLOCK_MIN and (txn["ip_risk"] or txn["shipping_mismatch"] or txn["new_payee"]):
        decision = BLOCK
        reasons.append("agent escalation confirmed strong combined risk signals")
    elif score >= ESCALATE_REVIEW_MIN:
        decision = REVIEW
        reasons.append("agent escalation requested manual review for borderline or compound risk")
    else:
        # Keep the original triage decision instead of forcing APPROVE so an
        # agent step can never silently approve a transaction triage flagged.
        decision = base_result["initial_decision"]
        reasons.append("agent review retained the initial triage decision")
    return {"decision": decision, "risk_score": score, "reason": "; ".join(reasons[:5]), "triggered_rules": triggered_rules, "retrieval_used": True}

def process_transaction(txn: Dict[str, Any]) -> Dict[str, Any]:
    customer = CUSTOMERS[txn["customer_id"]]
    query = build_query_from_txn(txn, customer)
    retrieved = retrieve_rules_vector(query)
    retrieval_eval = retrieval_quality(retrieved)
    risk_score, reasons = score_transaction(txn, customer, retrieved)
    base = {"risk_score": risk_score, "reasons": reasons, "initial_decision": initial_triage(risk_score)}
    needs_escalation = (base["initial_decision"] != APPROVE or retrieval_eval["reason"] == "weak_match" or base["risk_score"] >= ESCALATE_REVIEW_MIN)
    if needs_escalation:
        agent_result = local_agent_decision(txn, base, retrieved)
        final_decision = agent_result["decision"]
        final_reason = agent_result["reason"]
        triggered_rules = agent_result["triggered_rules"]
    else:
        final_decision = base["initial_decision"]
        final_reason = "; ".join(base["reasons"][:4]) if base["reasons"] else "low observed risk"
        triggered_rules = [r["rule_id"] for r in retrieved]
    return {
        "txn_id": txn["txn_id"], "customer_id": txn["customer_id"], "decision": final_decision, "risk_score": base["risk_score"],
        "reason": final_reason, "triggered_rules": triggered_rules, "retrieval_query": query,
        "retrieval_quality": retrieval_eval, "retrieved_rule_titles": [r["title"] for r in retrieved],
    }

single_alert = process_transaction(TRANSACTIONS[2])
pprint(single_alert)


# COMMAND ----------

# MAGIC %md
# MAGIC ## 12. Batch simulation and alerts
# MAGIC

# COMMAND ----------

results = [process_transaction(txn) for txn in TRANSACTIONS]

if pd is not None:
    df = pd.DataFrame(results)
    display(df[["txn_id", "customer_id", "decision", "risk_score", "triggered_rules", "reason"]])
else:
    pprint(results)


# COMMAND ----------

summary = {}
for r in results:
    summary[r["decision"]] = summary.get(r["decision"], 0) + 1
summary


# COMMAND ----------

# MAGIC %md
# MAGIC ## 13. Optional supervisor demos
# MAGIC
# MAGIC These examples show the Week 17-style agent path for a policy question and a transaction investigation.
# MAGIC

# COMMAND ----------

print("Policy-style query:")
print(supervisor_agent("What fraud rule applies to an international wire to a new payee?"))


# COMMAND ----------

print("Transaction investigation:")
print(supervisor_agent("Investigate transaction T005."))


# COMMAND ----------

# MAGIC %md
# MAGIC ## 14. Architectural notes
# MAGIC
# MAGIC Compared with `fraud_rag_poc_1.ipynb`, this version now uses:
# MAGIC
# MAGIC - **LLM**: a shared `BedrockModel` object for Strands agents.
# MAGIC - **Agent**: specialist agents plus a lightweight supervisor.
# MAGIC - **Vector Database**: a FAISS index over the fraud-rule documents instead of lexical overlap retrieval.
# MAGIC
# MAGIC That keeps the fraud POC notebook-friendly while aligning it much more closely to the Week 17 agentic RAG approach.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 15. Databricks run notes
# MAGIC
# MAGIC - Import this notebook into your Databricks workspace.
# MAGIC - Attach a cluster with Python support (Runtime 15.4 LTS ML or later recommended).
# MAGIC - Ensure the `aws-course-creds` secret scope exists and contains the same keys used in v1.
# MAGIC - Run the `%pip install` cell, restart the Python kernel if prompted, then run all cells from the top.
# MAGIC - If Bedrock access is unavailable, the deterministic vector-RAG fraud flow still runs; only the optional Strands agent demos depend on successful LLM access.
# MAGIC