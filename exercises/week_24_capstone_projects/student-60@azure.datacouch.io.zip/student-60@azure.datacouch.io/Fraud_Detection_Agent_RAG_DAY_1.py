# Databricks notebook source
# MAGIC %md
# MAGIC # Capstone 1 — Fraud Detection Agent with RAG
# MAGIC
# MAGIC **An agentic fraud-investigation system on AWS, driven from Azure Databricks.**
# MAGIC
# MAGIC This single notebook delivers the full capstone pipeline:
# MAGIC
# MAGIC 1. **Read** a batch of card transactions from the Delta table.
# MAGIC 2. **Train & deploy** an XGBoost fraud classifier to a **SageMaker real-time endpoint**.
# MAGIC 3. **Build a Bedrock Knowledge Base** over the `fraud_rules/` corpus (RAG) and validate retrieval.
# MAGIC 4. **Wire an agent loop** (LangGraph + Claude Sonnet 4.5) that exposes four tools and *chooses its own
# MAGIC    sequence*: `invoke_fraud_model`, `retrieve_rules`, `get_customer_profile`, `generate_report`.
# MAGIC 5. **Run a batch** end-to-end → one structured investigation report per high-risk transaction, with a
# MAGIC    **CloudWatch audit trail** of every tool call.
# MAGIC 6. **(Stretch)** Orchestrate the whole batch as an **MWAA Airflow DAG**.
# MAGIC
# MAGIC > **How to run:** set your `STUDENT_NUM` in Section 0, then run top to bottom. Long-running cells
# MAGIC > (training ~4 min, endpoint deploy ~6 min, KB sync) are clearly marked. Each section is idempotent
# MAGIC > where practical, so you can re-run pieces without redoing everything.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Architecture at a glance
# MAGIC
# MAGIC ```
# MAGIC  Delta table (fad_transactions)
# MAGIC         │  Spark read
# MAGIC         ▼
# MAGIC  [Feature engineering] ──► train XGBoost (SageMaker Training Job)
# MAGIC         │                              │ model.tar.gz in S3
# MAGIC         │                              ▼
# MAGIC         │                     SageMaker real-time endpoint
# MAGIC         ▼                              ▲
# MAGIC  sample batch ──► score all ──► high-risk subset
# MAGIC                                        │
# MAGIC                                        ▼
# MAGIC                       ┌──────────  AGENT LOOP  ──────────┐
# MAGIC                       │  (LangGraph + Claude Sonnet 4.5) │
# MAGIC                       │   chooses tool order each turn   │
# MAGIC                       │                                  │
# MAGIC                       │  invoke_fraud_model ─► endpoint  │
# MAGIC                       │  retrieve_rules ─────► Bedrock KB (RAG over fraud_rules/)
# MAGIC                       │  get_customer_profile ─► customers Delta
# MAGIC                       │  generate_report ────► structured JSON → S3
# MAGIC                       └───────────────┬──────────────────┘
# MAGIC                                       │  every tool call logged
# MAGIC                                       ▼
# MAGIC                           CloudWatch Logs (audit trail)
# MAGIC ```
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 0 — install agent / RAG libraries first
# MAGIC
# MAGIC On Databricks, `%pip install` **restarts the Python interpreter**, so run this cell **before** anything else (the auth cell below recreates all clients afterward). `langchain-aws` / `langgraph` are usually pre-installed on the course cluster — this is a safety net.

# COMMAND ----------

# Run this FIRST. %pip restarts the Python kernel on Databricks, so any state
# created before it would be lost. Nothing important runs above this cell.
%pip install -q langchain langchain-aws langgraph


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 0 — Environment Setup
# MAGIC
# MAGIC The standard auth cell (Databricks → AWS via `boto3`). Replace `STUDENT_NUM` with your 2-digit number.
# MAGIC We extend the guidance cell with the extra clients this capstone needs (`s3`, `sts`, `logs`,
# MAGIC `cloudwatch`, `mwaa`) and a SageMaker SDK session bound to our `boto3` session (so the Python SDK works
# MAGIC from Databricks, not just from inside SageMaker Studio).

# COMMAND ----------

# --- Standard auth cell (from Capstone_1_Guidance.md) -----------------------
import boto3, os, json, time

STUDENT_NUM = "60"  # <-- your number
AWS_ACCOUNT_ID   = "962804699607"

scope = f"aws-course-creds-{STUDENT_NUM}"
os.environ["AWS_ACCESS_KEY_ID"]     = dbutils.secrets.get(scope, "aws-access-key-id")
os.environ["AWS_SECRET_ACCESS_KEY"] = dbutils.secrets.get(scope, "aws-secret-access-key")
os.environ["AWS_REGION"] = os.environ["AWS_DEFAULT_REGION"] = "us-west-2"

session           = boto3.Session(region_name="us-west-2")
sagemaker_client  = session.client("sagemaker")
sagemaker_runtime = session.client("sagemaker-runtime")
bedrock_runtime   = session.client("bedrock-runtime")
bedrock_agent     = session.client("bedrock-agent")
bedrock_agent_rt  = session.client("bedrock-agent-runtime")

# --- Extra clients this capstone needs -------------------------------------
s3         = session.client("s3")
sts        = session.client("sts")
logs       = session.client("logs")
cloudwatch = session.client("cloudwatch")
mwaa       = session.client("mwaa")

CALLER_ARN = sts.get_caller_identity()["Arn"]
print("Caller:", CALLER_ARN)


# COMMAND ----------

# --- Project configuration -------------------------------------------------
# Region + models (per the guidance).
AWS_REGION       = "us-west-2"
AGENT_MODEL_ID   = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"   # agent backbone (inference profile)
EMBED_MODEL_ID   = "amazon.titan-embed-text-v2:0"                   # KB embeddings


# Shared course resources (read ids from the shared secret scope where available).
def _shared(key, default=None):
    try:
        return dbutils.secrets.get("aws-course-shared", key)
    except Exception:
        return default

SHARED_BUCKET = _shared("course-s3-bucket", "bread-academy-shared")
S3_PREFIX     = f"student-{STUDENT_NUM}"          # everything we write lands here
KB_ID         = _shared("knowledge-base-id", None) # pre-built fraud-rules KB (Option A)

# SageMaker execution role the Training Job / endpoint assume. The course provisions one;
# pull it from the shared scope, else paste the ARN your instructor gave you.
SAGEMAKER_ROLE_ARN = _shared(
    "sagemaker-execution-role-arn",
    "arn:aws:iam::962804699607:role/bread-academy-sagemaker-execution-role",  # <-- set if not in scope
)

# Unique, per-student names so nothing collides with other students.
ENDPOINT_NAME = f"fraud-clf-student-{STUDENT_NUM}"
LOG_GROUP     = f"/bread-academy/capstone1/student-{STUDENT_NUM}"

# SageMaker Python SDK session bound to OUR boto3 session (Databricks-friendly).
import sagemaker
sm_sdk_session = sagemaker.Session(boto_session=session)

print("Region          :", AWS_REGION)
print("Shared bucket   :", SHARED_BUCKET)
print("S3 work prefix  :", f"s3://{SHARED_BUCKET}/{S3_PREFIX}/")
print("Endpoint name   :", ENDPOINT_NAME)
print("Pre-built KB id :", KB_ID)
print("SageMaker role  :", SAGEMAKER_ROLE_ARN)
print("Agent model     :", AGENT_MODEL_ID)


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 1 — Load the data from Unity Catalog
# MAGIC
# MAGIC Everything lives under `bread_academy.course_data`. We read it with Spark, then pull the transactions
# MAGIC into pandas for XGBoost. We also load `customers` (the agent's `get_customer_profile` tool reads this)
# MAGIC and `ft_fraud_cases` (case-level context for richer reports).

# COMMAND ----------

# Transactions: one row per card authorization, ~3% confirmed fraud (label_type_cd = 1).
fad_transactions_spark_df = spark.read.table("bread_academy.course_data.fad_transactions")
print("transactions:", fad_transactions_spark_df.count(), "rows")
fad_transactions_spark_df.groupBy("label_type_cd").count().show()

# Customers: one row per account_num; risk_tier derived from real fraud history.
customers_spark_df = spark.read.table("bread_academy.course_data.customers")
print("customers:", customers_spark_df.count(), "rows")

# Confirmed-fraud case detail (optional, used to enrich reports).
try:
    ft_fraud_cases_spark_df = spark.read.table("bread_academy.course_data.ft_fraud_cases")
    print("fraud cases:", ft_fraud_cases_spark_df.count(), "rows")
except Exception as e:
    ft_fraud_cases_spark_df = None
    print("ft_fraud_cases not available:", e)

# Pull to pandas for training / lookups.
fad_transactions_df = fad_transactions_spark_df.toPandas()
customers_df = customers_spark_df.toPandas()
ft_fraud_cases_df = ft_fraud_cases_spark_df.toPandas() if ft_fraud_cases_spark_df is not None else None

print("\npandas transactions shape:", fad_transactions_df.shape)
fad_transactions_df.head(3)


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 2 — Feature engineering
# MAGIC
# MAGIC XGBoost on SageMaker expects **CSV, target in column 0, numeric only, no header**. We build a single
# MAGIC deterministic `featurize()` function and use it for **both training and inference** so the feature
# MAGIC vector the endpoint sees at scoring time is identical to what it was trained on.
# MAGIC
# MAGIC Features we derive from the real Fiserv FAD columns:
# MAGIC
# MAGIC | Feature | Source |
# MAGIC |---|---|
# MAGIC | `tran_amt`, `new_fraud_score`, `total_velocity_amt`, `cash_velocity_amt`, `hour_24_cnt` | numeric, as-is |
# MAGIC | `card_not_present` | `card_prsn_cd == 'N'` |
# MAGIC | `foreign_country` | `mrch_cntry_cd != 'US'` |
# MAGIC | `high_risk_mcc` | `merch_cat_code_cd` in a high-risk MCC set (gambling, crypto, …) |
# MAGIC | `cvv_fail`, `avs_fail` | non-match CVV / AVS outcome codes |
# MAGIC | `entry_mode__*` | one-hot of `entry_mode_ind` over a fixed category list |
# MAGIC | `txn_hour_from_ts`, `odd_hour_txn` | parsed from `transaction_ts` (fallback: `hour_24_cnt`) |
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

import numpy as np
import pandas as pd

# Fixed vocabularies so train- and inference-time encodings line up exactly.
ENTRY_MODES    = ["chip", "swipe", "contactless", "ecom", "manual", "token"]
HIGH_RISK_MCCS = {7995, 6051, 6211, 4829, 7273, 5967, 7801}  # gambling, crypto, wires, etc.
NUMERIC_COLS   = ["tran_amt", "new_fraud_score", "total_velocity_amt",
                  "cash_velocity_amt", "hour_24_cnt"]
TARGET_COL     = "label_type_cd"

def _to_num(s):
    return pd.to_numeric(s, errors="coerce").fillna(0.0)

def featurize(frame: pd.DataFrame) -> pd.DataFrame:
    """Deterministic transaction -> numeric feature matrix. No target column."""
    f = pd.DataFrame(index=frame.index)
    for c in NUMERIC_COLS:
        f[c] = _to_num(frame[c]) if c in frame else 0.0

    cp = frame["card_prsn_cd"].astype(str).str.upper() if "card_prsn_cd" in frame else ""
    f["card_not_present"] = (cp == "N").astype(int)

    cc = frame["mrch_cntry_cd"].astype(str).str.upper() if "mrch_cntry_cd" in frame else "US"
    f["foreign_country"] = (cc != "US").astype(int)

    mcc = _to_num(frame["merch_cat_code_cd"]).astype(int) if "merch_cat_code_cd" in frame else 0
    f["merch_cat_code_cd"] = mcc
    f["high_risk_mcc"] = mcc.isin(HIGH_RISK_MCCS).astype(int)

    # CVV / AVS: treat anything that is not an explicit match ('M') as a fail signal.
    cvv = frame["cvv2_cvc2_otcm_cd"].astype(str).str.upper() if "cvv2_cvc2_otcm_cd" in frame else ""
    avs = frame["addr_vrfc_otcm_cd"].astype(str).str.upper() if "addr_vrfc_otcm_cd" in frame else ""
    f["cvv_fail"] = (~cvv.isin(["M", "MATCH", "Y"])).astype(int)
    f["avs_fail"] = (~avs.isin(["M", "MATCH", "Y"])).astype(int)

    em = frame["entry_mode_ind"].astype(str).str.lower() if "entry_mode_ind" in frame else ""
    for mode in ENTRY_MODES:
        f[f"entry_mode__{mode}"] = (em == mode).astype(int)

    # Parse transaction timestamp into hour and flag odd-hour activity.
    fallback_hour = (_to_num(frame["hour_24_cnt"]) if "hour_24_cnt" in frame
                     else pd.Series(0, index=frame.index))
    fallback_hour = fallback_hour.round().clip(0, 23)

    if "transaction_ts" in frame:
        parsed_ts = pd.to_datetime(frame["transaction_ts"], errors="coerce")
        txn_hour = parsed_ts.dt.hour.fillna(fallback_hour).astype(int)
    else:
        txn_hour = fallback_hour.astype(int)

    f["txn_hour_from_ts"] = txn_hour
    f["odd_hour_txn"] = txn_hour.isin([0, 1, 2, 3, 4, 5]).astype(int)

    return f

# Build the feature frame + the canonical column order used everywhere downstream.
X_all = featurize(fad_transactions_df)
FEATURE_COLUMNS = list(X_all.columns)
y_all = _to_num(fad_transactions_df[TARGET_COL]).astype(int)

print(f"{len(FEATURE_COLUMNS)} features:")
print(FEATURE_COLUMNS)
print("\nfraud rate:", round(float(y_all.mean()), 4))
X_all.head(3)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Train / Validation / Holdout Split (60 / 20 / 20)
# MAGIC
# MAGIC We split the data into three sets so model training and evaluation stay unbiased:
# MAGIC
# MAGIC - **Train (60%)**: fit model parameters.
# MAGIC - **Validation (20%)**: tune decisions like early stopping and hyperparameters.
# MAGIC - **Holdout (20%)**: final, untouched evaluation.
# MAGIC
# MAGIC ### Why This Matters
# MAGIC
# MAGIC - Prevents leakage from evaluating on seen data.
# MAGIC - Produces more realistic performance metrics.
# MAGIC - Reduces overfitting to tuning choices by keeping a clean final test set.

# COMMAND ----------

from sklearn.model_selection import train_test_split

# Train / validation / holdout (60 / 20 / 20), stratified on the rare label.

X_train, X_tmp, y_train, y_tmp = train_test_split(
    X_all, y_all, test_size=0.40, random_state=42, stratify=y_all)
X_val, X_holdout, y_val, y_holdout = train_test_split(
    X_tmp, y_tmp, test_size=0.50, random_state=42, stratify=y_tmp)

print(f"train={len(X_train)}  val={len(X_val)}  holdout={len(X_holdout)}")
print("fraud per split:",
      round(y_train.mean(),3), round(y_val.mean(),3), round(y_holdout.mean(),3))

# XGBoost CSV format: target FIRST, numeric only, NO header, NO index.
train_csv = pd.concat([y_train.rename("y"), X_train.reset_index(drop=True)
                       .set_index(y_train.index)], axis=1)
val_csv   = pd.concat([y_val.rename("y"),   X_val.reset_index(drop=True)
                       .set_index(y_val.index)],   axis=1)

import os
os.makedirs("/tmp/cap1", exist_ok=True)
train_csv.to_csv("/tmp/cap1/train.csv", header=False, index=False)
val_csv.to_csv("/tmp/cap1/validation.csv", header=False, index=False)

# Class imbalance handle for XGBoost.
neg, pos = int((y_train == 0).sum()), int((y_train == 1).sum())
SCALE_POS_WEIGHT = round(neg / max(pos, 1), 2)
print("scale_pos_weight:", SCALE_POS_WEIGHT)


# COMMAND ----------

# Upload the training channels to our per-student S3 prefix.
train_key = f"{S3_PREFIX}/sagemaker/train/train.csv"
val_key   = f"{S3_PREFIX}/sagemaker/validation/validation.csv"
s3.upload_file("/tmp/cap1/train.csv",      SHARED_BUCKET, train_key)
s3.upload_file("/tmp/cap1/validation.csv", SHARED_BUCKET, val_key)
print("uploaded:")
print(" ", f"s3://{SHARED_BUCKET}/{train_key}")
print(" ", f"s3://{SHARED_BUCKET}/{val_key}")


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 3 — Train the fraud classifier on SageMaker
# MAGIC
# MAGIC We train the managed **XGBoost 1.5-1** container as a SageMaker Training Job (the Week 6 pattern), tuned
# MAGIC for the rare-fraud signal via `scale_pos_weight` and AUC early-stopping. Runs ~3–5 minutes.
# MAGIC
# MAGIC > *Optional:* uncomment the `HyperparameterTuner` block at the bottom to run a Bayesian sweep instead of
# MAGIC > a single fit — left off by default to respect the hackathon clock.

# COMMAND ----------

from sagemaker.estimator import Estimator
from sagemaker.inputs import TrainingInput
from sagemaker.image_uris import retrieve

xgb_image = retrieve("xgboost", AWS_REGION, version="1.5-1")
print("XGBoost container:", xgb_image)

output_path = f"s3://{SHARED_BUCKET}/{S3_PREFIX}/sagemaker/models"

# Single-fit setup: define one Estimator with fixed infrastructure + algorithm.
# This is NOT a tuning sweep; we run one training job with one parameter set.
xgb = Estimator(
    image_uri=xgb_image,
    role=SAGEMAKER_ROLE_ARN,
    instance_count=1,
    instance_type="ml.m5.xlarge",
    output_path=output_path,
    sagemaker_session=sm_sdk_session,
    base_job_name=f"cap1-fraud-{STUDENT_NUM}",
)

# Single-fit hyperparameters: one explicit configuration used for this run.
# If tuning is enabled (optional cell below), those ranges override this idea.
xgb.set_hyperparameters(
    objective="binary:logistic",
    eval_metric="auc",
    num_round=200,
    max_depth=5,
    eta=0.2,
    gamma=4,
    min_child_weight=6,
    subsample=0.8,
    colsample_bytree=0.8,
    scale_pos_weight=SCALE_POS_WEIGHT,
    early_stopping_rounds=15,
)

train_input = TrainingInput(f"s3://{SHARED_BUCKET}/{train_key}", content_type="text/csv")
val_input   = TrainingInput(f"s3://{SHARED_BUCKET}/{val_key}",   content_type="text/csv")

# One call to fit() launches one SageMaker Training Job using train + validation.
# Validation is used for eval metric tracking and early stopping in that SAME job.
print("Starting training job (3-5 min)...")
xgb.fit({"train": train_input, "validation": val_input}, wait=True, logs="None")

# Save the model artifact URI produced by this single fit run.
MODEL_DATA = xgb.model_data
print("\nModel artifact:", MODEL_DATA)


# COMMAND ----------

# Can be used for fine tuning..
# ---- (OPTIONAL) Bayesian hyperparameter tuning -- uncomment to use --------

# from sagemaker.tuner import HyperparameterTuner, IntegerParameter, ContinuousParameter
# tuner = HyperparameterTuner(
#     estimator=xgb,
#     objective_metric_name="validation:auc",
#     objective_type="Maximize",
#     max_jobs=12, max_parallel_jobs=2, strategy="Bayesian",
#     hyperparameter_ranges={
#         "max_depth": IntegerParameter(3, 10),
#         "eta": ContinuousParameter(0.01, 0.3),
#         "subsample": ContinuousParameter(0.5, 0.9),
#         "colsample_bytree": ContinuousParameter(0.5, 0.9),
#         "min_child_weight": IntegerParameter(1, 10),
#         "gamma": ContinuousParameter(0, 5),
#     },
#     base_tuning_job_name=f"cap1-tune-{STUDENT_NUM}",
# )
# tuner.fit({"train": train_input, "validation": val_input}, wait=True, logs=False)
# MODEL_DATA = tuner.best_estimator().model_data
# print("Best model artifact:", MODEL_DATA)


# COMMAND ----------

#copied from Single-fit setup and can be used for hyperparameter tuning as well
from sagemaker.estimator import Estimator
from sagemaker.inputs import TrainingInput
from sagemaker.image_uris import retrieve

xgb_image = retrieve("xgboost", AWS_REGION, version="1.5-1")
print("XGBoost container:", xgb_image)

output_path = f"s3://{SHARED_BUCKET}/{S3_PREFIX}/sagemaker/models"

# COMMAND ----------

# =============================================================================
# LAUNCH HYPERPARAMETER TUNING JOB
# =============================================================================
from sagemaker.tuner import HyperparameterTuner, IntegerParameter, ContinuousParameter
print("Configuring hyperparameter tuning job...")
print("=" * 60)

# Create a new estimator for tuning (clone the previous one)
xgb_tuning_estimator = Estimator(
    image_uri=xgb_image,
    role=SAGEMAKER_ROLE_ARN,
    instance_count=1,
    instance_type="ml.m5.xlarge",
    output_path=output_path,
    sagemaker_session=sm_sdk_session,
    base_job_name=f"cap1-fraud-{STUDENT_NUM}"
)

# Set static hyperparameters (ones we won't tune)
xgb_tuning_estimator.set_hyperparameters(
    objective='binary:logistic',
    num_round=100,
    eval_metric='auc',
    early_stopping_rounds=10
)

# Define hyperparameter ranges to explore
hyperparameter_ranges = {
    'max_depth': IntegerParameter(3, 10),           # Tree depth
    'eta': ContinuousParameter(0.01, 0.3),          # Learning rate
    'subsample': ContinuousParameter(0.5, 0.9),     # Sample fraction
    'colsample_bytree': ContinuousParameter(0.5, 0.9),  # Feature fraction
    'min_child_weight': IntegerParameter(1, 10),    # Minimum child weight
    'gamma': ContinuousParameter(0, 5)              # Min loss reduction
}

print("✓ Hyperparameter ranges defined:")
for param, range_obj in hyperparameter_ranges.items():
    print(f"  {param:20s}: {range_obj}")

# Create tuner
tuner = HyperparameterTuner(
    estimator=xgb_tuning_estimator,
    objective_metric_name='validation:auc',
    objective_type='Maximize',
    max_jobs=20,                # Total training jobs to try
    max_parallel_jobs=2,        # Run 2 jobs at a time
    hyperparameter_ranges=hyperparameter_ranges,
    strategy='Bayesian',        # Smart search strategy
    base_tuning_job_name=f"cap1-fraud-{STUDENT_NUM}"
)

print("\n✓ Tuner configured")
print(f"  Strategy:      Bayesian optimization")
print(f"  Max jobs:      20 training jobs")
print(f"  Parallel jobs: 2 simultaneous")
print(f"  Objective:     Maximize validation:auc")

# Launch tuning job (runs in background)
print("\n" + "=" * 60)
print("🚀 Launching hyperparameter tuning job...")
print("=" * 60)

tuner.fit(
    inputs={
        'train': train_input,
        'validation': validation_input
    },
    wait=False,     # Don't block - job runs in background
    logs=False      # Don't stream logs (would be overwhelming with 20 jobs)
)

tuning_job_name = tuner.latest_tuning_job.name

print(f"\n✅ Tuning job launched: {tuning_job_name}")
print(f"\n⏱️ This job will take approximately 30-60 minutes to complete")
print(f"   (20 training jobs × 3-5 min each ÷ 2 parallel = ~30-50 min)")
print(f"\n🔗 View progress in SageMaker Console:")
print(f"   https://console.aws.amazon.com/sagemaker/home?region={region}#/hyper-tuning-jobs/{tuning_job_name}")
print(f"\n💡 The job runs asynchronously - you can continue with the next section")

# COMMAND ----------

# =============================================================================
# MONITOR TUNING JOB STATUS
# =============================================================================

print("Checking tuning job status...")
print("=" * 60)

# Get current status
tuning_job_details = sm_session.sagemaker_client.describe_hyper_parameter_tuning_job(
    HyperParameterTuningJobName=tuning_job_name
)

status = tuning_job_details['HyperParameterTuningJobStatus']
print(f"Status: {status}")

# Show progress
if 'TrainingJobStatusCounters' in tuning_job_details:
    counters = tuning_job_details['TrainingJobStatusCounters']
    print(f"\nTraining Job Progress:")
    print(f"  Completed:   {counters.get('Completed', 0)}")
    print(f"  InProgress:  {counters.get('InProgress', 0)}")
    print(f"  Stopped:     {counters.get('Stopped', 0)}")
    print(f"  Failed:      {counters.get('RetryableError', 0) + counters.get('NonRetryableError', 0)}")

# Show best result so far (if any jobs completed)
if 'BestTrainingJob' in tuning_job_details:
    best_job = tuning_job_details['BestTrainingJob']
    print(f"\n✅ Best Training Job So Far:")
    print(f"  Job Name: {best_job['TrainingJobName']}")
    print(f"  Objective: {best_job['FinalHyperParameterTuningJobObjectiveMetric']['Value']:.4f}")
    print(f"\n  Best Hyperparameters:")
    for param, value in best_job['TunedHyperParameters'].items():
        print(f"    {param:20s}: {value}")
else:
    print(f"\n⏳ No completed jobs yet - check back in a few minutes")

# Provide code for later checking
print("\n" + "=" * 60)
print("💡 To check status later, run this code:")
print("=" * 60)
print(f"""
import boto3
sm_client = boto3.client('sagemaker', region_name='{region}')
details = sm_client.describe_hyper_parameter_tuning_job(
    HyperParameterTuningJobName='{tuning_job_name}'
)
print(f"Status: {{details['HyperParameterTuningJobStatus']}}")
if 'BestTrainingJob' in details:
    best = details['BestTrainingJob']
    print(f"Best AUC: {{best['FinalHyperParameterTuningJobObjectiveMetric']['Value']:.4f}}")
""")

print("\n" + "=" * 60)
print("🎯 What's Happening:")
print("=" * 60)
print("1. Bayesian optimizer selects hyperparameter combinations to try")
print("2. Each combination trains an XGBoost model (3-5 minutes)")
print("3. Two models train in parallel to save time")
print("4. After each job, the optimizer learns and picks better combinations")
print("5. After 20 jobs, the best hyperparameters are identified")
print("\n✓ The optimized model will outperform our manually tuned one!")

# COMMAND ----------

# MAGIC %md
# MAGIC # Section 4 — Deploy to a real-time endpoint & evaluate on holdout
# MAGIC
# MAGIC We wrap the trained artifact in a `Model` and deploy it to a real-time endpoint (Week 7 pattern). Deploy
# MAGIC takes ~5–8 minutes. Then we score the **holdout** through the live endpoint and report AUC, precision,
# MAGIC recall, and the confusion matrix — proving the endpoint works *and* that the model generalizes.

# COMMAND ----------

from sagemaker.model import Model

# If the endpoint already exists from a previous run, reuse it; else deploy.
def endpoint_exists(name):
    try:
        sagemaker_client.describe_endpoint(EndpointName=name)
        return True
    except sagemaker_client.exceptions.ClientError:
        return False

if endpoint_exists(ENDPOINT_NAME):
    print(f"Endpoint {ENDPOINT_NAME} already exists — reusing.")
else:
    fraud_model = Model(
        image_uri=xgb_image,
        model_data=MODEL_DATA,
        role=SAGEMAKER_ROLE_ARN,
        sagemaker_session=sm_sdk_session,
        name=f"cap1-fraud-model-{STUDENT_NUM}-{int(time.time())}",
    )
    print(f"Deploying {ENDPOINT_NAME} (5-8 min)...")
    fraud_model.deploy(
        initial_instance_count=1,
        instance_type="ml.m5.large",
        endpoint_name=ENDPOINT_NAME,
    )
    print("Deployed.")

print("Status:", sagemaker_client.describe_endpoint(EndpointName=ENDPOINT_NAME)["EndpointStatus"])


# COMMAND ----------

# MAGIC %md
# MAGIC ### Endpoint Scoring Helpers
# MAGIC
# MAGIC This section defines two reusable methods for sending feature vectors to the deployed SageMaker endpoint.
# MAGIC
# MAGIC - `score_features(feat_row)`: scores a **single featurized transaction row** and returns one fraud probability.
# MAGIC   - Used later by the agent tool (`invoke_fraud_model`) when investigating one transaction at a time.
# MAGIC - `score_frame(feat, batch=500)`: scores a **full feature dataframe in mini-batches** and returns probabilities for all rows.
# MAGIC   - Used for holdout/batch evaluation where we need efficient multi-row inference.
# MAGIC
# MAGIC Both methods use the same `FEATURE_COLUMNS` order to guarantee inference-time input matches the model's training-time feature layout.

# COMMAND ----------

# Low-level invoke helper (CSV in -> probability out). Used by eval AND the agent tool.
def score_features(feat_row: pd.Series) -> float:
    """Score a single featurized row (ordered by FEATURE_COLUMNS) -> fraud probability."""
    csv_line = ",".join(str(float(feat_row[c])) for c in FEATURE_COLUMNS)
    resp = sagemaker_runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME, ContentType="text/csv", Body=csv_line)
    out = resp["Body"].read().decode().strip()
    # XGBoost text container returns a bare probability (or CSV of them).
    return float(out.split(",")[0])

# Score the holdout through the live endpoint in mini-batches (CSV multi-row).
def score_frame(feat: pd.DataFrame, batch=500):
    probs = []
    rows = feat[FEATURE_COLUMNS].astype(float).values
    for i in range(0, len(rows), batch):
        chunk = rows[i:i+batch]
        body = "\n".join(",".join(str(v) for v in r) for r in chunk)
        resp = sagemaker_runtime.invoke_endpoint(
            EndpointName=ENDPOINT_NAME, ContentType="text/csv", Body=body)
        out = resp["Body"].read().decode().strip().splitlines()
        probs.extend(float(x.split(",")[0]) for x in out)
    return np.array(probs)

holdout_probs = score_frame(X_holdout)
print("scored holdout:", len(holdout_probs))


# COMMAND ----------

# MAGIC %md
# MAGIC ### Holdout Metrics Evaluation
# MAGIC
# MAGIC Here we evaluate model performance on the **holdout set** (data never used for fitting or tuning) to estimate real-world generalization.
# MAGIC
# MAGIC - **ROC-AUC**: ranking quality across thresholds; higher is better.
# MAGIC - **Precision**: among predicted fraud transactions, how many are truly fraud.
# MAGIC - **Recall**: among true fraud transactions, how many we successfully catch.
# MAGIC - **F1**: harmonic balance of precision and recall.
# MAGIC - **Confusion Matrix**: counts of TN, FP, FN, TP for the selected threshold.
# MAGIC
# MAGIC Together, these metrics help us assess the tradeoff between catching fraud and limiting false alarms before moving to production usage.

# COMMAND ----------

from sklearn.metrics import roc_auc_score, precision_score, recall_score, confusion_matrix, f1_score

THRESHOLD = 0.5
y_true = y_holdout.values
y_pred = (holdout_probs >= THRESHOLD).astype(int)

print("Holdout evaluation")
print("=" * 40)
print(f"ROC-AUC   : {roc_auc_score(y_true, holdout_probs):.4f}")
print(f"Precision : {precision_score(y_true, y_pred, zero_division=0):.4f}")
print(f"Recall    : {recall_score(y_true, y_pred, zero_division=0):.4f}")
print(f"F1        : {f1_score(y_true, y_pred, zero_division=0):.4f}")
print("\nConfusion matrix [[TN FP][FN TP]]:")
print(confusion_matrix(y_true, y_pred))


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 5 — Bedrock Knowledge Base (the RAG part)
# MAGIC
# MAGIC The agent retrieves matching fraud rules from a **Bedrock Knowledge Base** built over the `fraud_rules/`
# MAGIC corpus (~32 markdown docs, each with YAML frontmatter and worked examples). Two paths:
# MAGIC
# MAGIC - **Option A — reuse the pre-built KB** (`bread-academy-fraud-kb`): fastest, `KB_ID` came from the shared
# MAGIC   scope in Section 0. Run the validation cell and move on.
# MAGIC - **Option B — build your own** (more of the learning): upload `fraud_rules/*.md` to your S3 prefix, then
# MAGIC   create a KB in the Bedrock console (Titan v2 embeddings, OpenSearch Serverless quick-create, fixed-size
# MAGIC   ~300-token chunking), **sync**, and set `KB_ID` to your new id.
# MAGIC
# MAGIC Either way, our `retrieve_rules` tool is a thin wrapper over `bedrock_agent_rt.retrieve`.

# COMMAND ----------

# --- Option B (optional): upload the corpus so you can build your own KB ----
# Skip if you're using the pre-built KB (Option A). Run, then create the KB in the
# Bedrock console pointed at the prefix printed below, sync, and paste its id into KB_ID.

import glob
RULES_GLOB = "fraud_rules/*.md"          # the corpus sits next to the guidance file
files = glob.glob(RULES_GLOB)
print(f"found {len(files)} rule docs")
for f in files:
    key = f"{S3_PREFIX}/fraud_rules/{os.path.basename(f)}"
    s3.upload_file(f, SHARED_BUCKET, key)
if files:
    print(f"uploaded to s3://{SHARED_BUCKET}/{S3_PREFIX}/fraud_rules/")
    print("Now create a KB in the Bedrock console over that prefix, sync, and set KB_ID.")
else:
    print("No local fraud_rules/ found — use Option A (pre-built KB).")


# COMMAND ----------

# --- Option B (programmatic): create a Bedrock KB + data source + sync --------
# Adapted from exercises/week_17_rag_fundamentals/bootstrap_and_setup.py
import uuid
import time
from botocore.exceptions import ClientError

acct = sts.get_caller_identity()["Account"]
region = AWS_REGION

# Source docs uploaded in the previous cell.
DOC_PREFIX = f"{S3_PREFIX}/fraud_rules/"
DOC_BUCKET_ARN = f"arn:aws:s3:::{SHARED_BUCKET}"

# S3 Vectors store (same pattern used in bootstrap_and_setup.py)
VECTOR_BUCKET = f"bread-academy-fraud-kb-vectors-{STUDENT_NUM}"
VECTOR_INDEX = "fraud-index"
VECTOR_BUCKET_ARN = f"arn:aws:s3vectors:{region}:{acct}:bucket/{VECTOR_BUCKET}"
VECTOR_INDEX_ARN = f"{VECTOR_BUCKET_ARN}/index/{VECTOR_INDEX}"

# Role used by Bedrock KB. Prefer a dedicated role from shared secrets if present;
# fallback to the SageMaker role configured earlier.
try:
    KB_ROLE_ARN = dbutils.secrets.get("aws-course-shared", "bedrock-kb-role-arn")
except Exception:
    KB_ROLE_ARN = SAGEMAKER_ROLE_ARN

print("Using KB role:", KB_ROLE_ARN)
print("Docs source   :", f"s3://{SHARED_BUCKET}/{DOC_PREFIX}")

# Create/reuse the S3 Vectors bucket + index.
s3vec = session.client("s3vectors", region_name=region)
try:
    s3vec.create_vector_bucket(vectorBucketName=VECTOR_BUCKET)
    print("Created vector bucket:", VECTOR_BUCKET)
except ClientError as e:
    if e.response["Error"]["Code"] == "ConflictException":
        print("Vector bucket already exists:", VECTOR_BUCKET)
    else:
        raise

try:
    s3vec.create_index(
        vectorBucketName=VECTOR_BUCKET,
        indexName=VECTOR_INDEX,
        dataType="float32",
        dimension=1024,
        distanceMetric="cosine",
    )
    print("Created vector index:", VECTOR_INDEX)
except ClientError as e:
    if e.response["Error"]["Code"] == "ConflictException":
        print("Vector index already exists:", VECTOR_INDEX)
    else:
        raise

# Create KB.
kb_name = f"fraud-rules-kb-student-{STUDENT_NUM}-{uuid.uuid4().hex[:8]}"
embed_arn = f"arn:aws:bedrock:{region}::foundation-model/{EMBED_MODEL_ID}"

kb_resp = bedrock_agent.create_knowledge_base(
    name=kb_name,
    roleArn=KB_ROLE_ARN,
    knowledgeBaseConfiguration={
        "type": "VECTOR",
        "vectorKnowledgeBaseConfiguration": {
            "embeddingModelArn": embed_arn,
            "embeddingModelConfiguration": {
                "bedrockEmbeddingModelConfiguration": {
                    "dimensions": 1024,
                    "embeddingDataType": "FLOAT32",
                }
            },
        },
    },
    storageConfiguration={
        "type": "S3_VECTORS",
        "s3VectorsConfiguration": {
            "vectorBucketArn": VECTOR_BUCKET_ARN,
            "indexArn": VECTOR_INDEX_ARN,
        },
    },
)
KB_ID = kb_resp["knowledgeBase"]["knowledgeBaseId"]
print("Created KB:", KB_ID)

# Wait for KB to become ACTIVE.
while True:
    kb_desc = bedrock_agent.get_knowledge_base(knowledgeBaseId=KB_ID)["knowledgeBase"]
    kb_status = kb_desc["status"]
    print("KB status:", kb_status)
    if kb_status == "ACTIVE":
        break
    if kb_status in ("FAILED", "DELETE_UNSUCCESSFUL"):
        raise RuntimeError(f"KB creation failed with status={kb_status}")
    time.sleep(10)

# Create data source on your uploaded S3 fraud_rules docs.
ds_resp = bedrock_agent.create_data_source(
    knowledgeBaseId=KB_ID,
    name=f"{kb_name}-s3",
    dataSourceConfiguration={
        "type": "S3",
        "s3Configuration": {
            "bucketArn": DOC_BUCKET_ARN,
            "inclusionPrefixes": [DOC_PREFIX],
        },
    },
    vectorIngestionConfiguration={
        "chunkingConfiguration": {
            "chunkingStrategy": "FIXED_SIZE",
            "fixedSizeChunkingConfiguration": {
                "maxTokens": 300,
                "overlapPercentage": 20,
            },
        }
    },
)
DS_ID = ds_resp["dataSource"]["dataSourceId"]
print("Created data source:", DS_ID)

# Sync (ingest) documents.
ing = bedrock_agent.start_ingestion_job(knowledgeBaseId=KB_ID, dataSourceId=DS_ID)
ing_id = ing["ingestionJob"]["ingestionJobId"]
print("Started ingestion job:", ing_id)

while True:
    j = bedrock_agent.get_ingestion_job(
        knowledgeBaseId=KB_ID,
        dataSourceId=DS_ID,
        ingestionJobId=ing_id,
    )["ingestionJob"]
    status = j["status"]
    print("Ingestion status:", status, j.get("statistics", {}))
    if status == "COMPLETE":
        break
    if status in ("FAILED", "STOPPED"):
        raise RuntimeError(f"Ingestion ended with status={status}")
    time.sleep(15)

print("\nKB ready:", KB_ID)
print("You can now run the validation cell below (bedrock_agent_rt.retrieve).")

# COMMAND ----------

"""
Option A - reuse the pre-built KB (fastest).** A fraud-rules KB already exists in the
account. Get its id from the shared scope and start querying immediately:
"""
KB_ID = dbutils.secrets.get("aws-course-shared", "knowledge-base-id")  # bread-academy-fraud-kb
#(LXMHVMVY1L)
resp = bedrock_agent_rt.retrieve(
    knowledgeBaseId=KB_ID,
    retrievalQuery={"text": "high velocity card-not-present from a high-risk country"},
)
for r in resp["retrievalResults"]:
    print(r["content"]["text"][:200])

# COMMAND ----------

# --- Validate retrieval before wiring the KB to the agent -------------------
assert KB_ID, "KB_ID is not set. Use the pre-built KB (Option A) or build your own (Option B)."

def kb_retrieve(query: str, k: int = 4):
    """Raw retrieval against the Bedrock KB -> list of {text, source, score}."""
    resp = bedrock_agent_rt.retrieve(
        knowledgeBaseId=KB_ID,
        retrievalQuery={"text": query},
        retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": k}},
    )
    hits = []
    for r in resp.get("retrievalResults", []):
        hits.append({
            "text":   r["content"]["text"],
            "source": r.get("location", {}).get("s3Location", {}).get("uri", "unknown"),
            "score":  round(r.get("score", 0.0), 4),
        })
    return hits

# Sanity-check with a query whose thresholds are wired to the real data.
for h in kb_retrieve("high velocity card-not-present from a high-risk country", k=3):
    print(f"[{h['score']}] {h['source'].split('/')[-1]}")
    print("   ", h["text"][:160].replace("\n", " "), "...\n")


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 6 — The four agent tools (with CloudWatch audit trail)
# MAGIC
# MAGIC The agent is given four tools and **chooses its own sequence**. Every tool call emits a structured
# MAGIC log line to a per-student CloudWatch log group, so the full reasoning trace is auditable back to the
# MAGIC rules and customer data the agent used.
# MAGIC
# MAGIC | Tool | Does |
# MAGIC |---|---|
# MAGIC | `invoke_fraud_model` | look up the transaction, featurize it, call the SageMaker endpoint → risk score |
# MAGIC | `retrieve_rules` | `bedrock_agent_rt.retrieve` against the KB → matching fraud rules |
# MAGIC | `get_customer_profile` | read one row from `customers` |
# MAGIC | `generate_report` | assemble a structured investigation report (JSON) and persist to S3 |
# MAGIC

# COMMAND ----------

# --- CloudWatch audit-trail plumbing ---------------------------------------
def _ensure_log_group():
    try:
        logs.create_log_group(logGroupName=LOG_GROUP)
    except logs.exceptions.ResourceAlreadyExistsException:
        pass

# We need to UNCOMMENT THIS TO CREATE THE LOG GROUPS
#_ensure_log_group()

# Each agent run gets its own log stream (run_id). audit() appends one event per tool call.
_audit_seq = {"token": None}
def start_audit_stream(run_id: str):
    try:
        logs.create_log_stream(logGroupName=LOG_GROUP, logStreamName=run_id)
    except logs.exceptions.ResourceAlreadyExistsException:
        pass
    _audit_seq["token"] = None
    _audit_seq["run_id"] = run_id

def audit(step: str, txn: str, args: dict, result_summary):
    """Emit one structured audit line to CloudWatch for the current run."""
    run_id = _audit_seq.get("run_id", "adhoc")
    event = {
        "timestamp": int(time.time() * 1000),
        "message": json.dumps({
            "step": step, "txn": txn, "args": args,
            "result_summary": result_summary, "ts": time.time(),
        }),
    }
    kw = {"logGroupName": LOG_GROUP, "logStreamName": run_id, "logEvents": [event]}
    if _audit_seq["token"]:
        kw["sequenceToken"] = _audit_seq["token"]
    try:
        resp = logs.put_log_events(**kw)
        _audit_seq["token"] = resp.get("nextSequenceToken")
    except logs.exceptions.InvalidSequenceTokenException as e:
        # Recover the expected token and retry once.
        import re
        m = re.search(r"sequenceToken is: (\S+)", str(e))
        if m:
            kw["sequenceToken"] = m.group(1)
            resp = logs.put_log_events(**kw)
            _audit_seq["token"] = resp.get("nextSequenceToken")

print("CloudWatch audit trail ready ->", LOG_GROUP)


# COMMAND ----------

# --- Fast in-memory indexes the tools read from ----------------------------
# Transaction lookup by id (so a tool can featurize a single row on demand).
fad_transactions_df_indexed = fad_transactions_df.set_index("transaction_id", drop=False)
customers_df_indexed = customers_df.set_index("customer_id", drop=False)
ft_fraud_cases_df_indexed = (ft_fraud_cases_df.set_index("transaction_id", drop=False)
                             if ft_fraud_cases_df is not None else None)
print("indexed:", len(fad_transactions_df_indexed), "transactions,", len(customers_df_indexed), "customers")


# COMMAND ----------

from langchain_core.tools import tool

REPORTS = {}   # transaction_id -> report dict, collected this session

@tool
def invoke_fraud_model(transaction_id: str) -> str:
    """Score a transaction for fraud risk using the deployed SageMaker model.

    Returns the model's fraud probability (0-1) plus the key risk signals
    (amount, card-present flag, country, velocity) for the given transaction_id
    (format txn_00000001). Call this FIRST to decide whether deeper investigation
    is warranted."""
    if transaction_id not in fad_transactions_df_indexed.index:
        return json.dumps({"error": f"transaction {transaction_id} not found"})
    row = fad_transactions_df_indexed.loc[[transaction_id]]
    score = float(score_features(featurize(row).iloc[0]))
    r = row.iloc[0]
    out = {
        "transaction_id": transaction_id,
        "risk_score": round(score, 4),
        "tran_amt": float(_to_num(pd.Series([r.get("tran_amt", 0)]))[0]),
        "card_present": str(r.get("card_prsn_cd", "")),
        "country": str(r.get("mrch_cntry_cd", "")),
        "mcc": str(r.get("merch_cat_code_cd", "")),
        "merchant": str(r.get("mrch_nm", "")),
        "issuer_fraud_score": str(r.get("new_fraud_score", "")),
    }
    audit("invoke_fraud_model", transaction_id, {"transaction_id": transaction_id},
          {"risk_score": out["risk_score"]})
    return json.dumps(out)

@tool
def retrieve_rules(query: str) -> str:
    """Retrieve the fraud-policy rules that match a transaction pattern (RAG).

    Pass a natural-language description of the suspicious pattern (e.g.
    'high velocity card-not-present purchase from a high-risk country at a
    crypto merchant'). Returns the most relevant fraud rules from the knowledge
    base, with their source documents. Use this to ground your decision in
    written policy rather than guessing."""
    hits = kb_retrieve(query, k=4)
    audit("retrieve_rules", _audit_seq.get("run_id", ""), {"query": query},
          {"n_hits": len(hits), "top_source": hits[0]["source"].split("/")[-1] if hits else None})
    return json.dumps([{"source": h["source"].split("/")[-1], "score": h["score"],
                        "rule": h["text"][:700]} for h in hits])

@tool
def get_customer_profile(account_num: str) -> str:
    """Look up the customer profile for an account (context for the investigation).

    Pass the account_num (format acct_0000001). Returns tenure, average monthly
    spend, credit band, risk tier, delinquency flag, occupation, segment, and a
    human-readable profile summary. Use this to judge whether a transaction is
    anomalous for THIS customer."""
    if account_num not in customers_df_indexed.index:
        audit("get_customer_profile", account_num, {"account_num": account_num}, {"found": False})
        return json.dumps({"error": f"account {account_num} not found"})
    c = customers_df_indexed.loc[account_num].to_dict()
    keep = ["customer_id", "account_tenure_months", "avg_monthly_spend", "home_zip",
            "credit_score_band", "risk_tier", "delinquency_flag", "occupation",
            "segment", "profile_summary"]
    prof = {k: (str(c.get(k)) if c.get(k) is not None else None) for k in keep}
    audit("get_customer_profile", account_num, {"account_num": account_num},
          {"risk_tier": prof.get("risk_tier")})
    return json.dumps(prof)

@tool
def generate_report(transaction_id: str, account_num: str, risk_score: float,
                    decision: str, matched_rules: str, customer_context: str,
                    rationale: str, recommended_action: str) -> str:
    """Write the final structured investigation report for a transaction.

    Call this LAST, once you have the risk score, the matching rules, and the
    customer context. decision must be one of ESCALATE / MONITOR / CLEAR.
    matched_rules and customer_context are short summaries of what you found.
    The report is persisted to S3 and returned as JSON."""
    report = {
        "transaction_id": transaction_id,
        "account_num": account_num,
        "risk_score": round(float(risk_score), 4),
        "decision": decision.upper().strip(),
        "matched_rules": matched_rules,
        "customer_context": customer_context,
        "rationale": rationale,
        "recommended_action": recommended_action,
        "generated_ts": pd.Timestamp.utcnow().isoformat(),
        "run_id": _audit_seq.get("run_id", ""),
    }
    key = f"{S3_PREFIX}/reports/{transaction_id}.json"
    s3.put_object(Bucket=SHARED_BUCKET, Key=key,
                  Body=json.dumps(report, indent=2).encode())
    REPORTS[transaction_id] = report
    audit("generate_report", transaction_id,
          {"decision": report["decision"]},
          {"s3": f"s3://{SHARED_BUCKET}/{key}"})
    return json.dumps(report)

AGENT_TOOLS = [invoke_fraud_model, retrieve_rules, get_customer_profile, generate_report]
print("tools ready:", [t.name for t in AGENT_TOOLS])


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 7 — The agent loop (LangGraph + Claude Sonnet 4.5)
# MAGIC
# MAGIC Reason, Act, and Iterate - ReAct Agent
# MAGIC
# MAGIC A single ReAct agent loop. We hand the four tools to `create_react_agent` and let the model decide the
# MAGIC order — look up the risk score, retrieve the rules that match what it sees, pull the customer profile if
# MAGIC context is needed, and finally write the report. **A fixed script is not an agent; the model picks the
# MAGIC sequence.**

# COMMAND ----------

from langchain_aws import ChatBedrockConverse
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.prebuilt import create_react_agent

llm = ChatBedrockConverse(
    model=AGENT_MODEL_ID,
    region_name=AWS_REGION,
    temperature=0.0,
    max_tokens=2048,
)

AGENT_SYSTEM_PROMPT = (
    "You are a senior fraud investigator at a card issuer. For each transaction you receive:\n"
    "1. Call invoke_fraud_model to get the model risk score and the transaction's key signals.\n"
    "2. Based on those signals, call retrieve_rules with a focused description of the suspicious\n"
    "   pattern to find the fraud policies that apply.\n"
    "3. Call get_customer_profile (using the account_num) to judge whether this is anomalous for\n"
    "   this customer.\n"
    "4. Finally call generate_report exactly once with: a decision of ESCALATE, MONITOR, or CLEAR;\n"
    "   short summaries of the matched rules and customer context; a rationale that cites the\n"
    "   specific rules and signals; and a concrete recommended_action.\n"
    "Decide ESCALATE for clear policy violations or high model risk, MONITOR for ambiguous cases,\n"
    "CLEAR when the activity is consistent with the customer's profile. Be concise and evidence-driven."
)

fraud_agent = create_react_agent(model=llm, tools=AGENT_TOOLS, prompt=AGENT_SYSTEM_PROMPT)
print("agent ready with tools:", [t.name for t in AGENT_TOOLS])


# COMMAND ----------

def investigate(transaction_id: str, verbose: bool = True) -> dict:
    """Run one full agent investigation for a transaction. Returns the report dict."""
    account_num = str(fad_transactions_df_indexed.loc[transaction_id, "account_num"])
    run_id = f"student-{STUDENT_NUM}-{transaction_id}-{int(time.time())}"
    start_audit_stream(run_id)

    task = (f"Investigate transaction {transaction_id} (account {account_num}). "
            f"Decide whether it is fraudulent and write the investigation report.")
    result = fraud_agent.invoke({"messages": [HumanMessage(content=task)]})

    if verbose:
        used = [m.tool_calls[0]["name"] for m in result["messages"]
                if getattr(m, "tool_calls", None)]
        print(f"{transaction_id}: tool sequence -> {used}")
    return REPORTS.get(transaction_id, {"transaction_id": transaction_id,
                                         "decision": "UNKNOWN",
                                         "note": result["messages"][-1].content[:300]})

# Smoke-test the agent on one known-fraud transaction.
_sample_fraud = fad_transactions_df_indexed[fad_transactions_df_indexed["label_type_cd"] == 1]["transaction_id"].iloc[0]
demo_report = investigate(_sample_fraud)
print("\nDEMO REPORT")
print(json.dumps(demo_report, indent=2)[:1200])


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 8 — Run the batch end-to-end
# MAGIC
# MAGIC The production shape: **score the whole batch → filter the high-risk subset → investigate each with the
# MAGIC agent → collect one report per flagged transaction.** We score a sample batch through the endpoint, take
# MAGIC everything at or above `HIGH_RISK_THRESHOLD`, and let the agent investigate each one.

# COMMAND ----------

HIGH_RISK_THRESHOLD = 0.7
BATCH_SIZE          = 300     # sample-batch size to score
MAX_INVESTIGATIONS  = 8       # cap agent runs to respect the hackathon clock

# Take a sample batch (mix in known fraud so the batch has high-risk cases to find).
fraud_ids = pdf_indexed[pdf_indexed["label_type_cd"] == 1]["transaction_id"]
rng = np.random.RandomState(7)
batch_ids = list(pd.Index(rng.choice(pdf_indexed["transaction_id"].values,
                                     size=BATCH_SIZE, replace=False))
                 .union(pd.Index(fraud_ids.sample(min(20, len(fraud_ids)),
                                                   random_state=7).values)))
batch = pdf_indexed.loc[batch_ids]

# Score the whole batch through the endpoint in one pass.
batch_scores = score_frame(featurize(batch))
batch = batch.assign(risk_score=batch_scores)

high_risk = batch[batch["risk_score"] >= HIGH_RISK_THRESHOLD] \
                .sort_values("risk_score", ascending=False)
print(f"batch scored: {len(batch)}  |  high-risk (>= {HIGH_RISK_THRESHOLD}): {len(high_risk)}")
print(high_risk[["transaction_id", "account_num", "risk_score",
                 "tran_amt", "mrch_cntry_cd", "label_type_cd"]].head(10).to_string(index=False))


# COMMAND ----------

# Investigate the top high-risk transactions with the agent.
to_investigate = high_risk["transaction_id"].head(MAX_INVESTIGATIONS).tolist()
print(f"Investigating {len(to_investigate)} high-risk transactions...\n")

batch_reports = []
for txn in to_investigate:
    rep = investigate(txn, verbose=True)
    batch_reports.append(rep)

print("\nINVESTIGATION SUMMARY")
print("=" * 70)
for r in batch_reports:
    print(f"{r['transaction_id']}  {str(r.get('decision','?')):8s}  "
          f"risk={r.get('risk_score','?')}  -> {str(r.get('recommended_action',''))[:60]}")


# COMMAND ----------

# Persist the batch summary alongside the per-transaction reports already in S3.
summary = {
    "student": STUDENT_NUM,
    "batch_size": int(len(batch)),
    "high_risk_count": int(len(high_risk)),
    "investigated": len(batch_reports),
    "decisions": pd.Series([r.get("decision") for r in batch_reports]).value_counts().to_dict(),
    "reports": batch_reports,
    "generated_ts": pd.Timestamp.utcnow().isoformat(),
}
summary_key = f"{S3_PREFIX}/reports/_batch_summary.json"
s3.put_object(Bucket=SHARED_BUCKET, Key=summary_key,
              Body=json.dumps(summary, indent=2).encode())
print("batch summary ->", f"s3://{SHARED_BUCKET}/{summary_key}")
print("decisions:", summary["decisions"])


# COMMAND ----------

# Read back the CloudWatch audit trail for the most recent investigation (proof of the trace).
last_run = _audit_seq.get("run_id")
print("Audit trail for run:", last_run, "\n")
ev = logs.get_log_events(logGroupName=LOG_GROUP, logStreamName=last_run,
                         startFromHead=True)["events"]
for e in ev:
    m = json.loads(e["message"])
    print(f"  {m['step']:22s} txn={m.get('txn','')}  {json.dumps(m['result_summary'])}")


# COMMAND ----------

# MAGIC %md
# MAGIC # Section 9 — (Stretch) Orchestrate the batch as an MWAA Airflow DAG
# MAGIC
# MAGIC We wrap the pipeline as a DAG on the live **MWAA** environment, using the Week 21–22
# MAGIC **author → upload → poll → trigger** pattern. The DAG shape:
# MAGIC
# MAGIC ```
# MAGIC score_batch ──► decide_high_risk (BranchPythonOperator)
# MAGIC                      ├── has_high_risk ──► investigate ──► write_summary
# MAGIC                      └── no_high_risk  ─────────────────►  write_summary
# MAGIC                                                             (join: none_failed_min_one_success)
# MAGIC ```
# MAGIC
# MAGIC - **`score_batch`** reads a CSV the notebook drops in S3, calls the SageMaker endpoint per row, writes a
# MAGIC   predictions JSONL, and XComs the S3 URI.
# MAGIC - **`decide_high_risk`** branches on whether any row clears the threshold.
# MAGIC - **`investigate`** runs a **boto3-only** investigation per high-risk row (KB `retrieve` → Claude
# MAGIC   `converse` → structured report to S3). We keep this task dependency-free so it runs on stock MWAA
# MAGIC   workers; the notebook's LangGraph agent is the "live" agent, the DAG is the orchestrated batch version.
# MAGIC - **`write_summary`** writes a run summary marker to S3.
# MAGIC
# MAGIC MWAA syncs DAG code from S3 every ~30s, so we upload, poll until registered, then trigger via the REST
# MAGIC API — exactly the helpers from Week 21.

# COMMAND ----------

# --- Week 21 author-upload-poll-trigger helpers (verbatim shape) -----------
MWAA_ENV    = "bread-academy-airflow"
DAGS_BUCKET = "bread-academy-airflow-dags"
DAG_PREFIX  = f"dags/student_{STUDENT_NUM}"
DAG_ID      = f"capstone1_student_{STUDENT_NUM}"

def _mwaa_rest(method, path, body=None):
    kw = {"Name": MWAA_ENV, "Method": method, "Path": path}
    if body is not None:
        kw["Body"] = body
    transient = (
        mwaa.exceptions.RestApiClientException,
        mwaa.exceptions.RestApiServerException,
        mwaa.exceptions.ResourceNotFoundException,
        mwaa.exceptions.InternalServerException,
        mwaa.exceptions.ServiceUnavailableException,
    )
    try:
        return mwaa.invoke_rest_api(**kw)
    except transient:
        return {"RestApiStatusCode": 0, "RestApiResponse": {}}

def poll_until_registered(dag_id, max_iters=40, sleep_s=5):
    for i in range(max_iters):
        if _mwaa_rest("GET", f"/dags/{dag_id}")["RestApiStatusCode"] == 200:
            print(f"DAG {dag_id} registered after ~{i*sleep_s}s")
            return
        time.sleep(sleep_s)
    raise RuntimeError(f"{dag_id} not registered; check Browse -> DAG Import Errors in the UI.")

def unpause_dag(dag_id):
    for _ in range(6):
        if _mwaa_rest("PATCH", f"/dags/{dag_id}", {"is_paused": False})["RestApiStatusCode"] == 200:
            return
        time.sleep(5)

def trigger_dag(dag_id, conf=None):
    run_id = f"student-{STUDENT_NUM}-{int(time.time())}"
    unpause_dag(dag_id)
    body = {"dag_run_id": run_id}
    if conf is not None:
        body["conf"] = conf
    resp = _mwaa_rest("POST", f"/dags/{dag_id}/dagRuns", body)
    if resp["RestApiStatusCode"] not in (200, 201):
        raise RuntimeError(f"trigger failed: {resp}")
    print(f"Triggered {dag_id} run_id={run_id}")
    return run_id

def wait_for_dag(dag_id, run_id, cap_s=900, sleep_s=10):
    waited = 0
    while waited < cap_s:
        state = _mwaa_rest("GET", f"/dags/{dag_id}/dagRuns/{run_id}")["RestApiResponse"].get("state")
        if state in ("success", "failed"):
            print(f"Run {run_id} finished: {state} (~{waited}s)")
            return state
        time.sleep(sleep_s); waited += sleep_s
    raise RuntimeError(f"Run {run_id} did not finish in {cap_s}s.")

print("MWAA helpers defined.")


# COMMAND ----------

# --- Drop a batch CSV in S3 for the DAG to score ---------------------------
# Reuse the same sample batch; the DAG reads this exact key.
DAG_INPUT_KEY = f"{S3_PREFIX}/airflow/batch_input.csv"
dag_batch = batch[["transaction_id", "account_num"]].copy()
# Include the raw fields the DAG needs to featurize each row itself.
raw_cols = list(set(["transaction_id", "account_num"] + NUMERIC_COLS +
                    ["card_prsn_cd", "mrch_cntry_cd", "merch_cat_code_cd",
                     "cvv2_cvc2_otcm_cd", "addr_vrfc_otcm_cd", "entry_mode_ind",
                     "mrch_nm"]) & set(pdf.columns))
dag_input_df = pdf_indexed.loc[batch["transaction_id"], raw_cols]
csv_buf = dag_input_df.to_csv(index=False)
s3.put_object(Bucket=SHARED_BUCKET, Key=DAG_INPUT_KEY, Body=csv_buf.encode())
print("DAG input ->", f"s3://{SHARED_BUCKET}/{DAG_INPUT_KEY}", f"({len(dag_input_df)} rows)")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Author the DAG source
# MAGIC
# MAGIC Everything the workers need is baked into the DAG via f-string interpolation (endpoint name, bucket,
# MAGIC KB id, model id, feature vocabularies, threshold). Literal Python braces inside the DAG body are doubled
# MAGIC (`{{ }}`) because the outer string is an f-string.

# COMMAND ----------

dag_code = f"""
from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.utils.trigger_rule import TriggerRule
from datetime import datetime
import boto3, csv, io, json, time

REGION        = "{AWS_REGION}"
SHARED_BUCKET = "{SHARED_BUCKET}"
S3_PREFIX     = "{S3_PREFIX}"
ENDPOINT_NAME = "{ENDPOINT_NAME}"
KB_ID         = "{KB_ID}"
AGENT_MODEL   = "{AGENT_MODEL_ID}"
INPUT_KEY     = "{DAG_INPUT_KEY}"
THRESHOLD     = {HIGH_RISK_THRESHOLD}
MAX_INVEST    = {MAX_INVESTIGATIONS}

FEATURE_COLUMNS = {FEATURE_COLUMNS!r}
NUMERIC_COLS    = {NUMERIC_COLS!r}
ENTRY_MODES     = {sorted(list(ENTRY_MODES))!r}
HIGH_RISK_MCCS  = {sorted(list(HIGH_RISK_MCCS))!r}

PRED_KEY    = f"{{S3_PREFIX}}/airflow/predictions.jsonl"
SUMMARY_KEY = f"{{S3_PREFIX}}/airflow/_run_summary.json"


def _num(v):
    try:
        return float(v)
    except Exception:
        return 0.0


def _featurize_row(r):
    f = {{}}
    for c in NUMERIC_COLS:
        f[c] = _num(r.get(c, 0))
    f["card_not_present"] = 1 if str(r.get("card_prsn_cd", "")).upper() == "N" else 0
    f["foreign_country"]  = 1 if str(r.get("mrch_cntry_cd", "US")).upper() != "US" else 0
    mcc = int(_num(r.get("merch_cat_code_cd", 0)))
    f["merch_cat_code_cd"] = mcc
    f["high_risk_mcc"] = 1 if mcc in set(HIGH_RISK_MCCS) else 0
    cvv = str(r.get("cvv2_cvc2_otcm_cd", "")).upper()
    avs = str(r.get("addr_vrfc_otcm_cd", "")).upper()
    f["cvv_fail"] = 0 if cvv in ("M", "MATCH", "Y") else 1
    f["avs_fail"] = 0 if avs in ("M", "MATCH", "Y") else 1
    em = str(r.get("entry_mode_ind", "")).lower()
    for m in ENTRY_MODES:
        f["entry_mode__" + m] = 1 if em == m else 0
    return [float(f.get(c, 0.0)) for c in FEATURE_COLUMNS]


def score_batch(**context):
    s3 = boto3.client("s3", region_name=REGION)
    rt = boto3.client("sagemaker-runtime", region_name=REGION)
    body = s3.get_object(Bucket=SHARED_BUCKET, Key=INPUT_KEY)["Body"].read().decode()
    rows = list(csv.DictReader(io.StringIO(body)))
    preds = []
    for r in rows:
        line = ",".join(str(v) for v in _featurize_row(r))
        resp = rt.invoke_endpoint(EndpointName=ENDPOINT_NAME, ContentType="text/csv", Body=line)
        score = float(resp["Body"].read().decode().strip().split(",")[0])
        preds.append({{"transaction_id": r["transaction_id"],
                       "account_num": r.get("account_num", ""),
                       "risk_score": score}})
    out = "\\n".join(json.dumps(p) for p in preds)
    s3.put_object(Bucket=SHARED_BUCKET, Key=PRED_KEY, Body=out.encode())
    high = [p for p in preds if p["risk_score"] >= THRESHOLD]
    context["ti"].xcom_push(key="high_risk_count", value=len(high))
    return f"s3://{{SHARED_BUCKET}}/{{PRED_KEY}}"


def decide_high_risk(**context):
    n = context["ti"].xcom_pull(task_ids="score_batch", key="high_risk_count") or 0
    return "investigate" if n > 0 else "no_high_risk"


def _retrieve_rules(bart, query):
    resp = bart.retrieve(knowledgeBaseId=KB_ID, retrievalQuery={{"text": query}},
                         retrievalConfiguration={{"vectorSearchConfiguration": {{"numberOfResults": 3}}}})
    return [h["content"]["text"][:500] for h in resp.get("retrievalResults", [])]


def investigate(**context):
    s3   = boto3.client("s3", region_name=REGION)
    bart = boto3.client("bedrock-agent-runtime", region_name=REGION)
    brt  = boto3.client("bedrock-runtime", region_name=REGION)
    pred_uri = context["ti"].xcom_pull(task_ids="score_batch")
    bucket, _, key = pred_uri.replace("s3://", "").partition("/")
    lines = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode().strip().splitlines()
    preds = sorted((json.loads(l) for l in lines),
                   key=lambda p: p["risk_score"], reverse=True)
    high = [p for p in preds if p["risk_score"] >= THRESHOLD][:MAX_INVEST]

    reports = []
    for p in high:
        txn = p["transaction_id"]
        rules = _retrieve_rules(bart, f"transaction with fraud risk {{p['risk_score']:.2f}} -- "
                                       "which fraud policies apply?")
        prompt = ("You are a fraud investigator. Given the model risk score and the retrieved "
                  "fraud rules, return ONLY a JSON object with keys decision (ESCALATE/MONITOR/CLEAR), "
                  "rationale, recommended_action.\\n\\n"
                  f"transaction_id: {{txn}}\\nrisk_score: {{p['risk_score']:.4f}}\\n"
                  "rules:\\n- " + "\\n- ".join(rules))
        resp = brt.converse(modelId=AGENT_MODEL,
                            messages=[{{"role": "user", "content": [{{"text": prompt}}]}}],
                            inferenceConfig={{"maxTokens": 500, "temperature": 0.0}})
        text = resp["output"]["message"]["content"][0]["text"]
        try:
            verdict = json.loads(text[text.find("{{"): text.rfind("}}") + 1])
        except Exception:
            verdict = {{"decision": "MONITOR", "rationale": text[:300], "recommended_action": "manual review"}}
        report = {{"transaction_id": txn, "account_num": p["account_num"],
                   "risk_score": p["risk_score"], **verdict,
                   "generated_ts": datetime.utcnow().isoformat()}}
        s3.put_object(Bucket=SHARED_BUCKET, Key=f"{{S3_PREFIX}}/airflow/reports/{{txn}}.json",
                      Body=json.dumps(report, indent=2).encode())
        reports.append(report)
    context["ti"].xcom_push(key="investigated", value=len(reports))
    return len(reports)


def write_summary(**context):
    s3 = boto3.client("s3", region_name=REGION)
    n_high = context["ti"].xcom_pull(task_ids="score_batch", key="high_risk_count") or 0
    n_inv  = context["ti"].xcom_pull(task_ids="investigate", key="investigated") or 0
    summary = {{"dag_id": "{DAG_ID}", "high_risk_count": n_high,
                "investigated": n_inv, "ts": datetime.utcnow().isoformat()}}
    s3.put_object(Bucket=SHARED_BUCKET, Key=SUMMARY_KEY,
                  Body=json.dumps(summary, indent=2).encode())
    return SUMMARY_KEY


with DAG(
    dag_id="{DAG_ID}",
    start_date=datetime(2024, 1, 1),
    schedule=None,
    catchup=False,
    tags=["capstone1", "fraud", "student_{STUDENT_NUM}"],
) as dag:
    t_score = PythonOperator(task_id="score_batch", python_callable=score_batch)
    t_branch = BranchPythonOperator(task_id="decide_high_risk", python_callable=decide_high_risk)
    t_invest = PythonOperator(task_id="investigate", python_callable=investigate)
    from airflow.operators.empty import EmptyOperator
    t_none = EmptyOperator(task_id="no_high_risk")
    t_summary = PythonOperator(
        task_id="write_summary", python_callable=write_summary,
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

    t_score >> t_branch >> [t_invest, t_none]
    t_invest >> t_summary
    t_none >> t_summary
"""
print(f"DAG source built ({len(dag_code)} chars). Preview head:\n")
print(dag_code[:600])


# COMMAND ----------

# --- Upload -> poll -> trigger -> wait -------------------------------------
s3.put_object(Bucket=DAGS_BUCKET, Key=f"{DAG_PREFIX}/capstone1.py", Body=dag_code.encode())
print("Uploaded DAG to", f"s3://{DAGS_BUCKET}/{DAG_PREFIX}/capstone1.py")

poll_until_registered(DAG_ID)
run_id = trigger_dag(DAG_ID)
state  = wait_for_dag(DAG_ID, run_id, cap_s=1200)
assert state == "success", f"DAG ended in state {state} -- check task logs in the Airflow UI."
print("\nDAG run succeeded.")


# COMMAND ----------

# --- Read back what the DAG produced ---------------------------------------
summ = json.loads(s3.get_object(
    Bucket=SHARED_BUCKET, Key=f"{S3_PREFIX}/airflow/_run_summary.json")["Body"].read())
print("Airflow run summary:", json.dumps(summ, indent=2))

# List the reports the DAG wrote.
objs = s3.list_objects_v2(Bucket=SHARED_BUCKET,
                          Prefix=f"{S3_PREFIX}/airflow/reports/").get("Contents", [])
print(f"\nDAG wrote {len(objs)} reports:")
for o in objs[:10]:
    print("  s3://" + SHARED_BUCKET + "/" + o["Key"])


# COMMAND ----------

# MAGIC %md
# MAGIC # Deliverables checklist & wrap-up
# MAGIC
# MAGIC What this notebook produced:
# MAGIC
# MAGIC - ✅ **Trained fraud model deployed to a SageMaker endpoint**, evaluated on a stratified holdout
# MAGIC   (AUC / precision / recall / confusion matrix) — Sections 3–4.
# MAGIC - ✅ **Bedrock Knowledge Base over `fraud_rules/`**, retrieval validated on sample queries — Section 5.
# MAGIC - ✅ **Agent loop wiring all four tools** (`invoke_fraud_model`, `retrieve_rules`,
# MAGIC   `get_customer_profile`, `generate_report`); the model chooses its own sequence — Sections 6–7.
# MAGIC - ✅ **One structured investigation report per high-risk transaction** in a sample batch, persisted to
# MAGIC   `s3://{bucket}/student-NN/reports/` — Section 8.
# MAGIC - ✅ **CloudWatch audit trail** of every tool call, per run — Sections 6 & 8.
# MAGIC - ✅ **(Stretch) Airflow DAG** running the batch end-to-end on MWAA — Section 9.
# MAGIC
# MAGIC All artifacts live under your `student-{NN}/` prefix in the course S3 bucket (`reports/`, `airflow/`,
# MAGIC `sagemaker/`) and in the CloudWatch log group `/bread-academy/capstone1/student-{NN}`.

# COMMAND ----------

# Quick inventory of everything written to S3 under your prefix.
print(f"Artifacts under s3://{SHARED_BUCKET}/{S3_PREFIX}/\n")
token = None
while True:
    kw = {"Bucket": SHARED_BUCKET, "Prefix": f"{S3_PREFIX}/"}
    if token: kw["ContinuationToken"] = token
    resp = s3.list_objects_v2(**kw)
    for o in resp.get("Contents", []):
        print(f"  {o['Size']:>9d}  {o['Key']}")
    if not resp.get("IsTruncated"): break
    token = resp["NextContinuationToken"]


# COMMAND ----------

# MAGIC %md
# MAGIC ## Cleanup (cost control)
# MAGIC
# MAGIC The real-time endpoint bills per hour while it exists. **Delete it when you're done** (keep it if you
# MAGIC still want to demo the agent). The KB, S3 artifacts, and CloudWatch logs are cheap to leave in place;
# MAGIC remove them too if your instructor asks.

# COMMAND ----------

# --- Delete the SageMaker endpoint (uncomment to run) ----------------------
# sagemaker_client.delete_endpoint(EndpointName=ENDPOINT_NAME)
# try:
#     cfg = sagemaker_client.describe_endpoint_config  # endpoint config + model linger; remove if desired
# except Exception:
#     pass
# print(f"Deleted endpoint {ENDPOINT_NAME}")

# --- Pause your Airflow DAG so it does not get retriggered (optional) -------
# _mwaa_rest("PATCH", f"/dags/{DAG_ID}", {"is_paused": True})
# print(f"Paused DAG {DAG_ID}")

print("Cleanup cell ready — uncomment the lines above to tear down billable resources.")
