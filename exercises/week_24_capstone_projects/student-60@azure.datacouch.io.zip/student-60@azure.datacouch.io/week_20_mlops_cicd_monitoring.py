# Databricks notebook source
# MAGIC %md
# MAGIC # Week 20: MLOps - CI/CD, Monitoring, and LLM Observability
# MAGIC
# MAGIC ## Where we are
# MAGIC
# MAGIC Last week you turned the fraud classifier into a production asset: a SageMaker training job, an MLflow run, a model registered in the Model Registry, a deployed endpoint, and a `classify_with_finetuned_model` tool plugged into `week19_supervisor`. That is the artifact. This week we operate it.
# MAGIC
# MAGIC ## Learning objectives
# MAGIC
# MAGIC By the end of this lab you will be able to:
# MAGIC
# MAGIC 1. Add OpenTelemetry-based tracing to a Strands agent and view per-decision traces in Langfuse without modifying agent code
# MAGIC 2. Verify SageMaker data capture on an endpoint and schedule a Model Monitor job
# MAGIC 3. Create a CloudWatch alarm on endpoint latency that notifies an SNS topic
# MAGIC 4. Explain when to reach for LiteLLM versus a full agent framework
# MAGIC
# MAGIC ## The mental model
# MAGIC
# MAGIC Week 18 measured RAG quality OFFLINE on a fixed eval set with RAGAS. That tells you what the system can do in a lab. Week 20 measures the SAME system ONLINE on live traffic with Langfuse, Model Monitor, and CloudWatch. That tells you what the system is actually doing right now, in production, on real users.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Environment Setup
# MAGIC
# MAGIC **Platform**: Azure Databricks (plain Runtime 15.4 LTS, Python 3.10 - not the ML runtime).
# MAGIC
# MAGIC The next code cell uses `%pip install` (a Databricks magic) to install or upgrade the libraries this notebook needs. The default cluster `boto3` predates the Bedrock Converse API, so we upgrade it here. After the install finishes, `dbutils.library.restartPython()` restarts the Python kernel so the new versions are picked up - once it restarts, re-run from the top.
# MAGIC
# MAGIC **Libraries installed**:
# MAGIC
# MAGIC - `numpy<2`, `pandas<2` (pinned first to protect the runtime pyarrow)
# MAGIC - `boto3>=1.36` (Bedrock Converse API support)
# MAGIC - `sagemaker>=2.230,<3` (v3 breaks `from sagemaker import get_execution_role`)
# MAGIC - `strands-agents>=1.37,<2`
# MAGIC - `strands-agents-tools>=0.2`
# MAGIC - `opentelemetry-api`, `opentelemetry-sdk`, `opentelemetry-exporter-otlp` (required by Strands' OTLP exporter in Part 1; not pulled transitively)
# MAGIC - `litellm>=1.50` (unified LLM interface, Part 4)
# MAGIC - `langfuse>=2.50,<3` (observability backend, Part 1)
# MAGIC
# MAGIC **Already on the cluster** (do NOT pip-install these - reinstalling them breaks the DBR REPL): `pyspark`.
# MAGIC
# MAGIC Run the cell below, restart the kernel when prompted, then continue.
# MAGIC

# COMMAND ----------

# Install/upgrade the libraries this notebook needs. Safe to re-run.
# Databricks will ask you to restart the kernel afterwards - restartPython does that.
# This is plain DBR 15.4 LTS (not the ML runtime). numpy<2/pandas<2 are pinned
# FIRST to protect the runtime pyarrow so no transitive dependency bumps numpy to
# 2.x and crashes the kernel. The opentelemetry-exporter-otlp package is REQUIRED
# by StrandsTelemetry().setup_otlp_exporter() in Part 1; strands-agents does not
# pull it transitively.
%pip install --quiet "numpy<2" "pandas<2" "boto3>=1.36" "sagemaker>=2.230,<3" "strands-agents>=1.37,<2" "strands-agents-tools>=0.2" "opentelemetry-api" "opentelemetry-sdk" "opentelemetry-exporter-otlp" "litellm>=1.50" "langfuse>=2.50,<3"

dbutils.library.restartPython()

# Verify versions (use importlib.metadata - never pkg.__version__).
from importlib.metadata import version

for pkg in ["boto3", "sagemaker", "strands-agents", "litellm", "langfuse",
            "opentelemetry-exporter-otlp"]:
    try:
        print(f"{pkg:30s} {version(pkg)}")
    except Exception as e:
        print(f"{pkg:30s} NOT INSTALLED ({e})")


# COMMAND ----------

# Standard MLOps setup on Databricks: pull secrets, build boto3 clients.

import os
import json
import base64
import boto3

# Per-student AWS keys live in aws-course-creds-NN; class-wide config is in
# aws-course-shared. Derive this student's scope from the Databricks identity.
_user = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook().getContext().userName().get()
)
_num = _user.split("@")[0].split("-")[1] if _user.startswith("student-") else "01"
creds_scope = f"aws-course-creds-{_num}"

# Long-lived IAM-user keys (no AWS_SESSION_TOKEN).
AWS_ACCESS_KEY_ID     = dbutils.secrets.get(scope=creds_scope, key="aws-access-key-id")
AWS_SECRET_ACCESS_KEY = dbutils.secrets.get(scope=creds_scope, key="aws-secret-access-key")
AWS_REGION            = dbutils.secrets.get(scope="aws-course-shared", key="aws-region")

os.environ["AWS_ACCESS_KEY_ID"] = AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = AWS_SECRET_ACCESS_KEY
os.environ["AWS_REGION"] = AWS_REGION
os.environ["AWS_DEFAULT_REGION"] = AWS_REGION
# LiteLLM (Part 4) reads AWS_REGION_NAME specifically.
os.environ["AWS_REGION_NAME"] = AWS_REGION

# Clients used across the notebook
sagemaker_client = boto3.client("sagemaker", region_name=AWS_REGION)
sm_runtime = boto3.client("sagemaker-runtime", region_name=AWS_REGION)
cloudwatch = boto3.client("cloudwatch", region_name=AWS_REGION)
s3 = boto3.client("s3", region_name=AWS_REGION)

# This class has 3 cohorts of 22 students. Each cohort gets its OWN endpoint
# so 60 people never contend on one. The endpoint name follows the pattern
# the instructor deployed: fraud-classifier-endpoint-cohort-{1,2,3}.
# Cohort is derived from the student number: 1-22 -> 1, 23-44 -> 2, 45-66 -> 3.
cohort = (int(_num) - 1) // 22 + 1
ENDPOINT_NAME_BASE = dbutils.secrets.get(
    scope="aws-course-shared", key="endpoint-name-base")
ENDPOINT_NAME = f"{ENDPOINT_NAME_BASE}-{cohort}"

# Carried over from Week 19
BEDROCK_MODEL_ID = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"

print("AWS region:", AWS_REGION)
print("Cohort:", cohort)
print("Endpoint:", ENDPOINT_NAME)
print("Bedrock model:", BEDROCK_MODEL_ID)

# COMMAND ----------

# Pre-flight: fail loud now if anything we depend on is missing.

# 1. Endpoint is in service
resp = sagemaker_client.describe_endpoint(EndpointName=ENDPOINT_NAME)
assert resp["EndpointStatus"] == "InService", (
    f"Endpoint {ENDPOINT_NAME} is {resp['EndpointStatus']}. "
    "Ask your instructor to redeploy the Week 19 endpoint."
)
print("Endpoint status:", resp["EndpointStatus"])

# 2. Bedrock LLM responds
bedrock_runtime = boto3.client("bedrock-runtime", region_name=AWS_REGION)
try:
    bedrock_runtime.converse(
        modelId=BEDROCK_MODEL_ID,
        messages=[{"role": "user", "content": [{"text": "ping"}]}],
        inferenceConfig={"maxTokens": 10, "temperature": 0},
    )
    print("Bedrock LLM probe: ok")
except Exception as e:
    print("Ask your instructor to enable Bedrock access for", BEDROCK_MODEL_ID)
    raise

print("Pre-flight checks passed.")

# COMMAND ----------

# Week 19 fraud-investigation supervisor, rebuilt INLINE so this notebook is
# fully self-contained (no %run, no external helper notebook). It is the same
# agent we operated in Week 19: a Strands Agent backed by a Bedrock model,
# wired to a set of fraud-investigation tools. We trace THIS agent in Part 1 -
# we do NOT change it once Langfuse is wired.
#
# The supervisor has three tools:
#   1. classify_with_finetuned_model - calls the Week 19 SageMaker endpoint
#   2. check_fraud_policy            - looks up the Bread Financial fraud rules
#   3. score_transaction_risk        - a small deterministic heuristic check
# The LLM decides which tools to call and in what order; each tool call shows
# up as its own span in Langfuse.

import json
from strands import Agent, tool
from strands.models import BedrockModel


@tool
def classify_with_finetuned_model(narrative: str) -> str:
    """Classify a transaction narrative as fraud or not_fraud.

    Invokes the Week 19 fine-tuned SageMaker endpoint (a HuggingFace
    DistilBERT text classifier). Pass the free-text transaction narrative;
    the endpoint returns the predicted label and a confidence score.

    Args:
        narrative: Free-text description of the transaction.

    Returns:
        The raw JSON string returned by the endpoint, e.g.
        '[{"label": "fraud", "score": 0.93}]'.
    """
    out = sm_runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        Body=json.dumps({"inputs": narrative}),
    )
    return out["Body"].read().decode()


@tool
def check_fraud_policy(topic: str) -> str:
    """Look up the Bread Financial fraud-handling policy for a topic.

    Use this to find the documented rule for a situation before recommending
    an action, so the recommendation is grounded in policy and auditable.

    Args:
        topic: A short policy topic such as 'high amount', 'cross border',
            'new customer', 'velocity', or 'card not present'.

    Returns:
        The policy text for that topic, or a default if none matches.
    """
    policy = {
        "high amount": (
            "Transactions over 1000 USD require a step-up review and a "
            "second approver before the funds are released."
        ),
        "cross border": (
            "Cross-border merchant transactions get a +1 risk weight and "
            "must be checked against the sanctioned-country list."
        ),
        "new customer": (
            "Accounts under 30 days old route to manual review regardless "
            "of the classifier score."
        ),
        "velocity": (
            "More than 3 transactions in 10 minutes from one account is a "
            "velocity flag; block pending customer contact."
        ),
        "card not present": (
            "Card-not-present purchases above 250 USD require a one-time "
            "passcode confirmation."
        ),
    }
    return policy.get(
        topic.lower(),
        "No specific policy for that topic; apply the standard risk score.",
    )


@tool
def score_transaction_risk(amount_usd: float, is_cross_border: bool,
                           account_age_days: int) -> str:
    """Compute a quick deterministic risk score for a transaction.

    This is a cheap heuristic the supervisor can use ALONGSIDE the fine-tuned
    classifier - the classifier reads the narrative text, this reads the
    structured fields. Combining a model signal with a rules signal is a
    common fraud-investigation pattern.

    Args:
        amount_usd: Transaction amount in US dollars.
        is_cross_border: True if the merchant is in a different country.
        account_age_days: Age of the customer account in days.

    Returns:
        A human-readable line with the numeric score and a LOW/MEDIUM/HIGH
        risk band.
    """
    score = 0
    if amount_usd > 1000:
        score += 2
    elif amount_usd > 250:
        score += 1
    if is_cross_border:
        score += 1
    if account_age_days < 30:
        score += 2
    band = "LOW" if score <= 1 else "MEDIUM" if score <= 3 else "HIGH"
    return f"risk_score={score} band={band}"


# The Bedrock-backed model. BedrockModel picks up the AWS credentials that
# Cell 1 exported to the environment; region_name keeps it pinned.
supervisor_model = BedrockModel(
    model_id=BEDROCK_MODEL_ID,
    region_name=AWS_REGION,
    temperature=0,
)

# A clear, role-specific system prompt. This is what makes the agent a
# fraud-investigation SUPERVISOR rather than a generic chatbot.
SUPERVISOR_SYSTEM_PROMPT = (
    "You are a fraud investigation supervisor at Bread Financial. "
    "For each transaction you are given, run a thorough investigation:\n"
    "1. Call classify_with_finetuned_model on the transaction narrative to "
    "get the model's fraud label and confidence.\n"
    "2. Call check_fraud_policy for any relevant topic (for example "
    "'high amount', 'cross border', 'new customer', 'velocity', or "
    "'card not present').\n"
    "3. When you know the amount, whether it is cross-border, and the "
    "account age, call score_transaction_risk for a second, rules-based "
    "signal.\n"
    "Then weigh the model signal against the policy and the risk score and "
    "give a final recommendation of APPROVE, REVIEW, or BLOCK, followed by "
    "one concise sentence of justification that cites the evidence you used."
)

# Build the agent. The variable name week19_supervisor is the contract every
# downstream cell depends on - do not rename it.
week19_supervisor = Agent(
    model=supervisor_model,
    tools=[classify_with_finetuned_model, check_fraud_policy, score_transaction_risk],
    system_prompt=SUPERVISOR_SYSTEM_PROMPT,
)

print("Supervisor ready:", type(week19_supervisor).__name__)
# Agent.tool_names is the public Strands API for the registered tool names.
print("Tools:", week19_supervisor.tool_names)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 1 - Langfuse observability (online traces)
# MAGIC
# MAGIC ### The problem
# MAGIC
# MAGIC You ship `week19_supervisor`. A user complains it gave a wrong fraud decision on transaction `txn_009812` at 14:32 UTC yesterday. You need to answer:
# MAGIC
# MAGIC - Which tools did the supervisor call, in what order?
# MAGIC - What did `classify_with_finetuned_model` return?
# MAGIC - Which policy did `check_fraud_policy` return?
# MAGIC - How long did the whole decision take, and what did it cost in tokens?
# MAGIC
# MAGIC Without tracing this is impossible. RAGAS does not help, because RAGAS is offline. You need a per-request flight recorder. That is Langfuse.
# MAGIC
# MAGIC ### How Strands + Langfuse fit together
# MAGIC
# MAGIC Strands emits OpenTelemetry spans for every model call and tool call. Langfuse speaks OTLP. We point Strands at Langfuse with five lines, then re-run the agent. No code change to the agent itself.
# MAGIC
# MAGIC The magic is in `StrandsTelemetry().setup_otlp_exporter()`. After that call, every `agent(prompt)` invocation produces a trace in the Langfuse UI. In the demo and Lab 1 below we go one step further and group each investigation's spans into a Langfuse **Session** keyed on the real `transaction_id`.

# COMMAND ----------

# Five-line wiring. After this cell every supervisor call shows up in Langfuse.

import base64
import os
from strands.telemetry import StrandsTelemetry

LANGFUSE_PUBLIC_KEY = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-public-key")
LANGFUSE_SECRET_KEY = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-secret-key")
LANGFUSE_HOST = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-host")

# Langfuse OTLP endpoint expects basic auth with base64(public:secret)
LANGFUSE_AUTH = base64.b64encode(
    f"{LANGFUSE_PUBLIC_KEY}:{LANGFUSE_SECRET_KEY}".encode()
).decode()

os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = LANGFUSE_HOST + "/api/public/otel"
os.environ["OTEL_EXPORTER_OTLP_HEADERS"] = f"Authorization=Basic {LANGFUSE_AUTH}"
# Optional: a service name groups traces in the UI
os.environ["OTEL_SERVICE_NAME"] = "bread-academy-week20"

StrandsTelemetry().setup_otlp_exporter()
print("Langfuse OTLP exporter wired. Host:", LANGFUSE_HOST)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Where the transactions live
# MAGIC
# MAGIC The fraud transactions are real rows in a Delta table:
# MAGIC `bread_academy.course_data.fraud_transactions`. This is the same table Week 19
# MAGIC trained the classifier on. It has about 45,000 rows. Each row has a real
# MAGIC `transaction_id` (format `txn_NNNNNN`), a `customer_id` (`cust_NNNNN`), the
# MAGIC `amount`, `merchant_country`, `merchant_category`, an `is_fraud` label, and a
# MAGIC free-text `narrative` describing the transaction.
# MAGIC
# MAGIC We query this table with Spark. The next cell is a DEMO: it pulls one real
# MAGIC fraud transaction and runs it through the supervisor. In Lab 1 you will query
# MAGIC a handful of real transactions yourself and investigate each one.

# COMMAND ----------

# DEMO: query one real fraud transaction from Spark, then investigate it
# as a Langfuse session.

# Pull a single real fraud row from the Delta table.
demo_row = (
    spark.read.table("bread_academy.course_data.fraud_transactions")
    .filter("is_fraud = 1")
    .select("transaction_id", "customer_id", "amount",
            "merchant_country", "narrative")
    .orderBy("transaction_id")
    .limit(1)
    .collect()[0]
)

print("Real transaction pulled from the table:")
print("  id        :", demo_row["transaction_id"])
print("  customer  :", demo_row["customer_id"])
print("  amount    :", demo_row["amount"])
print("  country   :", demo_row["merchant_country"])
print("  narrative :", demo_row["narrative"])
print()

# Build a fresh agent whose trace_attributes carry the Langfuse trace fields.
# Langfuse maps these EXACT OTEL attribute keys:
#   session.id          -> Langfuse Session
#   user.id             -> Langfuse User
#   langfuse.trace.tags -> Langfuse Tags  (NOTE: plain "tags" is NOT mapped)
# trace_attributes is a CONSTRUCTOR argument - it cannot be set on the
# agent(prompt) call.
demo_agent = Agent(
    model=supervisor_model,
    tools=[classify_with_finetuned_model, check_fraud_policy,
           score_transaction_risk],
    system_prompt=SUPERVISOR_SYSTEM_PROMPT,
    trace_attributes={
        "session.id": demo_row["transaction_id"],
        "user.id": demo_row["customer_id"],
        "langfuse.trace.tags": ["week20-demo"],
    },
)

# Build the prompt from the REAL narrative text.
demo_prompt = (
    f"Investigate transaction {demo_row['transaction_id']} for customer "
    f"{demo_row['customer_id']}. Transaction narrative: "
    f"\"{demo_row['narrative']}\". Use the fine-tuned classifier on the "
    "narrative, check policy, and recommend an action."
)

response = demo_agent(demo_prompt)
print(str(response)[:500])

# Force-flush the OTLP exporter. In a notebook the exporter batches spans;
# without this flush the trace may not reach Langfuse before you look.
from opentelemetry import trace as _otel_trace
_otel_trace.get_tracer_provider().force_flush()

print()
print("Open", LANGFUSE_HOST, "-> Sessions. Session", demo_row["transaction_id"],
      "groups:")
print("- the top-level supervisor span")
print("- each tool invocation as a child span")
print("- the bedrock-runtime converse calls with token counts")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Lab 1 - Investigate five real transactions, one Langfuse session each (15 min)
# MAGIC
# MAGIC You are the on-call data scientist. In the demo above you ran ONE real
# MAGIC transaction through the supervisor. Now do five, and make each investigation
# MAGIC its own Langfuse SESSION.
# MAGIC
# MAGIC #### Why sessions
# MAGIC
# MAGIC A single supervisor call produces a Langfuse TRACE. But one real
# MAGIC investigation can be several calls, and at production scale you want every
# MAGIC trace about transaction `txn_000037` grouped together so you can read the
# MAGIC whole investigation as one unit. That grouping is a Langfuse **Session**.
# MAGIC
# MAGIC Strands lets you stamp the Langfuse trace fields on an agent through the
# MAGIC `trace_attributes` constructor argument. Langfuse maps these EXACT keys:
# MAGIC
# MAGIC | trace_attributes key | Langfuse field |
# MAGIC |----------------------|----------------|
# MAGIC | `session.id` | Session |
# MAGIC | `user.id` | User |
# MAGIC | `langfuse.trace.tags` | Tags |
# MAGIC
# MAGIC ```python
# MAGIC agent = Agent(
# MAGIC     model=supervisor_model,
# MAGIC     tools=[...],
# MAGIC     system_prompt=SUPERVISOR_SYSTEM_PROMPT,
# MAGIC     trace_attributes={
# MAGIC         "session.id": "txn_000037",           # this trace joins session txn_000037
# MAGIC         "user.id": "cust_01437",
# MAGIC         "langfuse.trace.tags": ["week20-lab1"],
# MAGIC     },
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC Two things that bite people:
# MAGIC - The tags key is `langfuse.trace.tags`, NOT plain `tags`. A plain `tags`
# MAGIC   key is silently dropped into metadata and never shows as a Langfuse Tag.
# MAGIC - `trace_attributes` is set at CONSTRUCTION time - you cannot pass it to
# MAGIC   `agent(prompt)`. To give each transaction its own session, build a fresh
# MAGIC   agent inside the loop, once per transaction.
# MAGIC - After your loop, force-flush the OTLP exporter so the traces actually
# MAGIC   reach Langfuse before you look (the exporter batches):
# MAGIC   ```python
# MAGIC   from opentelemetry import trace
# MAGIC   trace.get_tracer_provider().force_flush()
# MAGIC   ```
# MAGIC
# MAGIC #### Your task
# MAGIC
# MAGIC 1. Query five real fraud transactions from
# MAGIC    `bread_academy.course_data.fraud_transactions` (filter `is_fraud = 1`).
# MAGIC    Select `transaction_id`, `customer_id`, `amount`, `merchant_country`,
# MAGIC    and `narrative`.
# MAGIC 2. Loop over the five rows. For each one:
# MAGIC    - build a fresh `Agent` with `trace_attributes` whose `session.id` is
# MAGIC      that row's real `transaction_id`, `user.id` is its `customer_id`, and
# MAGIC      `langfuse.trace.tags` is `["week20-lab1"]`;
# MAGIC    - reuse `supervisor_model`, the three tools, and
# MAGIC      `SUPERVISOR_SYSTEM_PROMPT` from the supervisor cell;
# MAGIC    - build the prompt from the real `narrative` and invoke the agent.
# MAGIC 3. After the loop, force-flush the OTLP exporter.
# MAGIC 4. Open Langfuse and switch to the **Sessions** tab (not Traces). You should
# MAGIC    see five sessions, one per `transaction_id`. Open the slowest and answer:
# MAGIC    - Which transaction took the longest end-to-end?
# MAGIC    - Which tool dominated the latency for that transaction?
# MAGIC    - What were the total input and output tokens for the slowest one?
# MAGIC
# MAGIC Hints:
# MAGIC - `spark.read.table(...).filter("is_fraud = 1").select(...).limit(5).collect()`
# MAGIC   gives you five `Row` objects.
# MAGIC - The three tool functions (`classify_with_finetuned_model`,
# MAGIC   `check_fraud_policy`, `score_transaction_risk`) are already defined - pass
# MAGIC   them straight into the `tools=[...]` list.
# MAGIC
# MAGIC ### Stretch
# MAGIC
# MAGIC `trace_attributes` lands the fields on the agent's root span, which is
# MAGIC enough for the Sessions view. For production-grade filtering you want the
# MAGIC attributes on EVERY span. The OpenTelemetry way is a `BaggageSpanProcessor`
# MAGIC that copies baggage values onto all child spans. Read the Langfuse
# MAGIC "existing OTel setup" FAQ and describe how you would add it.
# MAGIC
# MAGIC ### Homework extension
# MAGIC
# MAGIC Pipe the production supervisor through Langfuse for 24 hours of real traffic
# MAGIC (simulated by replaying the `fraud_transactions` table), one session per
# MAGIC transaction. Build a Databricks SQL dashboard from the Langfuse exported
# MAGIC events to track p95 latency by tool.

# COMMAND ----------

# Lab 1 SOLUTION.
# Step 1: query five real fraud transactions from the Delta table.
# Step 2: loop. For each row build a FRESH agent whose trace_attributes
#         carry session.id = transaction_id, then invoke it.
# Step 3: force-flush the OTLP exporter so the traces reach Langfuse.

from strands import Agent
from opentelemetry import trace

# Step 1 - five real fraud rows. is_fraud = 1 keeps it to fraud cases;
# select the columns the supervisor's tools actually use.
lab_rows = (
    spark.read.table("bread_academy.course_data.fraud_transactions")
    .filter("is_fraud = 1")
    .select("transaction_id", "customer_id", "amount",
            "merchant_country", "narrative")
    .orderBy("transaction_id")
    .limit(5)
    .collect()
)

# Step 2 - one fresh agent per transaction so each investigation is its own
# Langfuse session. trace_attributes is constructor-only, so the agent must
# be rebuilt inside the loop to vary session.id. The tags key is
# langfuse.trace.tags - plain "tags" is not mapped by Langfuse.
results = []
for row in lab_rows:
    investigation_agent = Agent(
        model=supervisor_model,
        tools=[classify_with_finetuned_model, check_fraud_policy,
               score_transaction_risk],
        system_prompt=SUPERVISOR_SYSTEM_PROMPT,
        trace_attributes={
            "session.id": row["transaction_id"],
            "user.id": row["customer_id"],
            "langfuse.trace.tags": ["week20-lab1"],
        },
    )
    prompt = (
        f"Investigate transaction {row['transaction_id']} for customer "
        f"{row['customer_id']}. Transaction narrative: "
        f"\"{row['narrative']}\". Use the fine-tuned classifier on the "
        "narrative, check policy, and recommend an action."
    )
    out = investigation_agent(prompt)
    results.append({
        "transaction_id": row["transaction_id"],
        "amount": row["amount"],
        "text": str(out)[:200],
    })

# Step 3 - force-flush so batched OTLP spans reach Langfuse now.
trace.get_tracer_provider().force_flush()

print(f"Ran {len(results)} real transactions, one session each.")
for r in results:
    print(" ", r["transaction_id"], "amount", r["amount"])
print()
print("Done. Open", LANGFUSE_HOST, "-> Sessions to inspect.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Think about it
# MAGIC
# MAGIC Langfuse stores every prompt and every tool argument by default. A fraud transaction record contains a customer ID and a dollar amount. Is that PII for your jurisdiction? If it is, what would you change about this setup before pointing it at real production traffic? Consider redaction, self-hosted Langfuse, sampling, and retention windows.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 2 - SageMaker data capture and Model Monitor
# MAGIC
# MAGIC ### What Langfuse will NOT tell you
# MAGIC
# MAGIC Langfuse traces the supervisor's decisions. It does not watch the fine-tuned classifier endpoint at the input-feature level. If next month the distribution of `amount` shifts because of a new product launch, the endpoint will keep returning predictions and Langfuse will keep showing happy traces, while the classifier silently goes off the rails.
# MAGIC
# MAGIC That is what SageMaker Model Monitor is for. It samples requests and responses into S3 (data capture), then a scheduled job compares the captured distribution to a baseline you computed from training data. If a feature drifts beyond a threshold, the monitoring job writes a violation report.
# MAGIC
# MAGIC ### Data capture is already on - your instructor enabled it
# MAGIC
# MAGIC Data capture is configured on the `EndpointConfig`, not the endpoint directly. There are two enablement points:
# MAGIC
# MAGIC 1. At endpoint-creation time (cleanest)
# MAGIC 2. Updating an existing endpoint's config after the fact
# MAGIC
# MAGIC Your cohort endpoint was deployed **with data capture already on**, at creation time, by the instructor setup script. That is deliberate: enabling capture means an `update_endpoint` call, and an endpoint can only run one update at a time. If 60 students each tried to enable capture themselves, all but the first would hit `ValidationException: cannot update in-progress endpoint`. So the instructor does it once, per cohort endpoint.
# MAGIC
# MAGIC For reference, this is the code the instructor ran (you do NOT run it - it is shown so you know the API):
# MAGIC
# MAGIC ```python
# MAGIC from sagemaker.model_monitor import DataCaptureConfig
# MAGIC
# MAGIC capture_cfg = DataCaptureConfig(
# MAGIC     enable_capture=True,
# MAGIC     sampling_percentage=100,
# MAGIC     destination_s3_uri=f"s3://{bucket}/fraud-classifier/data-capture/cohort-{cohort}",
# MAGIC     capture_options=["REQUEST", "RESPONSE"],
# MAGIC )
# MAGIC model.deploy(
# MAGIC     initial_instance_count=1,
# MAGIC     instance_type="ml.m5.xlarge",
# MAGIC     endpoint_name=f"fraud-classifier-endpoint-cohort-{cohort}",
# MAGIC     data_capture_config=capture_cfg,
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC The next cell just VERIFIES capture is on and prints where the captured traffic lands.

# COMMAND ----------

# Verify data capture is enabled on this cohort's endpoint.
# This is READ-ONLY - no update_endpoint call, so it is safe to run any
# number of times and safe for all 60 students to run at once.

bucket = dbutils.secrets.get(scope="aws-course-shared", key="course-s3-bucket")

# The endpoint's active config carries the DataCaptureConfig.
active_cfg_name = sagemaker_client.describe_endpoint(
    EndpointName=ENDPOINT_NAME
)["EndpointConfigName"]
active_cfg = sagemaker_client.describe_endpoint_config(
    EndpointConfigName=active_cfg_name
)

capture = active_cfg.get("DataCaptureConfig")
if not capture or not capture.get("EnableCapture"):
    raise RuntimeError(
        f"Data capture is NOT enabled on {ENDPOINT_NAME}. "
        "Ask your instructor to redeploy the cohort endpoint with "
        "data capture (instructor_setup_aws.py does this at deploy time)."
    )

capture_s3_uri = capture["DestinationS3Uri"]
print("Data capture: ENABLED")
print("Sampling percentage:", capture.get("InitialSamplingPercentage"))
print("Capture S3:", capture_s3_uri)

# COMMAND ----------

# Send a few invocations so there is captured traffic to look at.
# The endpoint is already InService (the instructor deployed it), so there
# is no update to wait for.
import time
import json

# The fraud classifier is a HuggingFace DistilBERT text model - it expects
# {"inputs": "<narrative text>"}.
sample_payload = json.dumps({
    "inputs": "Card-not-present purchase of 482.50 at an online electronics "
              "retailer, 2 hours after the previous transaction."
})
for i in range(10):
    sm_runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        Body=sample_payload,
    )
print("Sent 10 invocations to", ENDPOINT_NAME)

# Inspect what landed in S3. Capture can take a minute to flush.
# capture_s3_uri is "s3://<bucket>/<prefix>" - strip the scheme for list.
capture_prefix = capture_s3_uri.replace(f"s3://{bucket}/", "")
time.sleep(60)
listing = s3.list_objects_v2(Bucket=bucket, Prefix=capture_prefix)
found = listing.get("Contents", [])
print(f"Capture objects under {capture_prefix}: {len(found)}")
for obj in found[:5]:
    print(" ", obj["Key"], obj["Size"], "bytes")

# COMMAND ----------

# MAGIC %md
# MAGIC ### What Model Monitor actually is, and what we are about to build
# MAGIC
# MAGIC So far you have ONE of the three pieces Model Monitor needs: data capture is
# MAGIC on, so every request and response the endpoint sees is being written to S3.
# MAGIC That alone monitors nothing. Monitoring is a comparison, and a comparison
# MAGIC needs a baseline and a job that runs the comparison on a schedule.
# MAGIC
# MAGIC Here is the whole loop:
# MAGIC
# MAGIC ![Model Monitor data-quality loop](https://raw.githubusercontent.com/axel-sirota/bread-financial-academy/main/docs/images/week20_model_monitor.png)
# MAGIC
# MAGIC Three moving parts:
# MAGIC
# MAGIC 1. **Baseline** - a one-shot Processing job, `suggest_baseline(...)`, reads
# MAGIC    your training data and writes `constraints.json` (the expected schema and
# MAGIC    value ranges per feature) and `statistics.json` (the reference
# MAGIC    distribution) to S3. This is "what normal looks like".
# MAGIC 2. **Data capture** - already on. The endpoint's live traffic in S3. This is
# MAGIC    "what is actually happening".
# MAGIC 3. **Monitoring schedule** - `create_monitoring_schedule(...)` sets up an
# MAGIC    hourly job that compares (2) against (1). When a feature drifts beyond the
# MAGIC    constraints, it writes a violation report and emits a CloudWatch metric.
# MAGIC
# MAGIC What we are about to build, in this notebook, is parts (1) and (3). Part (2)
# MAGIC is done. The goal of this section is a running hourly monitor on your cohort
# MAGIC endpoint that would catch a feature-distribution shift without anyone
# MAGIC watching.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Demo - the three SageMaker SDK calls you will use
# MAGIC
# MAGIC The SageMaker SDK gives you `DefaultModelMonitor` for data-quality
# MAGIC monitoring. You use it in three steps. Read these now; you will write them
# MAGIC in Lab 2.
# MAGIC
# MAGIC **Step 1 - construct the monitor.** It describes the compute for the jobs:
# MAGIC
# MAGIC ```python
# MAGIC from sagemaker.model_monitor import DefaultModelMonitor
# MAGIC
# MAGIC monitor = DefaultModelMonitor(
# MAGIC     role=role,                       # the SageMaker execution role ARN
# MAGIC     instance_count=1,
# MAGIC     instance_type="ml.m5.xlarge",    # 16 GiB - smaller instances OOM here
# MAGIC     volume_size_in_gb=20,
# MAGIC     max_runtime_in_seconds=1800,
# MAGIC     sagemaker_session=sm_session,
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC **Step 2 - suggest the baseline.** A one-shot Processing job that reads the
# MAGIC training CSV and writes `constraints.json` + `statistics.json` to S3:
# MAGIC
# MAGIC ```python
# MAGIC from sagemaker.model_monitor.dataset_format import DatasetFormat
# MAGIC
# MAGIC monitor.suggest_baseline(
# MAGIC     baseline_dataset="s3://.../baseline.csv",
# MAGIC     dataset_format=DatasetFormat.csv(header=True),
# MAGIC     output_s3_uri="s3://.../baseline-results",
# MAGIC     wait=False,    # do NOT block the notebook for 5-8 minutes in class
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC `wait=False` is important: the baseline job takes several minutes. We start
# MAGIC it and move on; it finishes in the background.
# MAGIC
# MAGIC **Step 3 - create the hourly schedule.** This is the monitor that actually
# MAGIC runs forever:
# MAGIC
# MAGIC ```python
# MAGIC from sagemaker.model_monitor import CronExpressionGenerator
# MAGIC
# MAGIC monitor.create_monitoring_schedule(
# MAGIC     monitor_schedule_name="fraud-classifier-hourly",
# MAGIC     endpoint_input=ENDPOINT_NAME,
# MAGIC     output_s3_uri="s3://.../schedule-results",
# MAGIC     statistics=monitor.baseline_statistics(),
# MAGIC     constraints=monitor.suggested_constraints(),
# MAGIC     schedule_cron_expression=CronExpressionGenerator.hourly(),
# MAGIC     enable_cloudwatch_metrics=True,
# MAGIC )
# MAGIC ```
# MAGIC
# MAGIC That is the entire pattern. In Lab 2 you write these three calls. You will
# MAGIC NOT wait for the hourly job to fire in class - you confirm the schedule
# MAGIC exists in the SageMaker console.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Lab 2 - Baseline + scheduled monitor (15 min)
# MAGIC
# MAGIC Now you write the three SDK calls from the demo above. The lab is mostly
# MAGIC configuration; the point is to wire the three moving parts together.
# MAGIC
# MAGIC Your task, in the starter cell below:
# MAGIC
# MAGIC 1. Construct a `DefaultModelMonitor` (use `instance_type="ml.m5.xlarge"` -
# MAGIC    smaller instances OOM on the baseline job).
# MAGIC 2. Call `suggest_baseline(...)` with `wait=False` so the notebook does not
# MAGIC    block for several minutes.
# MAGIC 3. Call `create_monitoring_schedule(...)` with an hourly cron, passing
# MAGIC    `monitor_schedule_name=SCHEDULE_NAME`. The starter cell already builds
# MAGIC    `SCHEDULE_NAME` and the S3 output paths PER STUDENT (keyed on your
# MAGIC    student number) so 60 students never collide on one schedule name or
# MAGIC    overwrite each other's results in S3.
# MAGIC
# MAGIC You will not wait for the scheduled run to complete in class. You start it
# MAGIC and confirm the schedule shows up under SageMaker -> Monitoring jobs.
# MAGIC
# MAGIC ### Stretch
# MAGIC
# MAGIC Once the baseline job finishes, read the generated `constraints.json` from
# MAGIC `baseline_results_s3` and print the inferred type and completeness for
# MAGIC `amount`.
# MAGIC
# MAGIC ### Homework extension
# MAGIC
# MAGIC Trigger the monitoring job by sending 1000 invocations with deliberately
# MAGIC drifted `amount` values, then read the violation report from S3.

# COMMAND ----------

# Lab 2 SOLUTION. Use SageMaker SDK to baseline and schedule.

from sagemaker import Session
from sagemaker.model_monitor import DefaultModelMonitor, CronExpressionGenerator
from sagemaker.model_monitor.dataset_format import DatasetFormat

sm_session = Session()
role = dbutils.secrets.get(scope="aws-course-shared", key="sagemaker-execution-role-arn")

# The baseline INPUT (training data) is shared and read-only - fine to share.
baseline_input_s3 = f"s3://{bucket}/fraud-classifier/training/baseline.csv"

# The baseline RESULTS and the schedule OUTPUT are per-student work products.
# Key them on the student number so 60 students do not clobber each other in
# S3 or collide on the schedule name. _num was derived in the setup cell.
baseline_results_s3 = f"s3://{bucket}/fraud-classifier/monitoring/student-{_num}/baseline-results"
schedule_output_s3 = f"s3://{bucket}/fraud-classifier/monitoring/student-{_num}/schedule-results"
SCHEDULE_NAME = f"fraud-classifier-hourly-student-{_num}"

# Step 1 - construct the monitor. ml.m5.xlarge (16 GiB) - smaller instances
# OOM on the baseline Processing job.
monitor = DefaultModelMonitor(
    role=role,
    instance_count=1,
    instance_type="ml.m5.xlarge",
    volume_size_in_gb=20,
    max_runtime_in_seconds=1800,
    sagemaker_session=sm_session,
)

# Step 2 - suggest the baseline. wait=False so the notebook does not block
# for the several minutes the Processing job takes.
monitor.suggest_baseline(
    baseline_dataset=baseline_input_s3,
    dataset_format=DatasetFormat.csv(header=True),
    output_s3_uri=baseline_results_s3,
    wait=False,
)

# Idempotency: drop an existing schedule of the same name so a re-run does
# not hit ResourceInUse.
import time
sm_client = sm_session.boto_session.client("sagemaker")
try:
    sm_client.describe_monitoring_schedule(MonitoringScheduleName=SCHEDULE_NAME)
    print(f"Found existing schedule {SCHEDULE_NAME}, deleting before recreate.")
    sm_client.delete_monitoring_schedule(MonitoringScheduleName=SCHEDULE_NAME)
    for _ in range(12):
        time.sleep(5)
        try:
            sm_client.describe_monitoring_schedule(MonitoringScheduleName=SCHEDULE_NAME)
        except sm_client.exceptions.ClientError:
            break
except sm_client.exceptions.ClientError:
    pass

# Step 3 - create the hourly monitoring schedule on this cohort's endpoint.
monitor.create_monitoring_schedule(
    monitor_schedule_name=SCHEDULE_NAME,
    endpoint_input=ENDPOINT_NAME,
    output_s3_uri=schedule_output_s3,
    statistics=monitor.baseline_statistics(),
    constraints=monitor.suggested_constraints(),
    schedule_cron_expression=CronExpressionGenerator.hourly(),
    enable_cloudwatch_metrics=True,
)

print("Schedule:", SCHEDULE_NAME, "- check SageMaker console -> Monitoring jobs.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 3 - CloudWatch alarm on endpoint latency
# MAGIC
# MAGIC Model Monitor fires on data quality. Langfuse fires on agent behavior. Neither pages you at 3am when the endpoint just becomes slow.
# MAGIC
# MAGIC SageMaker endpoints emit metrics to CloudWatch in the `aws/sagemaker/Endpoints` namespace: `ModelLatency`, `Invocations`, `Invocation4XXErrors`, `Invocation5XXErrors`. We will create one alarm: if `ModelLatency` p95 exceeds 1000 ms for 5 minutes, send a message to the SNS topic the instructor pre-created. SNS fans out to email, Slack, PagerDuty, whatever.
# MAGIC
# MAGIC Watch the unit: `ModelLatency` is reported in microseconds, so a 1000 ms threshold is `1000000` in the alarm config.
# MAGIC
# MAGIC This part is a demo only. You watch the cell run and the alarm appear in the CloudWatch console.

# COMMAND ----------

# Create a CloudWatch alarm wired to an SNS topic the instructor provisioned.

sns_topic_arn = dbutils.secrets.get(scope="aws-course-shared", key="sns-alerts-topic-arn")

# Per-student alarm name so 60 students do not overwrite one shared alarm.
alarm_name = f"fraud-classifier-high-latency-student-{_num}"

cloudwatch.put_metric_alarm(
    AlarmName=alarm_name,
    AlarmDescription="Fires when p95 ModelLatency exceeds 1000 ms for 5 minutes",
    MetricName="ModelLatency",
    Namespace="AWS/SageMaker",
    # ModelLatency is reported in MICROSECONDS. 1000 ms = 1000000 us.
    ExtendedStatistic="p95",
    Dimensions=[
        {"Name": "EndpointName", "Value": ENDPOINT_NAME},
        {"Name": "VariantName", "Value": "AllTraffic"},
    ],
    Period=60,
    EvaluationPeriods=5,
    Threshold=1000000.0,
    ComparisonOperator="GreaterThanThreshold",
    TreatMissingData="notBreaching",
    AlarmActions=[sns_topic_arn],
)

print("Alarm created:", alarm_name)
print("Open CloudWatch -> Alarms to see it.")
print("Subscribe yourself to", sns_topic_arn, "to receive the page.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 4 - LiteLLM as a unified interface (brief)
# MAGIC
# MAGIC Strands gives you agents. Langfuse gives you traces. But sometimes you do not need an agent; you just need to call an LLM and log the call. LiteLLM is the "boring" version of this pattern: a single Python function `litellm.completion(...)` that speaks to any provider, with built-in callbacks for Langfuse and others.
# MAGIC
# MAGIC You will not build with LiteLLM today. You will see it work in one cell. The point is the interface: same call, any provider, free Langfuse logging.

# COMMAND ----------

# Single demo of LiteLLM auto-logging to Langfuse. No agent involved.

import litellm

# Tell LiteLLM to log everything to Langfuse. The Langfuse env vars
# from Part 1 are still set, so it picks them up automatically.
litellm.success_callback = ["langfuse"]
litellm.failure_callback = ["langfuse"]

resp = litellm.completion(
    model="bedrock/converse/us.anthropic.claude-sonnet-4-5-20250929-v1:0",
    messages=[
        {"role": "user", "content": "In one sentence, why is online monitoring required for ML systems?"}
    ],
    max_tokens=80,
    temperature=0,
)
print(resp.choices[0].message.content)
print()
print("This call appears in Langfuse as a Generation (not a Trace), tagged with the model name.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Think about it
# MAGIC
# MAGIC You now have three production signals on the same fraud system:
# MAGIC
# MAGIC 1. Langfuse traces (per-decision, qualitative)
# MAGIC 2. SageMaker Model Monitor (feature distribution, statistical)
# MAGIC 3. CloudWatch alarms (operational, time-series)
# MAGIC
# MAGIC Which of these would have caught the following, in order of speed?
# MAGIC - The endpoint instance ran out of memory at 3:04 am
# MAGIC - A new fraud pattern using sub-dollar amounts started yesterday
# MAGIC - The supervisor started calling `policy_retriever_v2` 14 times per decision because of a prompt regression you shipped Friday
# MAGIC - The training-serving skew on `merchant_category` has been growing for three weeks
# MAGIC
# MAGIC There is no single right ordering. The point is that each signal has a job, and none of them substitutes for the others. A fourth signal, upstream drift detection on the data lake itself, is the subject of Week 21.

# COMMAND ----------

# MAGIC %md
# MAGIC ## A note on CI/CD
# MAGIC
# MAGIC We did not build a GitHub Actions workflow in this notebook. In a Databricks-centric MLOps shop you usually combine two pieces:
# MAGIC
# MAGIC 1. A GitHub Actions workflow that, on push to `main`, runs unit tests, packages the training code, and submits a Databricks Job that runs the Week 19 SageMaker training script.
# MAGIC 2. A scheduled drift check that decides when to retrain and triggers (1) if drift is detected.
# MAGIC
# MAGIC The "CI" half is testing your training code before it can run. The "CD" half is the drift check that decides when to run it. You have the "CI" ingredient already; the scheduled drift check is what Week 21 builds with Airflow.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Wrap-up
# MAGIC
# MAGIC You took a deployed Strands-based fraud system and put three production guardrails on it:
# MAGIC
# MAGIC - Langfuse + OTEL traces on `week19_supervisor` with five lines of setup
# MAGIC - SageMaker data capture and a Model Monitor schedule on the cohort endpoint
# MAGIC - A CloudWatch alarm on endpoint latency wired to SNS
# MAGIC - A glimpse of LiteLLM as the simpler unified-interface pattern
# MAGIC
# MAGIC ## Homework
# MAGIC
# MAGIC 1. Finish the homework extension on Lab 1 (24h replay + p95 dashboard).
# MAGIC 2. Read the SageMaker Model Monitor docs for the four built-in monitor types: Data Quality, Model Quality, Bias Drift, Feature Attribution Drift. Pick one of the latter three and write a 200-word note on when you would add it to this pipeline.
# MAGIC 3. Preview Week 21: think about which of this week's checks belong on a schedule rather than run by hand, and what should happen automatically when one of them fires.
# MAGIC
# MAGIC Next week (Week 21) we move to orchestration with Airflow / MWAA. Upstream drift detection on the data lake, the natural fourth signal, becomes a scheduled DAG there.