# Databricks notebook source
# MAGIC %md
# MAGIC # Minimal Fraud Detection with RAG POC — v5 (Multi-Agent, Databricks → Bedrock, Airflow)
# MAGIC
# MAGIC This notebook upgrades the standalone mock POC (`minimal_fraud_rag_poc.ipynb`) into the
# MAGIC **real** proof of concept described in components 1–5: it runs on **Databricks**, calls out
# MAGIC to **Amazon Bedrock**, queries a **fraud-rules Knowledge Base** with the most advanced
# MAGIC retrieval (Cohere Rerank 3.5), orchestrates a **multi-agent** investigation (Strands
# MAGIC specialists + supervisor + Swarm), simulates **near-real-time** monitoring over the Spark
# MAGIC transaction table, and triggers **alerts** — with a scheduled **Apache Airflow (MWAA) DAG**
# MAGIC for the batch-monitoring + alerting path.
# MAGIC
# MAGIC | Component | What it does | Source notebook (most advanced piece pulled) |
# MAGIC |-----------|--------------|----------------------------------------------|
# MAGIC | **1. Databricks → Bedrock setup** | Secret-based AWS auth, boto3 clients, `BedrockModel` | Week 20 / Week 21 (`dbutils.secrets`) |
# MAGIC | **2. Agent queries fraud-rules KB (RAG)** | KB retrieve **+ Cohere Rerank 3.5** + RAGAS eval | Week 18 (`reranked_retrieve`, `policy_retriever_v2`) |
# MAGIC | **3. Multi-agent orchestration** | Triage / Investigation / Decision specialists, supervisor, **Swarm** | Week 16 / Week 17 (agents-as-tools, Swarm) |
# MAGIC | **4. Near-real-time simulation** | Spark transaction stream, one **Langfuse session per txn** | Week 20 (Spark loop + OTLP traces) |
# MAGIC | **5. Alerts** | SNS publish on high-risk verdict / fraud rate | Week 21 (`sns.publish`) |
# MAGIC | **Airflow DAG** | Pull → score → fraud-rate → **branch** → SNS, with failure paging | Week 21 (Lab 2 branch + Lab 4 `on_failure_callback`) |
# MAGIC
# MAGIC > **Architecture note (the split).** Agentic RAG investigation is GPU-light but
# MAGIC > framework-heavy, so it runs **here on Databricks** against Bedrock (Component 4). The
# MAGIC > scheduled, fan-out batch scoring + alerting runs on **MWAA**, which scores via the
# MAGIC > SageMaker endpoint rather than the agent stack — this is the course's *"Databricks
# MAGIC > authors, MWAA executes"* model. Both paths share the same KB, model, and SNS topic.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## What you must provision first
# MAGIC
# MAGIC These were pre-provisioned by the instructor in the course; for your own run, set the
# MAGIC constants in **Section 1**. None of this notebook fabricates them:
# MAGIC
# MAGIC - A **Bedrock Knowledge Base** of fraud / BSA-AML / OFAC / CTR policy docs → `KNOWLEDGE_BASE_ID`
# MAGIC - Bedrock model access for **Claude Sonnet**, **Titan Embeddings v2**, **Cohere Rerank 3.5**
# MAGIC - A Databricks **secret scope** holding AWS keys (`aws-course-creds-NN`, `aws-course-shared`)
# MAGIC - A Spark/Delta table `bread_academy.course_data.fraud_transactions`
# MAGIC - A deployed **SageMaker endpoint** (DistilBERT fraud classifier) → `ENDPOINT_NAME`
# MAGIC - An **SNS topic** for alerts → `SNS_TOPIC_ARN`
# MAGIC - An **MWAA environment** + its DAGs S3 bucket (for the Airflow section)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Section 0 — Install & import
# MAGIC
# MAGIC Same client surface as Weeks 17–21. `faiss-cpu` + `numpy<2` back the `mem0_memory`
# MAGIC case-history store; `ragas` powers the optional retrieval evaluation.

# COMMAND ----------

# Databricks will prompt a kernel restart after install — that is expected.
%pip install -q \
    "boto3>=1.36" \
    "strands-agents>=1.37,<2" \
    "strands-agents-tools[mem0-memory]>=0.2.10" \
    "langchain>=0.3" \
    "langchain-aws>=0.2" \
    "langchain-community>=0.3" \
    "ragas>=0.4" \
    "faiss-cpu>=1.9,<2" \
    "numpy<2"


# COMMAND ----------

# Import order matters: pull strands_tools BEFORE any direct faiss import to
# avoid the segfault some kernels hit when faiss loads first.
import os
import json
import time
import base64
import boto3
import pandas as pd

from strands import Agent, tool
from strands.models import BedrockModel
from strands.multiagent import Swarm
from strands_tools import retrieve, mem0_memory
from strands.telemetry import StrandsTelemetry

from langchain_aws import ChatBedrockConverse, BedrockEmbeddings

# Optional eval stack (Section 2b)
# from ragas import evaluate, EvaluationDataset, SingleTurnSample
# from ragas.metrics import faithfulness, answer_relevancy, context_precision
# from ragas.llms import LangchainLLMWrapper
# from ragas.embeddings import LangchainEmbeddingsWrapper

from importlib.metadata import version as pkg_version
for pkg in ["boto3", "strands-agents", "strands-agents-tools",
            "langchain-aws", "ragas", "faiss-cpu", "numpy"]:
    try:
        print(f"  {pkg:<22} {pkg_version(pkg)}")
    except Exception:
        print(f"  {pkg:<22} (not found)")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Component 1 — Databricks → Bedrock setup
# MAGIC
# MAGIC Secret-based auth (no `get_execution_role()`; that was the SageMaker pattern in Weeks
# MAGIC 15–18). We pull per-student AWS keys from the Databricks secret scope, export them so
# MAGIC boto3 / Strands / LangChain all pick them up, and build every client once.
# MAGIC *(Source: Week 20 / Week 21 cell 3.)*

# COMMAND ----------

# Pull secrets, build clients. NEVER hard-code credentials.
_user = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook().getContext().userName().get()
)
_num = _user.split("@")[0].split("-")[1] if _user.startswith("student-") else "01"
creds_scope = f"aws-course-creds-{_num}"

AWS_ACCESS_KEY_ID     = dbutils.secrets.get(scope=creds_scope, key="aws-access-key-id")
AWS_SECRET_ACCESS_KEY = dbutils.secrets.get(scope=creds_scope, key="aws-secret-access-key")
AWS_REGION            = dbutils.secrets.get(scope="aws-course-shared", key="aws-region")

os.environ["AWS_ACCESS_KEY_ID"]     = AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = AWS_SECRET_ACCESS_KEY
os.environ["AWS_REGION"]            = AWS_REGION
os.environ["AWS_DEFAULT_REGION"]    = AWS_REGION
os.environ["AWS_REGION_NAME"]       = AWS_REGION  # LiteLLM / some SDKs read this

# Clients used across the notebook.
bedrock_client        = boto3.client("bedrock",               region_name=AWS_REGION)
bedrock_runtime       = boto3.client("bedrock-runtime",       region_name=AWS_REGION)
bedrock_agent_runtime = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)
sm_runtime            = boto3.client("sagemaker-runtime",     region_name=AWS_REGION)
sagemaker_client      = boto3.client("sagemaker",             region_name=AWS_REGION)
cloudwatch            = boto3.client("cloudwatch",            region_name=AWS_REGION)
s3                    = boto3.client("s3",                    region_name=AWS_REGION)
sns                   = boto3.client("sns",                   region_name=AWS_REGION)
mwaa                  = boto3.client("mwaa",                  region_name=AWS_REGION)

# Fail loud if Bedrock is not reachable.
try:
    n = len(bedrock_client.list_foundation_models()["modelSummaries"])
    print(f"Connected to Bedrock: {n} models visible.")
except Exception as e:
    print(f"Bedrock connection failed: {e}")
    print("Ask your admin to confirm the execution role / keys have Bedrock permissions.")


# COMMAND ----------

# ---- Model + resource configuration (EDIT THESE for your environment) -------
MODEL_ID        = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
EMBED_MODEL_ID  = "amazon.titan-embed-text-v2:0"
RERANK_MODEL_ID = "cohere.rerank-v3-5:0"
RERANK_MODEL_ARN = f"arn:aws:bedrock:{AWS_REGION}::foundation-model/{RERANK_MODEL_ID}"

# Pre-provisioned Bedrock Knowledge Base of fraud / BSA-AML / OFAC / CTR policy docs.
KNOWLEDGE_BASE_ID = dbutils.secrets.get(scope="aws-course-shared", key="fraud-kb-id")
os.environ["STRANDS_KNOWLEDGE_BASE_ID"] = KNOWLEDGE_BASE_ID  # strands_tools.retrieve reads this

# SageMaker DistilBERT fraud classifier endpoint (cohort-derived in the course).
cohort = (int(_num) - 1) // 20 + 1
ENDPOINT_NAME = dbutils.secrets.get(scope="aws-course-shared", key="endpoint-name-base") + f"-{cohort}"

# Alerting + Airflow.
SNS_TOPIC_ARN = dbutils.secrets.get(scope="aws-course-shared", key="fraud-alerts-topic-arn")
SHARED_BUCKET = "bread-academy-shared"
DAGS_BUCKET   = "bread-academy-airflow-dags"
MWAA_ENV      = "bread-academy-airflow"
STUDENT_ID    = _num
USER_SLUG     = f"participant_{_num}"

# Shared model handles. One Strands BedrockModel for agents; one LangChain
# client + embeddings for RAGAS.
bedrock_model      = BedrockModel(model_id=MODEL_ID, region_name=AWS_REGION)
langchain_llm      = ChatBedrockConverse(model=MODEL_ID, region_name=AWS_REGION)
bedrock_embeddings = BedrockEmbeddings(model_id=EMBED_MODEL_ID, region_name=AWS_REGION)

print("Model:", MODEL_ID)
print("KB:", KNOWLEDGE_BASE_ID, "| Rerank:", RERANK_MODEL_ID)
print("Endpoint:", ENDPOINT_NAME, "| SNS:", SNS_TOPIC_ARN)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Langfuse observability (online traces)
# MAGIC
# MAGIC Five-line OTLP wiring. After this cell every Strands agent call — including each tool
# MAGIC call and Bedrock `converse` with token counts — shows up as a span in Langfuse.
# MAGIC *(Source: Week 20 cell 7.)*

# COMMAND ----------

LANGFUSE_PUBLIC_KEY = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-public-key")
LANGFUSE_SECRET_KEY = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-secret-key")
LANGFUSE_HOST       = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-host")

LANGFUSE_AUTH = base64.b64encode(
    f"{LANGFUSE_PUBLIC_KEY}:{LANGFUSE_SECRET_KEY}".encode()
).decode()
os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = LANGFUSE_HOST + "/api/public/otel"
os.environ["OTEL_EXPORTER_OTLP_HEADERS"]  = f"Authorization=Basic {LANGFUSE_AUTH}"
os.environ["OTEL_SERVICE_NAME"]           = "fraud-rag-poc-v5"

StrandsTelemetry().setup_otlp_exporter()
print("Langfuse OTLP exporter wired. Host:", LANGFUSE_HOST)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Component 2 — Agent queries the fraud-rules KB (RAG, with Cohere Rerank 3.5)
# MAGIC
# MAGIC This is the defining upgrade over the mock POC: the policy lookup is **KB-backed retrieval**,
# MAGIC not a hardcoded Python dict. We use the most advanced retrieval from the course — a
# MAGIC bi-encoder KB retrieve followed by a **Cohere Rerank 3.5 cross-encoder** that re-scores
# MAGIC every `(query, chunk)` pair and promotes the most relevant chunk to rank 1.
# MAGIC *(Source: Week 18 cells 14 & 17.)*

# COMMAND ----------

# Cohere Rerank 3.5 via the Bedrock Rerank API (a cross-encoder, NOT a generation call).
def bedrock_rerank(query_text: str, text_sources: list, num_results: int = 3) -> list:
    """Rerank text_sources by relevance to query_text using Cohere Rerank 3.5.

    Returns: [{index, relevance_score, text}, ...] sorted by score desc.
    """
    if not text_sources:
        return []
    response = bedrock_agent_runtime.rerank(
        queries=[{"type": "TEXT", "textQuery": {"text": query_text}}],
        sources=[
            {
                "type": "INLINE",
                "inlineDocumentSource": {
                    "type": "TEXT",
                    "textDocument": {"text": s},
                },
            }
            for s in text_sources
        ],
        rerankingConfiguration={
            "type": "BEDROCK_RERANKING_MODEL",
            "bedrockRerankingConfiguration": {
                "numberOfResults": num_results,
                "modelConfiguration": {"modelArn": RERANK_MODEL_ARN},
            },
        },
    )
    return [
        {"index": r["index"],
         "relevance_score": r["relevanceScore"],
         "text": text_sources[r["index"]]}
        for r in response["results"]
    ]


# COMMAND ----------

# Retrieve k_retrieve candidates from the KB, then rerank down to k_final.
# We call bedrock_agent_runtime.retrieve() DIRECTLY (not strands_tools.retrieve),
# because the rerank API needs plain text strings, and the raw API gives us the
# retrievalResults with scores + source locations.
def reranked_retrieve(query: str, k_retrieve: int = 10, k_final: int = 3) -> list:
    raw = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=KNOWLEDGE_BASE_ID,
        retrievalQuery={"text": query},
        retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": k_retrieve}},
    )
    items = raw.get("retrievalResults", [])
    candidates = [i.get("content", {}).get("text", "") for i in items]
    sources    = [i.get("location", {}) for i in items]
    ranked = bedrock_rerank(query, candidates, num_results=k_final)
    for r in ranked:
        r["source_uri"] = sources[r["index"]].get("s3Location", {}).get("uri", "unknown")
    return ranked


@tool
def retrieve_policy_reranked(query: str) -> str:
    """Retrieve fraud-policy chunks from the KB, reranked by Cohere Rerank 3.5.

    Args:
        query: The policy question or investigation query.
    """
    ranked = reranked_retrieve(query, k_retrieve=10, k_final=3)
    lines = []
    for i, r in enumerate(ranked, 1):
        lines.append(f"[{i}] score={r['relevance_score']:.3f} | {r['source_uri']}")
        lines.append(r["text"])
        lines.append("")
    return "\n".join(lines)


# The RAG specialist agent: always retrieves before answering, answers only from
# retrieved content. This is the "agent queries fraud rules knowledge base" piece.
policy_retriever_v2 = Agent(
    model=bedrock_model,
    tools=[retrieve_policy_reranked],
    system_prompt=(
        "You are a fraud policy specialist. Always call retrieve_policy_reranked "
        "before answering. Answer only from retrieved content. If the KB does not "
        "cover the question, say so and stop."
    ),
    callback_handler=None,
)

_q = "What is the CTR reporting threshold for cash transactions?"
print("policy_retriever_v2 (Cohere-reranked KB):")
print(str(policy_retriever_v2(_q))[:500])


# COMMAND ----------

# MAGIC %md
# MAGIC ### (Optional) Component 2b — Prove the RAG is good with RAGAS
# MAGIC
# MAGIC LLM-as-judge scoring of **faithfulness** and **answer relevancy**, baseline KB retrieve vs.
# MAGIC the reranked path. Run this when you need numbers, not vibes. *(Source: Week 18 cell 25.)*

# COMMAND ----------

def _baseline_sample(question):
    raw = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=KNOWLEDGE_BASE_ID,
        retrievalQuery={"text": question},
        retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": 3}},
    )
    contexts = [i["content"]["text"] for i in raw.get("retrievalResults", [])]
    prompt = (f"Answer using only the context.\n\nContext:\n{chr(10).join(contexts)}\n\n"
              f"Question: {question}\nAnswer:")
    return SingleTurnSample(user_input=question,
                            response=langchain_llm.invoke(prompt).content,
                            retrieved_contexts=contexts)

def _reranked_sample(question):
    ranked = reranked_retrieve(question, k_retrieve=10, k_final=3)
    contexts = [r["text"] for r in ranked]
    prompt = (f"Answer using only the context.\n\nContext:\n{chr(10).join(contexts)}\n\n"
              f"Question: {question}\nAnswer:")
    return SingleTurnSample(user_input=question,
                            response=langchain_llm.invoke(prompt).content,
                            retrieved_contexts=contexts)

evaluator_llm        = LangchainLLMWrapper(langchain_llm)
evaluator_embeddings = LangchainEmbeddingsWrapper(bedrock_embeddings)

def score_config(name, builder, questions):
    ds = EvaluationDataset(samples=[builder(q) for q in questions])
    r = evaluate(dataset=ds, metrics=[faithfulness, answer_relevancy],
                 llm=evaluator_llm, embeddings=evaluator_embeddings)
    df = r.to_pandas(); df["config"] = name
    return df[["config", "user_input", "faithfulness", "answer_relevancy"]]

eval_questions = [
    "What is the CTR reporting threshold?",
    "When must a bank file a CTR on aggregated transactions?",
    "What evidence indicates account takeover?",
]
compare = pd.concat([
    score_config("baseline",  _baseline_sample, eval_questions),
    score_config("+ rerank",  _reranked_sample, eval_questions),
], ignore_index=True)
print(compare.to_string(index=False))
print("\nMean per config:")
print(compare.groupby("config")[["faithfulness", "answer_relevancy"]].mean().round(3))


# COMMAND ----------

# MAGIC %md
# MAGIC ## Component 3 — Multi-agent fraud orchestration
# MAGIC
# MAGIC A genuine multi-agent system. First the shared **fraud tools** (Week 16), then three
# MAGIC **specialist agents** (triage / investigation / decision, Weeks 16–17), then a
# MAGIC **supervisor** that delegates to them *and* to the Component-2 RAG agent + a `mem0_memory`
# MAGIC case-history store (Week 18 `week18_supervisor`). Section 3b adds the **Swarm** — the most
# MAGIC advanced multi-agent pattern, where specialists hand off to each other with no central
# MAGIC coordinator (Week 16 bonus).

# COMMAND ----------

# Demo transaction / customer fixtures the tools read from. In production these
# tools would query the Spark/Delta tables; we seed a small dict so the agent
# demo is self-contained. (Tools: Week 16 cell 6.)
TRANSACTION_DATABASE = {
    "TXN-001": {"transaction_id": "TXN-001", "amount": 4500.0, "merchant": "Overseas Wire Co",
                "merchant_country": "GB", "hour": 3, "channel": "wire",
                "narrative": "International wire transfer to a new overseas payee at 03:47."},
    "TXN-002": {"transaction_id": "TXN-002", "amount": 12.99, "merchant": "StreamFlix",
                "merchant_country": "US", "hour": 19, "channel": "card_present",
                "narrative": "Recurring streaming subscription on a known device."},
}
CUSTOMER_HISTORY = {
    "TXN-001": {"customer_id": "C002", "avg_monthly_spend": 1800.0, "home_country": "US",
                "known_devices": ["web_9"], "chargebacks_90d": 0},
    "TXN-002": {"customer_id": "C001", "avg_monthly_spend": 1600.0, "home_country": "US",
                "known_devices": ["ios_1"], "chargebacks_90d": 0},
}


@tool
def lookup_transaction(transaction_id: str) -> str:
    """Look up transaction details by ID from the fraud database.

    Args:
        transaction_id: The transaction ID to look up (e.g., 'TXN-001').
    """
    txn = TRANSACTION_DATABASE.get(transaction_id)
    return json.dumps(txn, indent=2) if txn else f"Transaction {transaction_id} not found."


@tool
def check_customer_history(transaction_id: str) -> str:
    """Check customer spending history and patterns for a given transaction.

    Args:
        transaction_id: The transaction ID to check history for.
    """
    h = CUSTOMER_HISTORY.get(transaction_id)
    return json.dumps(h, indent=2) if h else f"No customer history for {transaction_id}."


@tool
def calculate_risk_score(amount: float, avg_monthly_spend: float,
                         is_international: bool, is_unusual_hour: bool,
                         is_new_merchant: bool) -> str:
    """Calculate a fraud risk score (0-100) from transaction characteristics.

    Args:
        amount: Transaction amount in dollars.
        avg_monthly_spend: Customer's average monthly spend.
        is_international: Whether the transaction crosses borders.
        is_unusual_hour: Whether it occurred at an unusual time.
        is_new_merchant: Whether the merchant is new to this customer.
    """
    amount_ratio = min(amount / max(avg_monthly_spend, 1), 5.0)
    risk = (min(amount_ratio * 20, 100) * 0.30
            + (90 if is_international else 0) * 0.25
            + (70 if is_unusual_hour else 0) * 0.20
            + (50 if is_new_merchant else 0) * 0.15
            + 10)
    level = "LOW" if risk < 30 else "MEDIUM" if risk < 60 else "HIGH"
    return json.dumps({"risk_score": round(risk, 1), "risk_level": level})


@tool
def classify_with_finetuned_model(narrative: str) -> str:
    """Classify a transaction narrative as fraud / not_fraud via the SageMaker endpoint.

    Args:
        narrative: Free-text description of the transaction.
    """
    out = sm_runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        Body=json.dumps({"inputs": narrative}),
    )
    return out["Body"].read().decode()


# COMMAND ----------

# Three specialist agents. Triage classifies; investigation gathers evidence;
# decision renders the verdict. (Weeks 16-17.)
triage_agent = Agent(
    model=bedrock_model,
    tools=[lookup_transaction, calculate_risk_score],
    system_prompt=("You classify transactions by risk level (LOW/MEDIUM/HIGH). "
                   "Look up the transaction, calculate risk, return a JSON verdict."),
    callback_handler=None,
)

investigation_agent = Agent(
    model=bedrock_model,
    tools=[lookup_transaction, check_customer_history, classify_with_finetuned_model],
    system_prompt=("You gather evidence for flagged transactions: look up the transaction "
                   "and customer history, run the fine-tuned classifier on the narrative, "
                   "and produce an evidence report."),
    callback_handler=None,
)

decision_agent = Agent(
    model=bedrock_model,
    tools=[],
    system_prompt=("You render a final verdict: APPROVE, FLAG_FOR_REVIEW, or BLOCK, using "
                   "the triage, investigation, and policy context you are given. "
                   "Cite the policy that supports your decision."),
    callback_handler=None,
)


# Wrap each specialist (and the RAG agent) as a callable tool for the supervisor.
@tool
def run_triage(transaction_id: str) -> str:
    """Classify a transaction's risk level.

    Args:
        transaction_id: The transaction to triage.
    """
    return str(triage_agent(f"Triage transaction {transaction_id}."))


@tool
def run_investigation(transaction_id: str) -> str:
    """Investigate a flagged transaction and produce an evidence report.

    Args:
        transaction_id: The transaction to investigate.
    """
    return str(investigation_agent(f"Investigate transaction {transaction_id}."))


@tool
def run_decision(triage_result: str, investigation_report: str, policy_context: str) -> str:
    """Render the final fraud verdict.

    Args:
        triage_result: Triage classification JSON.
        investigation_report: Evidence report from the investigator.
        policy_context: Relevant policy text retrieved from the KB.
    """
    return str(decision_agent(
        f"Triage: {triage_result}\nInvestigation: {investigation_report}\n"
        f"Policy: {policy_context}\nRender the verdict."))


@tool
def run_policy_retriever_v2(question: str) -> str:
    """Ask the fraud-policy specialist (Cohere-reranked KB retrieval).

    Args:
        question: A natural-language fraud policy question.
    """
    return str(policy_retriever_v2(question))


# COMMAND ----------

# The supervisor: orchestrates the specialists + the RAG retriever + case memory.
# This mirrors week18_supervisor, but here check-policy is genuinely KB-backed RAG.
SUPERVISOR_SYSTEM_PROMPT = (
    "You are the senior fraud operations supervisor. For each transaction: "
    "1) Search memory for prior findings on this customer or case. "
    "2) run_triage to classify the risk level. "
    "3) If risk is MEDIUM or HIGH, run_investigation to gather evidence. "
    "4) Retrieve the governing policy with run_policy_retriever_v2. "
    "5) run_decision for the final verdict (APPROVE / FLAG_FOR_REVIEW / BLOCK) with a "
    "policy citation. Save key findings to memory after answering."
)

supervisor = Agent(
    model=bedrock_model,
    tools=[run_triage, run_investigation, run_policy_retriever_v2, run_decision, mem0_memory],
    system_prompt=SUPERVISOR_SYSTEM_PROMPT,
    callback_handler=None,
)

print("Supervisor ready. Tools: triage, investigation, policy-RAG (Cohere rerank), "
      "decision, mem0_memory.")
print(str(supervisor("Investigate transaction TXN-001 for potential fraud."))[:600])


# COMMAND ----------

# MAGIC %md
# MAGIC ### Component 3b — Swarm (decentralized multi-agent)
# MAGIC
# MAGIC Same specialists, but **they** decide the flow via `handoff_to_agent()` instead of a
# MAGIC supervisor calling them — the most advanced multi-agent shape in the course.
# MAGIC *(Source: Week 16 bonus.)*

# COMMAND ----------

@tool
def get_similar_transactions(merchant_name: str) -> str:
    """Return past transactions at the same merchant (stub for the demo).

    Args:
        merchant_name: Merchant to search for.
    """
    return json.dumps({"merchant": merchant_name, "similar_count": 2,
                       "note": "2 prior disputes at this merchant in 90d"})

swarm_triage = Agent(
    name="triage", model=bedrock_model,
    tools=[lookup_transaction, calculate_risk_score],
    system_prompt=("You are a fraud triage specialist. Look up the transaction and "
                   "calculate risk. If risk is MEDIUM or HIGH, hand off to 'investigator'. "
                   "If LOW, hand off to 'decider'."),
)
swarm_investigator = Agent(
    name="investigator", model=bedrock_model,
    tools=[lookup_transaction, check_customer_history, get_similar_transactions,
           run_policy_retriever_v2],
    system_prompt=("You are a fraud investigator. Gather evidence: customer history, "
                   "similar transactions, and the governing policy via "
                   "run_policy_retriever_v2. Write a report, then hand off to 'decider'."),
)
swarm_decider = Agent(
    name="decider", model=bedrock_model,
    tools=[],
    system_prompt=("You are the fraud decision maker. Review triage + investigation, then "
                   "render a FINAL VERDICT: APPROVE, FLAG_FOR_REVIEW, or BLOCK. "
                   "Call complete_swarm_task with your verdict."),
)

fraud_swarm = Swarm([swarm_triage, swarm_investigator, swarm_decider],
                    entry_point=swarm_triage, max_handoffs=10)

print("Swarm investigating TXN-001 (decentralized flow)...")
print(str(fraud_swarm(
    "Investigate transaction TXN-001: a $4,500 wire transfer to an unknown overseas "
    "account at 03:47 AM."))[:600])


# COMMAND ----------

# MAGIC %md
# MAGIC ## Components 4 & 5 — Near-real-time simulation over Spark + alerts
# MAGIC
# MAGIC We pull real rows from the Delta table and run the multi-agent supervisor on each, one
# MAGIC **Langfuse session per transaction** (`session.id = transaction_id`). When the verdict is
# MAGIC `BLOCK`, we publish an **SNS alert**. This is the streaming-consumer simulation: swap the
# MAGIC `.limit(N)` read for a Structured-Streaming `readStream` to go truly real-time.
# MAGIC *(Source: Week 20 cell 11 loop + Week 21 `sns.publish`.)*

# COMMAND ----------

from opentelemetry import trace

# Component 4: pull a handful of real transactions from the Delta table.
lab_rows = (
    spark.read.table("bread_academy.course_data.fraud_transactions")
    .filter("is_fraud = 1")
    .select("transaction_id", "customer_id", "amount", "merchant_country", "narrative")
    .orderBy("transaction_id")
    .limit(5)
    .collect()
)


def publish_alert(transaction_id, customer_id, verdict, detail):
    """Component 5: fire an SNS alert for a blocked / high-risk transaction."""
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject=f"FRAUD ALERT [{verdict}] {transaction_id}",
        Message=json.dumps({
            "transaction_id": transaction_id,
            "customer_id": customer_id,
            "verdict": verdict,
            "detail": detail[:900],
        }),
    )


results = []
for row in lab_rows:
    # One fresh agent per transaction => one Langfuse session each.
    # trace_attributes is constructor-only, so rebuild inside the loop.
    investigation_supervisor = Agent(
        model=bedrock_model,
        tools=[run_triage, run_investigation, run_policy_retriever_v2,
               run_decision, mem0_memory],
        system_prompt=SUPERVISOR_SYSTEM_PROMPT,
        callback_handler=None,
        trace_attributes={
            "session.id": row["transaction_id"],
            "user.id": row["customer_id"],
            "langfuse.trace.tags": ["fraud-rag-poc-v5", "realtime-sim"],
        },
    )
    prompt = (
        f"Investigate transaction {row['transaction_id']} for customer "
        f"{row['customer_id']}. Narrative: \"{row['narrative']}\". "
        "Triage, retrieve the governing policy, and recommend APPROVE / "
        "FLAG_FOR_REVIEW / BLOCK with a citation."
    )
    verdict_text = str(investigation_supervisor(prompt))

    decision = ("BLOCK" if "BLOCK" in verdict_text.upper()
                else "REVIEW" if "REVIEW" in verdict_text.upper()
                else "APPROVE")
    if decision == "BLOCK":
        publish_alert(row["transaction_id"], row["customer_id"], decision, verdict_text)

    results.append({"transaction_id": row["transaction_id"], "amount": row["amount"],
                    "decision": decision, "summary": verdict_text[:160]})

# Force-flush so batched OTLP spans reach Langfuse now.
trace.get_tracer_provider().force_flush()

display(pd.DataFrame(results)) if "display" in dir() else print(pd.DataFrame(results))
print("Open", LANGFUSE_HOST, "-> Sessions to inspect each investigation.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Airflow DAG — scheduled batch monitoring + alerting on MWAA
# MAGIC
# MAGIC The real-time loop above is interactive. For *scheduled, fan-tolerant* monitoring we author
# MAGIC an **Airflow DAG**, upload it to the MWAA DAGs bucket, and trigger it via the MWAA REST API
# MAGIC — the *"Databricks authors, MWAA executes"* pattern. The DAG runs entirely on MWAA, so it
# MAGIC scores via the **SageMaker endpoint** (MWAA has no Strands/Bedrock agent stack), computes
# MAGIC the fraud rate, **branches**, and **SNS-alerts** on high risk — with a DAG-level
# MAGIC `on_failure_callback` that pages on any task failure.
# MAGIC *(Source: Week 21 — Lab 2 branch + Lab 4 `on_failure_callback`.)*

# COMMAND ----------

# The author -> upload -> poll -> trigger -> wait helpers. Reused verbatim from
# Week 21 cell 6.
def _mwaa_rest(method, path, body=None):
    kw = {"Name": MWAA_ENV, "Method": method, "Path": path}
    if body is not None:
        kw["Body"] = body
    transient = (
        mwaa.exceptions.RestApiClientException,
        mwaa.exceptions.RestApiServerException,
        mwaa.exceptions.ResourceNotFoundException,
        mwaa.exceptions.InternalServerException,
        mwaa.exceptions.ServiceUnavailableException,
    )
    try:
        return mwaa.invoke_rest_api(**kw)
    except transient:
        return {"RestApiStatusCode": 0, "RestApiResponse": {}}


def upload_dag(student_id: str, lab_n: int, dag_code: str) -> str:
    key = f"dags/student_{student_id}/lab{lab_n}.py"
    s3.put_object(Bucket=DAGS_BUCKET, Key=key, Body=dag_code.encode())
    print(f"Uploaded DAG to s3://{DAGS_BUCKET}/{key} ({len(dag_code)} bytes)")
    return key


def poll_until_registered(dag_id: str, max_iters: int = 40, sleep_s: int = 5) -> None:
    for i in range(max_iters):
        if _mwaa_rest("GET", f"/dags/{dag_id}")["RestApiStatusCode"] == 200:
            print(f"DAG {dag_id} registered after ~{i * sleep_s}s")
            return
        time.sleep(sleep_s)
    raise RuntimeError(f"DAG {dag_id} not registered; check Browse -> DAG Import Errors.")


def unpause_dag(dag_id: str) -> None:
    for _ in range(6):
        if _mwaa_rest("PATCH", f"/dags/{dag_id}", {"is_paused": False})["RestApiStatusCode"] == 200:
            print(f"Unpaused {dag_id}")
            return
        time.sleep(5)
    raise RuntimeError(f"unpause_dag failed for {dag_id}")


def trigger_dag(dag_id: str, conf: dict | None = None) -> str:
    run_id = f"student-{STUDENT_ID}-{int(time.time())}"
    unpause_dag(dag_id)
    body = {"dag_run_id": run_id}
    if conf is not None:
        body["conf"] = conf
    resp = _mwaa_rest("POST", f"/dags/{dag_id}/dagRuns", body)
    if resp["RestApiStatusCode"] not in (200, 201):
        raise RuntimeError(f"trigger_dag failed: {resp}")
    print(f"Triggered {dag_id} run_id={run_id}")
    return run_id


def wait_for_dag(dag_id: str, run_id: str, cap_s: int = 900, sleep_s: int = 10) -> str:
    waited = 0
    while waited < cap_s:
        state = _mwaa_rest("GET", f"/dags/{dag_id}/dagRuns/{run_id}")["RestApiResponse"].get("state")
        if state in ("success", "failed"):
            print(f"Run {run_id} finished: {state} (after ~{waited}s)")
            return state
        time.sleep(sleep_s); waited += sleep_s
    raise RuntimeError(f"Run {run_id} did not finish in {cap_s}s.")

print("Helpers defined: upload_dag, poll_until_registered, trigger_dag, wait_for_dag")


# COMMAND ----------

# The fraud-monitoring DAG source (a Python string baked with this notebook's
# config, then uploaded to S3). Tasks:
#   pull_batch -> score_batch -> compute_fraud_rate -> decide_route
#                                                         |-> high_risk (SNS) -> join
#                                                         |-> normal           -> join
# DAG-level on_failure_callback pages SNS on ANY task failure (Lab 4 pattern).
poc_dag_code = f'''
from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.amazon.aws.notifications.sns import send_sns_notification
from airflow.utils.trigger_rule import TriggerRule
from datetime import datetime
import boto3, csv, io, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
ENDPOINT_NAME = "{ENDPOINT_NAME}"
SHARED_BUCKET = "{SHARED_BUCKET}"
REGION        = "{AWS_REGION}"
SNS_TOPIC_ARN = "{SNS_TOPIC_ARN}"

INPUT_KEY     = "lab-inputs/fraud_sample_500.csv"
SLICE_KEY     = f"fraud-poc/student-{{STUDENT_ID}}/slice.csv"
PRED_KEY      = f"fraud-poc/student-{{STUDENT_ID}}/predictions.jsonl"
HIGH_RISK_KEY = f"high-risk/student-{{STUDENT_ID}}/marker.json"


def pull_batch(**context):
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=SHARED_BUCKET, Key=INPUT_KEY)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body))
    rows = list(reader)[:50]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=reader.fieldnames)
    writer.writeheader(); writer.writerows(rows)
    s3.put_object(Bucket=SHARED_BUCKET, Key=SLICE_KEY, Body=out.getvalue().encode())
    return f"s3://{{SHARED_BUCKET}}/{{SLICE_KEY}}"


def score_batch(**context):
    ti = context["ti"]
    bucket, _, key = ti.xcom_pull(task_ids="pull_batch").replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION)
    sm = boto3.client("sagemaker-runtime", region_name=REGION)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode()
    preds = []
    for row in csv.DictReader(io.StringIO(body)):
        resp = sm.invoke_endpoint(EndpointName=ENDPOINT_NAME, ContentType="application/json",
                                  Body=json.dumps({{"inputs": row["narrative"]}}).encode())
        preds.append({{"narrative": row["narrative"],
                       "prediction": json.loads(resp["Body"].read().decode())}})
    s3.put_object(Bucket=SHARED_BUCKET, Key=PRED_KEY,
                  Body=("\\n".join(json.dumps(p) for p in preds)).encode())
    return f"s3://{{SHARED_BUCKET}}/{{PRED_KEY}}"


def compute_fraud_rate(**context):
    ti = context["ti"]
    bucket, _, key = ti.xcom_pull(task_ids="score_batch").replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode()
    lines = [json.loads(l) for l in body.strip().splitlines()]
    def is_fraud(p):
        pred = p["prediction"]
        if isinstance(pred, list) and pred:
            pred = pred[0]
        return isinstance(pred, dict) and pred.get("label") == "LABEL_1"
    return sum(1 for p in lines if is_fraud(p)) / max(len(lines), 1)


def decide_route(**context):
    rate = context["ti"].xcom_pull(task_ids="compute_fraud_rate")
    threshold = context["dag_run"].conf.get("fraud_rate_threshold", 0.05)
    return "high_risk" if rate > threshold else "normal"


def high_risk(**context):
    rate = context["ti"].xcom_pull(task_ids="compute_fraud_rate")
    s3 = boto3.client("s3", region_name=REGION)
    s3.put_object(Bucket=SHARED_BUCKET, Key=HIGH_RISK_KEY,
                  Body=json.dumps({{"fraud_rate": rate, "student_id": STUDENT_ID}}).encode())
    sns = boto3.client("sns", region_name=REGION)
    sns.publish(TopicArn=SNS_TOPIC_ARN, Subject="High fraud rate detected",
                Message=f"student {{STUDENT_ID}} fraud_rate={{rate:.3f}}")
    print(f"HIGH RISK: rate={{rate:.3f}}")


def normal(**context):
    rate = context["ti"].xcom_pull(task_ids="compute_fraud_rate")
    print(f"NORMAL: rate={{rate:.3f}}")


# Page on ANY task failure (Lab 4 pattern).
sns_failure = send_sns_notification(
    aws_conn_id="aws_default",
    region_name=REGION,
    target_arn=SNS_TOPIC_ARN,
    subject=f"DAG FAILURE fraud_poc_{{USER_SLUG}}",
    message="A task in the fraud monitoring DAG failed. Check the Airflow UI.",
)
default_args = {{"on_failure_callback": sns_failure}}

with DAG(
    dag_id=f"fraud_poc_monitor_{{USER_SLUG}}",
    start_date=datetime(2026, 1, 1),
    schedule="@hourly",
    catchup=False,
    default_args=default_args,
) as dag:
    t_pull   = PythonOperator(task_id="pull_batch",  python_callable=pull_batch)
    t_score  = PythonOperator(task_id="score_batch", python_callable=score_batch)
    t_rate   = PythonOperator(task_id="compute_fraud_rate", python_callable=compute_fraud_rate)
    t_decide = BranchPythonOperator(task_id="decide_route", python_callable=decide_route)
    t_high   = PythonOperator(task_id="high_risk", python_callable=high_risk)
    t_norm   = PythonOperator(task_id="normal",    python_callable=normal)
    t_join   = EmptyOperator(task_id="join", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
    t_pull >> t_score >> t_rate >> t_decide >> [t_high, t_norm] >> t_join
'''

print(f"DAG source built: {len(poc_dag_code)} bytes")


# COMMAND ----------

# Author -> upload -> poll -> trigger -> wait. Forces the high-risk branch via conf
# so the demo run exercises the SNS alert path.
DAG_ID = f"fraud_poc_monitor_{USER_SLUG}"

upload_dag(STUDENT_ID, lab_n=5, dag_code=poc_dag_code)
poll_until_registered(DAG_ID)
run_id = trigger_dag(DAG_ID, conf={"fraud_rate_threshold": 0.0})  # 0.0 => always high_risk
final_state = wait_for_dag(DAG_ID, run_id)
print("DAG run finished:", final_state)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Wrap-up — what's real vs. what needs provisioning
# MAGIC
# MAGIC **Real code, runs as-is once the resources exist:** the Databricks→Bedrock auth, the
# MAGIC Cohere-reranked KB RAG, the multi-agent supervisor + Swarm, the Langfuse-traced Spark loop,
# MAGIC and the MWAA DAG authoring/trigger flow.
# MAGIC
# MAGIC **You must provide (Section 1 constants):** `KNOWLEDGE_BASE_ID` (a populated Bedrock KB),
# MAGIC Bedrock model access (Claude Sonnet + Titan v2 + Cohere Rerank 3.5), the Databricks secret
# MAGIC scope, the `bread_academy.course_data.fraud_transactions` table, the `ENDPOINT_NAME`
# MAGIC classifier, the `SNS_TOPIC_ARN`, and the MWAA environment + DAGs bucket.
# MAGIC
# MAGIC **To go from simulation to true real-time:** replace the `spark.read.table(...).limit(5)`
# MAGIC in Component 4 with a Structured Streaming `spark.readStream` over the transaction source
# MAGIC and run the supervisor inside `foreachBatch`. The MWAA DAG already covers the scheduled
# MAGIC path; tighten its `schedule` from `@hourly` as needed.
# MAGIC
# MAGIC **Lever to pull next:** swap the heuristic `calculate_risk_score` for the fine-tuned
# MAGIC classifier's probability, and add `context_recall` to the RAGAS gate (Section 2b) so a CI
# MAGIC job can block deploys when retrieval quality regresses.
# MAGIC