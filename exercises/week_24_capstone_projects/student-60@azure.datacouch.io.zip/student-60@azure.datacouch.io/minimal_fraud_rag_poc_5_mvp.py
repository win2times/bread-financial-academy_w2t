# Databricks notebook source
# MAGIC %md
# MAGIC # Fraud Detection with RAG — MVP (Single Agent)
# MAGIC
# MAGIC A **minimum viable** version of `minimal_fraud_rag_poc_5.ipynb`. Same end-to-end story —
# MAGIC read a transaction, consult the fraud-rules Knowledge Base, decide, alert — but the
# MAGIC four-agent system (supervisor + triage/investigation/decision specialists + Swarm) is
# MAGIC collapsed into **one agent that holds all the tools**.
# MAGIC
# MAGIC **Why single-agent for an MVP:** fewer LLM round-trips (cheaper, faster), one prompt and
# MAGIC one trace to debug instead of inter-agent handoffs, and no `mem0_memory`/faiss dependency
# MAGIC (lighter install, fewer kernel restarts). Multi-agent only pays off when specialists need
# MAGIC isolation or parallelism — out of scope for a POC.
# MAGIC
# MAGIC | Component | MVP status | Notes |
# MAGIC |-----------|-----------|-------|
# MAGIC | **1. Databricks → Bedrock** | **core** | secret auth, boto3 clients, `BedrockModel` |
# MAGIC | **2. KB RAG (Cohere Rerank 3.5)** | **core** | the differentiator; this is the "RAG" |
# MAGIC | **3. Agent** | **core, simplified** | **one** `fraud_agent` with all tools |
# MAGIC | **4. Near-real-time loop** | **core** | Spark transaction stream |
# MAGIC | **5. Alerts** | **core** | SNS publish on BLOCK |
# MAGIC | Langfuse tracing | *optional* | observability, not function |
# MAGIC | RAGAS eval | *optional* | offline quality check |
# MAGIC | Airflow DAG | *optional* | scheduled scale-out path |
# MAGIC
# MAGIC > **Run the core in minutes:** run Sections 0–4 and Component 5. Skip any cell labeled
# MAGIC > *OPTIONAL*. **Leaner still:** swap `retrieve_policy_reranked` for a plain
# MAGIC > `bedrock_agent_runtime.retrieve` to drop the rerank model + call.
# MAGIC
# MAGIC > **Carryover:** the demo `TRANSACTION_DATABASE` fixtures and a couple of
# MAGIC > secret-scope key names (`fraud-kb-id`, `fraud-alerts-topic-arn`) are **fabricated
# MAGIC > placeholders** — replace with the real values.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## What you must provision first
# MAGIC
# MAGIC - A **Bedrock Knowledge Base** of fraud / BSA-AML / OFAC / CTR policy docs → `KNOWLEDGE_BASE_ID`
# MAGIC - Bedrock model access: **Claude Sonnet** + **Cohere Rerank 3.5** (+ **Titan v2** only if you run the optional RAGAS eval)
# MAGIC - A Databricks **secret scope** with AWS keys (`aws-course-creds-NN`, `aws-course-shared`)
# MAGIC - A Spark table `bread_academy.course_data.fraud_transactions`
# MAGIC - A deployed **SageMaker** fraud-classifier endpoint → `ENDPOINT_NAME`
# MAGIC - An **SNS topic** for alerts → `SNS_TOPIC_ARN`
# MAGIC - *(optional)* an **MWAA** environment + DAGs bucket for the Airflow section
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Section 0 — Install & import (lean)
# MAGIC
# MAGIC Core install only: `boto3` + Strands. No faiss/numpy pin (we dropped `mem0_memory`).
# MAGIC The optional RAGAS section installs its own extras.

# COMMAND ----------

# Databricks may prompt a kernel restart after install — expected.
%pip install -q "boto3>=1.36" "strands-agents>=1.37,<2" "strands-agents-tools>=0.2"


# COMMAND ----------

import os
import json
import time
import base64
import boto3
import pandas as pd

from strands import Agent, tool
from strands.models import BedrockModel

from importlib.metadata import version as pkg_version
for pkg in ["boto3", "strands-agents", "strands-agents-tools"]:
    try:
        print(f"  {pkg:<22} {pkg_version(pkg)}")
    except Exception:
        print(f"  {pkg:<22} (not found)")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Component 1 — Databricks → Bedrock setup *(core)*
# MAGIC
# MAGIC Secret-based AWS auth and the boto3 clients. *(Source: Week 20 / 21 cell 3.)*

# COMMAND ----------

# Pull secrets, build clients. NEVER hard-code credentials.
_user = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook().getContext().userName().get()
)
_num = _user.split("@")[0].split("-")[1] if _user.startswith("student-") else "01"
creds_scope = f"aws-course-creds-{_num}"

AWS_ACCESS_KEY_ID     = dbutils.secrets.get(scope=creds_scope, key="aws-access-key-id")
AWS_SECRET_ACCESS_KEY = dbutils.secrets.get(scope=creds_scope, key="aws-secret-access-key")
AWS_REGION            = dbutils.secrets.get(scope="aws-course-shared", key="aws-region")

os.environ["AWS_ACCESS_KEY_ID"]     = AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = AWS_SECRET_ACCESS_KEY
os.environ["AWS_REGION"]            = AWS_REGION
os.environ["AWS_DEFAULT_REGION"]    = AWS_REGION
os.environ["AWS_REGION_NAME"]       = AWS_REGION

bedrock_client        = boto3.client("bedrock",               region_name=AWS_REGION)
bedrock_runtime       = boto3.client("bedrock-runtime",       region_name=AWS_REGION)
bedrock_agent_runtime = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)
sm_runtime            = boto3.client("sagemaker-runtime",     region_name=AWS_REGION)
s3                    = boto3.client("s3",                    region_name=AWS_REGION)
sns                   = boto3.client("sns",                   region_name=AWS_REGION)
mwaa                  = boto3.client("mwaa",                  region_name=AWS_REGION)  # optional DAG section

try:
    n = len(bedrock_client.list_foundation_models()["modelSummaries"])
    print(f"Connected to Bedrock: {n} models visible.")
except Exception as e:
    print(f"Bedrock connection failed: {e}")


# COMMAND ----------

# ---- Config (EDIT for your environment) ------------------------------------
MODEL_ID         = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
RERANK_MODEL_ID  = "cohere.rerank-v3-5:0"
RERANK_MODEL_ARN = f"arn:aws:bedrock:{AWS_REGION}::foundation-model/{RERANK_MODEL_ID}"

KNOWLEDGE_BASE_ID = dbutils.secrets.get(scope="aws-course-shared", key="fraud-kb-id")

cohort = (int(_num) - 1) // 20 + 1
ENDPOINT_NAME = dbutils.secrets.get(scope="aws-course-shared", key="endpoint-name-base") + f"-{cohort}"

SNS_TOPIC_ARN = dbutils.secrets.get(scope="aws-course-shared", key="fraud-alerts-topic-arn")
SHARED_BUCKET = "bread-academy-shared"
DAGS_BUCKET   = "bread-academy-airflow-dags"
MWAA_ENV      = "bread-academy-airflow"
STUDENT_ID    = _num
USER_SLUG     = f"participant_{_num}"

# One shared model handle for the agent.
bedrock_model = BedrockModel(model_id=MODEL_ID, region_name=AWS_REGION)

print("Model:", MODEL_ID, "| KB:", KNOWLEDGE_BASE_ID, "| Endpoint:", ENDPOINT_NAME)


# COMMAND ----------

# MAGIC %md
# MAGIC ### *(OPTIONAL)* Langfuse tracing
# MAGIC
# MAGIC Skip this cell for the fastest run. If kept, every agent + tool call shows up as a span.
# MAGIC *(Source: Week 20 cell 7.)*

# COMMAND ----------

# OPTIONAL. Comment out the whole cell to skip observability.
from strands.telemetry import StrandsTelemetry

LANGFUSE_PUBLIC_KEY = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-public-key")
LANGFUSE_SECRET_KEY = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-secret-key")
LANGFUSE_HOST       = dbutils.secrets.get(scope="aws-course-shared", key="langfuse-host")

LANGFUSE_AUTH = base64.b64encode(
    f"{LANGFUSE_PUBLIC_KEY}:{LANGFUSE_SECRET_KEY}".encode()
).decode()
os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = LANGFUSE_HOST + "/api/public/otel"
os.environ["OTEL_EXPORTER_OTLP_HEADERS"]  = f"Authorization=Basic {LANGFUSE_AUTH}"
os.environ["OTEL_SERVICE_NAME"]           = "fraud-rag-mvp"
StrandsTelemetry().setup_otlp_exporter()
print("Langfuse wired:", LANGFUSE_HOST)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Component 2 — KB RAG with Cohere Rerank 3.5 *(core)*
# MAGIC
# MAGIC KB retrieve → cross-encoder rerank. Exposed as a single `@tool` the agent calls.
# MAGIC *(Source: Week 18 cells 14 & 17.)* **Leaner option:** replace `reranked_retrieve` with a
# MAGIC plain `bedrock_agent_runtime.retrieve(...)` to drop the rerank model + call.

# COMMAND ----------

def bedrock_rerank(query_text: str, text_sources: list, num_results: int = 3) -> list:
    """Rerank text_sources by relevance to query_text using Cohere Rerank 3.5."""
    if not text_sources:
        return []
    response = bedrock_agent_runtime.rerank(
        queries=[{"type": "TEXT", "textQuery": {"text": query_text}}],
        sources=[{"type": "INLINE",
                  "inlineDocumentSource": {"type": "TEXT", "textDocument": {"text": s}}}
                 for s in text_sources],
        rerankingConfiguration={
            "type": "BEDROCK_RERANKING_MODEL",
            "bedrockRerankingConfiguration": {
                "numberOfResults": num_results,
                "modelConfiguration": {"modelArn": RERANK_MODEL_ARN},
            },
        },
    )
    return [{"index": r["index"], "relevance_score": r["relevanceScore"],
             "text": text_sources[r["index"]]} for r in response["results"]]


def reranked_retrieve(query: str, k_retrieve: int = 10, k_final: int = 3) -> list:
    raw = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=KNOWLEDGE_BASE_ID,
        retrievalQuery={"text": query},
        retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": k_retrieve}},
    )
    items = raw.get("retrievalResults", [])
    candidates = [i.get("content", {}).get("text", "") for i in items]
    sources    = [i.get("location", {}) for i in items]
    ranked = bedrock_rerank(query, candidates, num_results=k_final)
    for r in ranked:
        r["source_uri"] = sources[r["index"]].get("s3Location", {}).get("uri", "unknown")
    return ranked


@tool
def retrieve_policy_reranked(query: str) -> str:
    """Retrieve fraud-policy chunks from the KB, reranked by Cohere Rerank 3.5.

    Args:
        query: The policy question or investigation query.
    """
    ranked = reranked_retrieve(query, k_retrieve=10, k_final=3)
    lines = []
    for i, r in enumerate(ranked, 1):
        lines.append(f"[{i}] score={r['relevance_score']:.3f} | {r['source_uri']}")
        lines.append(r["text"])
        lines.append("")
    return "\n".join(lines)

print("RAG tool ready: retrieve_policy_reranked")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Component 3 — The single fraud agent *(core, simplified)*
# MAGIC
# MAGIC One `Agent` with every tool attached. The system prompt drives the full flow itself:
# MAGIC look up → score → classify → retrieve policy → decide. No supervisor, no specialists, no
# MAGIC Swarm. *(Tools: Week 16 cell 6 / Week 20 cell 5; RAG tool from Component 2.)*

# COMMAND ----------

# Demo fixtures the lookup tools read from. FABRICATED placeholders — in production
# these tools would query the Spark/Delta tables. Replace with real values.
TRANSACTION_DATABASE = {
    "TXN-001": {"transaction_id": "TXN-001", "amount": 4500.0, "merchant": "Overseas Wire Co",
                "merchant_country": "GB", "hour": 3, "channel": "wire",
                "narrative": "International wire transfer to a new overseas payee at 03:47."},
    "TXN-002": {"transaction_id": "TXN-002", "amount": 12.99, "merchant": "StreamFlix",
                "merchant_country": "US", "hour": 19, "channel": "card_present",
                "narrative": "Recurring streaming subscription on a known device."},
}
CUSTOMER_HISTORY = {
    "TXN-001": {"customer_id": "C002", "avg_monthly_spend": 1800.0, "home_country": "US"},
    "TXN-002": {"customer_id": "C001", "avg_monthly_spend": 1600.0, "home_country": "US"},
}


@tool
def lookup_transaction(transaction_id: str) -> str:
    """Look up transaction details by ID.

    Args:
        transaction_id: The transaction ID (e.g., 'TXN-001').
    """
    txn = TRANSACTION_DATABASE.get(transaction_id)
    return json.dumps(txn, indent=2) if txn else f"Transaction {transaction_id} not found."


@tool
def check_customer_history(transaction_id: str) -> str:
    """Check the customer's spend history for a transaction.

    Args:
        transaction_id: The transaction ID to check.
    """
    h = CUSTOMER_HISTORY.get(transaction_id)
    return json.dumps(h, indent=2) if h else f"No history for {transaction_id}."


@tool
def calculate_risk_score(amount: float, avg_monthly_spend: float, is_international: bool,
                         is_unusual_hour: bool, is_new_merchant: bool) -> str:
    """Calculate a fraud risk score (0-100).

    Args:
        amount: Transaction amount in dollars.
        avg_monthly_spend: Customer's average monthly spend.
        is_international: Whether the transaction crosses borders.
        is_unusual_hour: Whether it occurred at an unusual time.
        is_new_merchant: Whether the merchant is new to this customer.
    """
    amount_ratio = min(amount / max(avg_monthly_spend, 1), 5.0)
    risk = (min(amount_ratio * 20, 100) * 0.30 + (90 if is_international else 0) * 0.25
            + (70 if is_unusual_hour else 0) * 0.20 + (50 if is_new_merchant else 0) * 0.15 + 10)
    level = "LOW" if risk < 30 else "MEDIUM" if risk < 60 else "HIGH"
    return json.dumps({"risk_score": round(risk, 1), "risk_level": level})


@tool
def classify_with_finetuned_model(narrative: str) -> str:
    """Classify a transaction narrative via the SageMaker fraud classifier.

    Args:
        narrative: Free-text description of the transaction.
    """
    out = sm_runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME, ContentType="application/json",
        Body=json.dumps({"inputs": narrative}),
    )
    return out["Body"].read().decode()


# COMMAND ----------

# THE SINGLE AGENT. One prompt runs the whole investigation.
FRAUD_AGENT_PROMPT = (
    "You are a fraud investigation agent. For each transaction, in order: "
    "1) lookup_transaction and check_customer_history; "
    "2) calculate_risk_score from those details; "
    "3) classify_with_finetuned_model on the narrative; "
    "4) retrieve_policy_reranked to get the governing fraud policy from the knowledge base; "
    "5) render a FINAL VERDICT — APPROVE, FLAG_FOR_REVIEW, or BLOCK — with a one-line "
    "policy citation. Answer policy questions only from retrieved content."
)

fraud_agent = Agent(
    model=bedrock_model,
    tools=[lookup_transaction, check_customer_history, calculate_risk_score,
           classify_with_finetuned_model, retrieve_policy_reranked],
    system_prompt=FRAUD_AGENT_PROMPT,
    callback_handler=None,
)

print("Single fraud_agent ready with 5 tools.")
print(str(fraud_agent("Investigate transaction TXN-001 for potential fraud."))[:600])


# COMMAND ----------

# MAGIC %md
# MAGIC ## Components 4 & 5 — Near-real-time loop + alerts *(core)*
# MAGIC
# MAGIC Pull rows from the Delta table, run the single agent per transaction (one Langfuse session
# MAGIC each if tracing is on), and **SNS-alert** on a BLOCK verdict. Swap `.limit(5)` for a
# MAGIC `spark.readStream` + `foreachBatch` to go truly real-time.
# MAGIC *(Source: Week 20 cell 11 loop + Week 21 `sns.publish`.)*

# COMMAND ----------

try:
    from opentelemetry import trace
    _otel = True
except Exception:
    _otel = False

lab_rows = (
    spark.read.table("bread_academy.course_data.fraud_transactions")
    .filter("is_fraud = 1")
    .select("transaction_id", "customer_id", "amount", "merchant_country", "narrative")
    .orderBy("transaction_id")
    .limit(5)
    .collect()
)


def publish_alert(transaction_id, customer_id, verdict, detail):
    """Component 5: SNS alert for a blocked transaction."""
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject=f"FRAUD ALERT [{verdict}] {transaction_id}",
        Message=json.dumps({"transaction_id": transaction_id, "customer_id": customer_id,
                            "verdict": verdict, "detail": detail[:900]}),
    )


results = []
for row in lab_rows:
    # Rebuild per row so each investigation is its own Langfuse session.
    agent = Agent(
        model=bedrock_model,
        tools=[lookup_transaction, check_customer_history, calculate_risk_score,
               classify_with_finetuned_model, retrieve_policy_reranked],
        system_prompt=FRAUD_AGENT_PROMPT,
        callback_handler=None,
        trace_attributes={
            "session.id": row["transaction_id"],
            "user.id": row["customer_id"],
            "langfuse.trace.tags": ["fraud-rag-mvp"],
        },
    )
    prompt = (f"Investigate transaction {row['transaction_id']} for customer "
              f"{row['customer_id']}. Narrative: \"{row['narrative']}\". "
              "Score it, retrieve the governing policy, and give a verdict with a citation.")
    verdict_text = str(agent(prompt))

    decision = ("BLOCK" if "BLOCK" in verdict_text.upper()
                else "REVIEW" if "REVIEW" in verdict_text.upper() else "APPROVE")
    if decision == "BLOCK":
        publish_alert(row["transaction_id"], row["customer_id"], decision, verdict_text)

    results.append({"transaction_id": row["transaction_id"], "amount": row["amount"],
                    "decision": decision, "summary": verdict_text[:160]})

if _otel:
    trace.get_tracer_provider().force_flush()

print(pd.DataFrame(results).to_string(index=False))


# COMMAND ----------

# MAGIC %md
# MAGIC ## *(OPTIONAL)* Prove the RAG with RAGAS
# MAGIC
# MAGIC Offline quality check — skip for the core MVP. Installs its own extras.
# MAGIC *(Source: Week 18 cell 25.)*

# COMMAND ----------

# OPTIONAL.
%pip install -q "langchain-aws>=0.2" "ragas>=0.2,<0.3"


# COMMAND ----------

# OPTIONAL. faithfulness + answer relevancy, baseline vs reranked retrieval.
from langchain_aws import ChatBedrockConverse, BedrockEmbeddings
from ragas import evaluate, EvaluationDataset, SingleTurnSample
from ragas.metrics import faithfulness, answer_relevancy
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper

langchain_llm      = ChatBedrockConverse(model=MODEL_ID, region_name=AWS_REGION)
bedrock_embeddings = BedrockEmbeddings(model_id="amazon.titan-embed-text-v2:0", region_name=AWS_REGION)
evaluator_llm        = LangchainLLMWrapper(langchain_llm)
evaluator_embeddings = LangchainEmbeddingsWrapper(bedrock_embeddings)

def _baseline_sample(q):
    raw = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=KNOWLEDGE_BASE_ID, retrievalQuery={"text": q},
        retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": 3}})
    ctx = [i["content"]["text"] for i in raw.get("retrievalResults", [])]
    p = f"Answer using only the context.\n\nContext:\n{chr(10).join(ctx)}\n\nQuestion: {q}\nAnswer:"
    return SingleTurnSample(user_input=q, response=langchain_llm.invoke(p).content, retrieved_contexts=ctx)

def _reranked_sample(q):
    ranked = reranked_retrieve(q, k_retrieve=10, k_final=3)
    ctx = [r["text"] for r in ranked]
    p = f"Answer using only the context.\n\nContext:\n{chr(10).join(ctx)}\n\nQuestion: {q}\nAnswer:"
    return SingleTurnSample(user_input=q, response=langchain_llm.invoke(p).content, retrieved_contexts=ctx)

def score_config(name, builder, questions):
    ds = EvaluationDataset(samples=[builder(q) for q in questions])
    r = evaluate(dataset=ds, metrics=[faithfulness, answer_relevancy],
                 llm=evaluator_llm, embeddings=evaluator_embeddings)
    df = r.to_pandas(); df["config"] = name
    return df[["config", "user_input", "faithfulness", "answer_relevancy"]]

qs = ["What is the CTR reporting threshold?",
      "When must a bank file a CTR on aggregated transactions?",
      "What evidence indicates account takeover?"]
compare = pd.concat([score_config("baseline", _baseline_sample, qs),
                     score_config("+ rerank", _reranked_sample, qs)], ignore_index=True)
print(compare.to_string(index=False))
print("\nMean per config:")
print(compare.groupby("config")[["faithfulness", "answer_relevancy"]].mean().round(3))


# COMMAND ----------

# MAGIC %md
# MAGIC ## *(OPTIONAL)* Scheduled monitoring on MWAA (Airflow)
# MAGIC
# MAGIC The scale-out path — skip for the core MVP. The in-notebook loop above already proves the
# MAGIC value. This DAG runs on MWAA (no agent stack there), so it scores via the **SageMaker
# MAGIC endpoint**, computes a fraud rate, **branches**, and **SNS-alerts** on high risk, with a
# MAGIC DAG-level failure callback. *(Source: Week 21 — Lab 2 branch + Lab 4 `on_failure_callback`.)*

# COMMAND ----------

# OPTIONAL. Author -> upload -> poll -> trigger -> wait helpers (Week 21 cell 6).
def _mwaa_rest(method, path, body=None):
    kw = {"Name": MWAA_ENV, "Method": method, "Path": path}
    if body is not None:
        kw["Body"] = body
    transient = (mwaa.exceptions.RestApiClientException, mwaa.exceptions.RestApiServerException,
                 mwaa.exceptions.ResourceNotFoundException, mwaa.exceptions.InternalServerException,
                 mwaa.exceptions.ServiceUnavailableException)
    try:
        return mwaa.invoke_rest_api(**kw)
    except transient:
        return {"RestApiStatusCode": 0, "RestApiResponse": {}}

def upload_dag(student_id, lab_n, dag_code):
    key = f"dags/student_{student_id}/lab{lab_n}.py"
    s3.put_object(Bucket=DAGS_BUCKET, Key=key, Body=dag_code.encode())
    print(f"Uploaded s3://{DAGS_BUCKET}/{key} ({len(dag_code)} bytes)"); return key

def poll_until_registered(dag_id, max_iters=40, sleep_s=5):
    for i in range(max_iters):
        if _mwaa_rest("GET", f"/dags/{dag_id}")["RestApiStatusCode"] == 200:
            print(f"DAG {dag_id} registered after ~{i*sleep_s}s"); return
        time.sleep(sleep_s)
    raise RuntimeError(f"{dag_id} not registered; check Browse -> DAG Import Errors.")

def unpause_dag(dag_id):
    for _ in range(6):
        if _mwaa_rest("PATCH", f"/dags/{dag_id}", {"is_paused": False})["RestApiStatusCode"] == 200:
            print(f"Unpaused {dag_id}"); return
        time.sleep(5)
    raise RuntimeError(f"unpause failed for {dag_id}")

def trigger_dag(dag_id, conf=None):
    run_id = f"student-{STUDENT_ID}-{int(time.time())}"
    unpause_dag(dag_id)
    body = {"dag_run_id": run_id}
    if conf is not None:
        body["conf"] = conf
    resp = _mwaa_rest("POST", f"/dags/{dag_id}/dagRuns", body)
    if resp["RestApiStatusCode"] not in (200, 201):
        raise RuntimeError(f"trigger failed: {resp}")
    print(f"Triggered {dag_id} run_id={run_id}"); return run_id

def wait_for_dag(dag_id, run_id, cap_s=900, sleep_s=10):
    waited = 0
    while waited < cap_s:
        state = _mwaa_rest("GET", f"/dags/{dag_id}/dagRuns/{run_id}")["RestApiResponse"].get("state")
        if state in ("success", "failed"):
            print(f"Run {run_id}: {state} (~{waited}s)"); return state
        time.sleep(sleep_s); waited += sleep_s
    raise RuntimeError(f"Run {run_id} did not finish in {cap_s}s.")

print("DAG helpers ready.")


# COMMAND ----------

# OPTIONAL. The monitoring DAG (endpoint scoring -> fraud rate -> branch -> SNS).
poc_dag_code = f'''
from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.amazon.aws.notifications.sns import send_sns_notification
from airflow.utils.trigger_rule import TriggerRule
from datetime import datetime
import boto3, csv, io, json

STUDENT_ID    = "{STUDENT_ID}"
USER_SLUG     = "{USER_SLUG}"
ENDPOINT_NAME = "{ENDPOINT_NAME}"
SHARED_BUCKET = "{SHARED_BUCKET}"
REGION        = "{AWS_REGION}"
SNS_TOPIC_ARN = "{SNS_TOPIC_ARN}"

INPUT_KEY     = "lab-inputs/fraud_sample_500.csv"
SLICE_KEY     = f"fraud-mvp/student-{{STUDENT_ID}}/slice.csv"
PRED_KEY      = f"fraud-mvp/student-{{STUDENT_ID}}/predictions.jsonl"


def pull_batch(**c):
    s3 = boto3.client("s3", region_name=REGION)
    body = s3.get_object(Bucket=SHARED_BUCKET, Key=INPUT_KEY)["Body"].read().decode()
    reader = csv.DictReader(io.StringIO(body)); rows = list(reader)[:50]
    out = io.StringIO(); w = csv.DictWriter(out, fieldnames=reader.fieldnames)
    w.writeheader(); w.writerows(rows)
    s3.put_object(Bucket=SHARED_BUCKET, Key=SLICE_KEY, Body=out.getvalue().encode())
    return f"s3://{{SHARED_BUCKET}}/{{SLICE_KEY}}"


def score_batch(**c):
    bucket, _, key = c["ti"].xcom_pull(task_ids="pull_batch").replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION); sm = boto3.client("sagemaker-runtime", region_name=REGION)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode()
    preds = []
    for row in csv.DictReader(io.StringIO(body)):
        r = sm.invoke_endpoint(EndpointName=ENDPOINT_NAME, ContentType="application/json",
                               Body=json.dumps({{"inputs": row["narrative"]}}).encode())
        preds.append({{"narrative": row["narrative"], "prediction": json.loads(r["Body"].read().decode())}})
    s3.put_object(Bucket=SHARED_BUCKET, Key=PRED_KEY,
                  Body=("\\n".join(json.dumps(p) for p in preds)).encode())
    return f"s3://{{SHARED_BUCKET}}/{{PRED_KEY}}"


def compute_fraud_rate(**c):
    bucket, _, key = c["ti"].xcom_pull(task_ids="score_batch").replace("s3://", "").partition("/")
    s3 = boto3.client("s3", region_name=REGION)
    lines = [json.loads(l) for l in
             s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode().strip().splitlines()]
    def is_fraud(p):
        pred = p["prediction"]
        if isinstance(pred, list) and pred: pred = pred[0]
        return isinstance(pred, dict) and pred.get("label") == "LABEL_1"
    return sum(1 for p in lines if is_fraud(p)) / max(len(lines), 1)


def decide_route(**c):
    rate = c["ti"].xcom_pull(task_ids="compute_fraud_rate")
    return "high_risk" if rate > c["dag_run"].conf.get("fraud_rate_threshold", 0.05) else "normal"


def high_risk(**c):
    rate = c["ti"].xcom_pull(task_ids="compute_fraud_rate")
    boto3.client("sns", region_name=REGION).publish(
        TopicArn=SNS_TOPIC_ARN, Subject="High fraud rate detected",
        Message=f"student {{STUDENT_ID}} fraud_rate={{rate:.3f}}")
    print(f"HIGH RISK: {{rate:.3f}}")


def normal(**c):
    print("NORMAL:", c["ti"].xcom_pull(task_ids="compute_fraud_rate"))


sns_failure = send_sns_notification(aws_conn_id="aws_default", region_name=REGION,
    target_arn=SNS_TOPIC_ARN, subject=f"DAG FAILURE fraud_mvp_{{USER_SLUG}}",
    message="A task in the fraud MVP DAG failed.")

with DAG(dag_id=f"fraud_mvp_monitor_{{USER_SLUG}}", start_date=datetime(2026, 1, 1),
         schedule="@hourly", catchup=False,
         default_args={{"on_failure_callback": sns_failure}}) as dag:
    t_pull   = PythonOperator(task_id="pull_batch",  python_callable=pull_batch)
    t_score  = PythonOperator(task_id="score_batch", python_callable=score_batch)
    t_rate   = PythonOperator(task_id="compute_fraud_rate", python_callable=compute_fraud_rate)
    t_decide = BranchPythonOperator(task_id="decide_route", python_callable=decide_route)
    t_high   = PythonOperator(task_id="high_risk", python_callable=high_risk)
    t_norm   = PythonOperator(task_id="normal",    python_callable=normal)
    t_join   = EmptyOperator(task_id="join", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
    t_pull >> t_score >> t_rate >> t_decide >> [t_high, t_norm] >> t_join
'''

DAG_ID = f"fraud_mvp_monitor_{USER_SLUG}"
upload_dag(STUDENT_ID, lab_n=5, dag_code=poc_dag_code)
poll_until_registered(DAG_ID)
run_id = trigger_dag(DAG_ID, conf={"fraud_rate_threshold": 0.0})  # 0.0 => force high_risk
print("DAG run finished:", wait_for_dag(DAG_ID, run_id))


# COMMAND ----------

# MAGIC %md
# MAGIC ## Wrap-up
# MAGIC
# MAGIC **Core MVP path (Sections 0–4 + Components 4–5):** Databricks→Bedrock auth → Cohere-reranked
# MAGIC KB RAG → one `fraud_agent` → Spark loop → SNS alert. That alone is the viable product.
# MAGIC
# MAGIC **Optional layers:** Langfuse (observability), RAGAS (offline eval), the MWAA DAG
# MAGIC (scheduled scale-out). Each is isolated and skippable.
# MAGIC
# MAGIC **To grow up from MVP:** (1) `spark.readStream` + `foreachBatch` for true real-time;
# MAGIC (2) re-introduce specialist agents only if one stage needs isolation/parallelism;
# MAGIC (3) feed the classifier's probability into `calculate_risk_score`; (4) gate deploys on a
# MAGIC RAGAS threshold in CI.
# MAGIC
# MAGIC *Unchanged caveats:* demo fixtures and two secret-key names are fabricated placeholders;
# MAGIC nothing here has been executed — wire in real resources before running.
# MAGIC