# Databricks notebook source
# MAGIC %md
# MAGIC # Week 23: AI Governance and Ethics - Fairness and Explainability
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this session, you will be able to:
# MAGIC 1. **Audit a model for bias** using Fairlearn's `MetricFrame` and fairness metrics
# MAGIC 2. **Mitigate bias** with Fairlearn's `ThresholdOptimizer` and understand the fairness-accuracy tradeoff
# MAGIC 3. **Explain individual predictions** with SHAP, including the local explanation behind a single decision
# MAGIC 4. **Cross-check with a second opinion** using AIF360 fairness metrics and LIME explanations
# MAGIC 5. **Produce a governance artifact** - a model card that documents the model, its fairness results, the accountable owner, and the human-oversight rule
# MAGIC 6. **Connect the practice to regulation** - ECOA adverse-action notices, GDPR right to explanation, and the EU AI Act high-risk classification of credit scoring
# MAGIC
# MAGIC ## Prerequisites
# MAGIC
# MAGIC - Completed the modeling weeks (you have trained and evaluated classifiers before)
# MAGIC - Watched the pre-class videos on AI ethics principles, bias in ML, fairness metrics, explainability, and the regulatory landscape (GDPR, EU AI Act)
# MAGIC
# MAGIC ## Session Format (~1.75 hours)
# MAGIC
# MAGIC | Section | Duration | Type |
# MAGIC |---------|----------|------|
# MAGIC | Section 0: Setup and Baseline Model | 12 min | Code |
# MAGIC | Section 1: Auditing a Credit Model for Bias | 18 min | Demo |
# MAGIC | Lab 1: Mitigate Bias with ThresholdOptimizer | 15 min | Lab |
# MAGIC | Section 2: Explaining Decisions with SHAP | 18 min | Demo |
# MAGIC | Lab 2: Explain a Denied Application | 15 min | Lab |
# MAGIC | Section 3: Second Opinion (AIF360 + LIME) and Governance | 12 min | Demo |
# MAGIC | Lab 3: Write a Model Card (governance) | 10 min | Lab |
# MAGIC | Wrap-up and Homework | 6 min | Markdown |
# MAGIC
# MAGIC ## The Story So Far
# MAGIC
# MAGIC All program long you have built models for Bread Financial: fraud detection,
# MAGIC credit scoring, customer analytics. They are accurate. But accuracy is not the
# MAGIC only thing that matters when a model decides whether a real person gets a loan.
# MAGIC
# MAGIC Imagine your loan-approval model approves men at a much higher rate than women
# MAGIC with the same income and credit profile. That is not just a bad look. Under the
# MAGIC Equal Credit Opportunity Act (ECOA) it is illegal, and a regulator can demand a
# MAGIC written reason for every single denial. Today you learn the two skills that keep
# MAGIC a model on the right side of that line:
# MAGIC
# MAGIC - **Fairness**: measure whether the model treats demographic groups equitably,
# MAGIC   and fix it if it does not.
# MAGIC - **Explainability**: produce a clear, per-applicant reason for any decision,
# MAGIC   which is exactly what an adverse-action notice requires.
# MAGIC
# MAGIC We work on a public census dataset reframed as a Bread Financial loan-approval
# MAGIC model, because unlike the fraud data from prior weeks it carries the protected
# MAGIC attributes (such as sex) that a fairness audit needs.
# MAGIC
# MAGIC ## Platform
# MAGIC
# MAGIC Google Colab. No GPU and no AWS credentials needed - Fairlearn and SHAP run
# MAGIC entirely on the CPU inside this notebook.
# MAGIC
# MAGIC ![Responsible AI workflow: audit, mitigate, explain](https://raw.githubusercontent.com/axel-sirota/bread-financial-academy/main/exercises/week_23_ai_governance_ethics/diagrams/responsible_ai_flow.png)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Section 0: Setup and a Baseline Credit Model
# MAGIC
# MAGIC We install a pinned set of libraries, then load the data and train a plain
# MAGIC baseline loan-approval model. That baseline is the thing we will audit. We pin
# MAGIC numpy below 2 so the fairness and explainability tooling installs cleanly.
# MAGIC
# MAGIC Run the install cell FIRST and let it run while we talk through the plan for the
# MAGIC session. Installing four libraries (Fairlearn, SHAP, AIF360, LIME) takes a few
# MAGIC minutes on Colab, so starting it now means it is ready by the time we need it.
# MAGIC The dataset is loaded from a cached copy in the course repo, so it loads in
# MAGIC seconds rather than waiting on an external download.

# COMMAND ----------

# Install the libraries for this notebook. We pin numpy below 2 so the fairness
# and explainability tooling (Fairlearn, SHAP, AIF360, LIME) installs and imports
# cleanly.

!pip install -q \
    "numpy<2" \
    "scikit-learn>=1.4,<1.7" \
    "fairlearn>=0.12" \
    "shap>=0.46" \
    "aif360>=0.6" \
    "lime>=0.2" \
    "pandas>=2.0" \
    "matplotlib>=3.7"

# COMMAND ----------

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score

# Confirm we are on numpy below 2.
print("numpy version:", np.__version__)

# Load the census dataset. We reframe it as a Bread Financial loan-approval
# problem: target = 1 means "approve" (the person earns >50K, a proxy for
# creditworthiness), target = 0 means "deny". The dataset carries protected
# attributes (sex, race) that a fairness audit needs.
#
# We load a cached copy from the course repo first (fast and reliable in class);
# if that is unavailable we fall back to fetching from OpenML via Fairlearn.
CACHE_URL = ("https://raw.githubusercontent.com/axel-sirota/"
             "bread-financial-academy/main/exercises/"
             "week_23_ai_governance_ethics/data/adult.csv")
try:
    full = pd.read_csv(CACHE_URL)
    X_raw = full.drop(columns=["__target__"]).copy()
    y = (full["__target__"] == ">50K").astype(int)
    print("Loaded cached Adult dataset:", len(X_raw), "rows.")
except Exception as e:
    print("Cache load failed, fetching from OpenML instead:", e)
    from fairlearn.datasets import fetch_adult
    data = fetch_adult(as_frame=True)
    X_raw = data.data.copy()
    y = (data.target == ">50K").astype(int)

# The protected attribute we audit on. ECOA names sex as a protected class.
sensitive = X_raw["sex"]

# Pick a small, readable set of features for a fast, interpretable model.
numeric_features = ["age", "hours-per-week", "education-num"]
categorical_features = ["workclass", "marital-status", "occupation"]
model_features = numeric_features + categorical_features

# One preprocessing + model pipeline so the demo stays simple.
preprocess = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numeric_features),
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
    ]
)
credit_model = Pipeline(
    steps=[
        ("prep", preprocess),
        ("clf", LogisticRegression(max_iter=1000)),
    ]
)

# Train/test split, keeping the sensitive feature aligned with each split.
X_train, X_test, y_train, y_test, sens_train, sens_test = train_test_split(
    X_raw[model_features], y, sensitive, test_size=0.3, random_state=42
)

credit_model.fit(X_train, y_train)
y_pred = credit_model.predict(X_test)

print("Baseline accuracy:", round(accuracy_score(y_test, y_pred), 3))
print("This model looks fine on accuracy. Next we check if it is FAIR.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Section 1: Auditing a Credit Model for Bias
# MAGIC
# MAGIC Accuracy is a single number for the whole population. It hides the question a
# MAGIC regulator actually cares about: does the model approve some groups more often
# MAGIC than others?
# MAGIC
# MAGIC Two ideas we use today:
# MAGIC
# MAGIC - **Selection rate**: the fraction of people a group that the model approves. If
# MAGIC   the model approves 30 percent of men but only 12 percent of women, that gap is
# MAGIC   a red flag.
# MAGIC - **Demographic parity difference**: the gap between the highest and lowest
# MAGIC   selection rate across groups. A value near 0 means groups are approved at
# MAGIC   similar rates; a large value means disparate impact.
# MAGIC
# MAGIC Fairlearn gives us `MetricFrame`, which computes any metric SEPARATELY for each
# MAGIC group, and helper functions like `demographic_parity_difference` that summarize
# MAGIC the gap in one number.
# MAGIC
# MAGIC ```python
# MAGIC from fairlearn.metrics import MetricFrame, selection_rate
# MAGIC from fairlearn.metrics import demographic_parity_difference
# MAGIC ```
# MAGIC
# MAGIC ![Fairlearn MetricFrame: per-group metrics and the parity gap](https://raw.githubusercontent.com/axel-sirota/bread-financial-academy/main/exercises/week_23_ai_governance_ethics/diagrams/fairness_metricframe.png)

# COMMAND ----------

# DEMO: measure fairness, not just accuracy.
from fairlearn.metrics import MetricFrame, selection_rate
from fairlearn.metrics import demographic_parity_difference

# MetricFrame computes each metric separately for each value of the sensitive
# feature. Here: accuracy and selection rate, split by sex.
frame = MetricFrame(
    metrics={"accuracy": accuracy_score, "selection_rate": selection_rate},
    y_true=y_test,
    y_pred=y_pred,
    sensitive_features=sens_test,
)

print("Per-group metrics (baseline model):")
print(frame.by_group)

# The selection rate gap, summarized to one number. 0 = perfect parity.
dpd = demographic_parity_difference(
    y_test, y_pred, sensitive_features=sens_test
)
print("\nDemographic parity difference (baseline):", round(dpd, 3))
print("A large gap means the model approves one group far more than the other.")

# A quick bar chart of selection rate per group makes the disparity visible.
frame.by_group["selection_rate"].plot.bar(
    title="Approval (selection) rate by sex - baseline model",
    ylabel="selection rate",
    rot=0,
)
plt.tight_layout()
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Think About It
# MAGIC
# MAGIC The baseline model approves one group at a noticeably higher rate than the
# MAGIC other, even though its overall accuracy looked fine.
# MAGIC
# MAGIC - If you only ever reported overall accuracy to leadership, would anyone have
# MAGIC   caught this? What does that say about the metrics we put on a model card?
# MAGIC - Demographic parity asks for equal approval rates. But what if one group is
# MAGIC   genuinely more creditworthy on average in the data? Is forcing equal approval
# MAGIC   always the right call, or can it create its own problems?
# MAGIC
# MAGIC No need to write anything down. Hold these questions as we mitigate the gap next.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 1: Mitigate Bias with ThresholdOptimizer (about 15 minutes)
# MAGIC
# MAGIC You measured the disparity. Now reduce it. Fairlearn's `ThresholdOptimizer`
# MAGIC wraps your already-trained model and picks group-specific decision thresholds so
# MAGIC that a fairness constraint is satisfied, without retraining the underlying model.
# MAGIC
# MAGIC **Your task:** write one function, `mitigate_bias`, and call it.
# MAGIC
# MAGIC ```python
# MAGIC def mitigate_bias(model, constraint):
# MAGIC     # returns (mitigated_predictions_on_test, demographic_parity_difference)
# MAGIC     ...
# MAGIC ```
# MAGIC
# MAGIC It should wrap the already-fitted `model` in a `ThresholdOptimizer` using the
# MAGIC given fairness `constraint`, fit it on the training data, predict on the test
# MAGIC data, and return both the mitigated test predictions and their demographic parity
# MAGIC difference. Then call it with `credit_model` and `"demographic_parity"`, store
# MAGIC the results in `mitigated_pred` and `mitigated_dpd`, and print the gap.
# MAGIC
# MAGIC You decide the steps inside the function. Think about what `ThresholdOptimizer`
# MAGIC needs that an ordinary sklearn model does not.
# MAGIC
# MAGIC **Expected outcome:** `mitigated_dpd` is much smaller than the baseline gap from
# MAGIC the demo.
# MAGIC
# MAGIC **Hints:**
# MAGIC - `ThresholdOptimizer` needs to know the model is already trained, and it needs
# MAGIC   the sensitive feature at BOTH fit time and predict time. That second point is a
# MAGIC   real governance fact worth pausing on.
# MAGIC - `demographic_parity_difference` is the same helper from the demo.
# MAGIC - The training and test sensitive features are `sens_train` and `sens_test`.
# MAGIC
# MAGIC ### Stretch goal (fast finishers)
# MAGIC
# MAGIC Your function already takes a `constraint` argument, so call it a second time with
# MAGIC `"equalized_odds"` and compare. Demographic parity equalizes approval RATES;
# MAGIC equalized odds equalizes error rates (true and false positive rates) across
# MAGIC groups. Which constraint changed the predictions more?
# MAGIC
# MAGIC ### Homework Extension
# MAGIC
# MAGIC Add a third return value to `mitigate_bias`: the accuracy of the mitigated model.
# MAGIC Mitigation usually costs a little accuracy. Quantify that cost here and write two
# MAGIC sentences on whether the tradeoff is acceptable for a lending decision and who
# MAGIC should make that call.

# COMMAND ----------

# Lab 1 SOLUTION: one function that mitigates and measures, then a call.
from fairlearn.postprocessing import ThresholdOptimizer
from fairlearn.metrics import demographic_parity_difference


def mitigate_bias(model, constraint):
    """Return (fitted_optimizer, mitigated_test_predictions, parity_gap).

    ThresholdOptimizer wraps an ALREADY-fitted model (prefit=True) and learns one
    decision threshold per group. It needs the sensitive feature at fit time (to
    learn the thresholds) AND at predict time (to apply the right one) - a real
    governance point: the protected attribute must be available when the decision
    is made.
    """
    optimizer = ThresholdOptimizer(
        estimator=model, constraints=constraint, prefit=True,
    )
    optimizer.fit(X_train, y_train, sensitive_features=sens_train)
    preds = optimizer.predict(X_test, sensitive_features=sens_test)
    gap = demographic_parity_difference(
        y_test, preds, sensitive_features=sens_test
    )
    return optimizer, preds, gap


# Call it on the baseline model with the demographic parity constraint.
mitigator, mitigated_pred, mitigated_dpd = mitigate_bias(
    credit_model, "demographic_parity"
)

print("Mitigated demographic parity difference:", round(mitigated_dpd, 3))
print("This should be much closer to 0 than the baseline gap.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Section 2: Explaining Decisions with SHAP
# MAGIC
# MAGIC A fair model still has to explain itself. When Bread Financial denies a loan,
# MAGIC ECOA requires a written adverse-action notice listing the main reasons for the
# MAGIC denial. "The model said no" is not a legal reason. We need the specific factors
# MAGIC that drove THIS applicant's decision.
# MAGIC
# MAGIC SHAP (SHapley Additive exPlanations) assigns each feature a contribution value
# MAGIC for a single prediction: how much did `age`, `hours-per-week`, `education-num`,
# MAGIC and the rest each push the decision toward approve or deny, starting from the
# MAGIC average applicant.
# MAGIC
# MAGIC Two views:
# MAGIC - **Global**: across everyone, which features matter most to the model overall.
# MAGIC - **Local**: for one applicant, exactly which features drove their decision.
# MAGIC   This local view is what an adverse-action notice is built from.
# MAGIC
# MAGIC Because our credit model is a linear logistic model, SHAP can compute exact
# MAGIC contributions quickly with `shap.LinearExplainer`.
# MAGIC
# MAGIC ```python
# MAGIC import shap
# MAGIC explainer = shap.LinearExplainer(model, background_data)
# MAGIC ```
# MAGIC
# MAGIC ![SHAP: global and local explanations for a decision](https://raw.githubusercontent.com/axel-sirota/bread-financial-academy/main/exercises/week_23_ai_governance_ethics/diagrams/shap_flow.png)

# COMMAND ----------

# DEMO: explain the model globally with SHAP.
import shap

# SHAP works on numeric arrays, so we transform the data through the fitted
# preprocessing step and explain the LogisticRegression at the end of the
# pipeline. The transformed training data is the "background" SHAP compares to.
prep = credit_model.named_steps["prep"]
clf = credit_model.named_steps["clf"]

X_train_enc = prep.transform(X_train)
X_test_enc = prep.transform(X_test)

# LinearExplainer gives exact SHAP values for a linear model, fast.
# .toarray() handles the sparse output of the one-hot encoder.
explainer = shap.LinearExplainer(clf, X_train_enc.toarray())
shap_values = explainer(X_test_enc.toarray())

# Readable feature names from the preprocessing step (numeric + one-hot columns).
feature_names = prep.get_feature_names_out()
shap_values.feature_names = list(feature_names)

# Global view: which features matter most across all test applicants.
shap.plots.bar(shap_values, max_display=10)
print("These are the features that drive approvals and denials overall.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Think About It
# MAGIC
# MAGIC Look at the global SHAP bar chart.
# MAGIC
# MAGIC - Suppose one of the top drivers were a feature that correlates strongly with a
# MAGIC   protected attribute (for example, occupation correlating with sex). The model
# MAGIC   never sees sex directly, yet it could still produce a disparate outcome. How
# MAGIC   would your fairness audit from Section 1 catch this, when looking at the model
# MAGIC   internals alone would not?
# MAGIC - An adverse-action notice has to be understandable to the applicant, not just
# MAGIC   to a data scientist. How would you translate a SHAP value into a sentence a
# MAGIC   customer would accept as a reason?
# MAGIC
# MAGIC Hold these as you build a single-applicant explanation in the next lab.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 2: Explain a Denied Application (about 15 minutes)
# MAGIC
# MAGIC A specific applicant was denied. Produce the per-applicant explanation that an
# MAGIC adverse-action notice is built from.
# MAGIC
# MAGIC **Your task:** write one function, `explain_denial`, then use it.
# MAGIC
# MAGIC ```python
# MAGIC def explain_denial(position):
# MAGIC     # show the waterfall plot for the applicant at `position`
# MAGIC     # return their top-3 denial-driving feature names
# MAGIC     ...
# MAGIC ```
# MAGIC
# MAGIC Given a test-set `position`, it should display that applicant's SHAP waterfall
# MAGIC plot and return the three features that pushed them most toward denial (the "main
# MAGIC reasons" an adverse-action notice lists). Then find any applicant the model
# MAGIC denied, call `explain_denial` on them, and store the result in `top_factors`.
# MAGIC
# MAGIC You decide how to turn one applicant's SHAP values into a ranked list of reasons.
# MAGIC
# MAGIC **Expected outcome:** a waterfall plot and a printed list of the top denial
# MAGIC factors for one denied applicant.
# MAGIC
# MAGIC **Hints:**
# MAGIC - `shap_values` for the whole test set was built in the demo; `shap_values[i]` is
# MAGIC   one applicant, and `shap.plots.waterfall` takes exactly that.
# MAGIC - A NEGATIVE SHAP value pushes the prediction DOWN (toward deny). Sorting by the
# MAGIC   raw values puts the strongest deny-drivers first.
# MAGIC - `shap_values.feature_names` lines up with the values; `np.where(y_pred == 0)`
# MAGIC   finds denied applicants.
# MAGIC
# MAGIC ### Stretch goal (fast finishers)
# MAGIC
# MAGIC Your function takes a `position`, so call it on one APPROVED applicant and one
# MAGIC DENIED applicant and compare their top features. Which features flipped the
# MAGIC outcome? A contrastive explanation ("approved because X, denied because Y") is
# MAGIC often clearer to a customer than a single plot.
# MAGIC
# MAGIC ### Homework Extension
# MAGIC
# MAGIC Write the actual adverse-action notice. Using the top factors your function
# MAGIC returned, draft a 3 to 4 sentence plain-English letter to the applicant that
# MAGIC states the main reasons for the decision, the way ECOA requires. Avoid jargon: a
# MAGIC customer should understand it without knowing what a SHAP value is.

# COMMAND ----------

# Lab 2 SOLUTION: one function that explains a single applicant, then a call.
import numpy as np


def explain_denial(position):
    """Show the SHAP waterfall for one applicant; return their top-3 deny reasons.

    shap_values[position] is a single explanation object the waterfall plot
    understands. A negative SHAP value pushes the prediction toward deny, so
    sorting the contributions ascending puts the strongest deny-drivers first.
    """
    shap.plots.waterfall(shap_values[position], max_display=10)
    contributions = shap_values[position].values
    names = shap_values.feature_names
    order = np.argsort(contributions)  # most negative (toward deny) first
    return [names[j] for j in order[:3]]


# First test-set position the baseline model denied, then explain it.
denied_idx = int(np.where(y_pred == 0)[0][0])
top_factors = explain_denial(denied_idx)

print("Applicant index:", denied_idx)
print("Top denial factors (the 'main reasons' for an adverse-action notice):")
for f in top_factors:
    print(" -", f)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Section 3: A Second Opinion, then Governance
# MAGIC
# MAGIC This section does two things. First, a SECOND opinion: the outline names IBM's AI
# MAGIC Fairness 360 (AIF360) and LIME, and there is a real reason to know more than one
# MAGIC tool. Fairness metrics and local explanations are concepts, not library features.
# MAGIC When two independent tools agree, you can put a reason in an adverse-action notice
# MAGIC with more confidence; when they disagree, that is a signal to look closer.
# MAGIC
# MAGIC Then the part that makes this an AI GOVERNANCE week, not just a fairness week: we
# MAGIC turn all of today's numbers into a documented, signed governance artifact, a
# MAGIC model card. Metrics in a notebook are not governance. Governance is the paper
# MAGIC trail an auditor or regulator can pull: what the model is for, how it was tested,
# MAGIC who is accountable, and what a human must check before a decision goes out. You
# MAGIC build that artifact in Lab 3.
# MAGIC
# MAGIC We reuse the SAME credit model and the SAME denied applicant:
# MAGIC
# MAGIC - **AIF360** measures the same disparity as Fairlearn, under different names:
# MAGIC   `disparate_impact` is the RATIO of approval rates (the US four-fifths rule
# MAGIC   flags anything below 0.8), and `statistical_parity_difference` is the signed
# MAGIC   gap, the same idea as Fairlearn's `demographic_parity_difference`.
# MAGIC - **LIME** explains the same denied applicant as SHAP, with different math: it
# MAGIC   perturbs the applicant's features and fits a simple local model to see what
# MAGIC   drove the decision.
# MAGIC
# MAGIC ![AIF360: BinaryLabelDataset metrics](https://raw.githubusercontent.com/axel-sirota/bread-financial-academy/main/exercises/week_23_ai_governance_ethics/diagrams/aif360_flow.png)
# MAGIC
# MAGIC ![LIME vs SHAP local explanations](https://raw.githubusercontent.com/axel-sirota/bread-financial-academy/main/exercises/week_23_ai_governance_ethics/diagrams/lime_flow.png)

# COMMAND ----------

# DEMO: a second opinion. Same model, same denied applicant, different tools.
from aif360.datasets import BinaryLabelDataset
from aif360.metrics import BinaryLabelDatasetMetric
from lime.lime_tabular import LimeTabularExplainer

# --- AIF360: the same disparity Fairlearn reported, under different names ---
# AIF360 wants one dataframe with numeric features, the label, and a numeric
# protected attribute. Encode sex as 1 = Male (privileged), 0 = Female.
df = pd.get_dummies(X_test[model_features], columns=categorical_features)
df["label"] = y_test.values
df["sex_code"] = (sens_test.values == "Male").astype(int)

privileged = [{"sex_code": 1}]
unprivileged = [{"sex_code": 0}]

bld = BinaryLabelDataset(
    df=df, label_names=["label"], protected_attribute_names=["sex_code"],
    favorable_label=1, unfavorable_label=0,
)
metric = BinaryLabelDatasetMetric(
    bld, privileged_groups=privileged, unprivileged_groups=unprivileged
)
di_baseline = metric.disparate_impact()
print("AIF360 disparate_impact, baseline (ratio, flag if < 0.8):",
      round(di_baseline, 3))
print("AIF360 statistical_parity_difference (same idea as Fairlearn DPD):",
      round(metric.statistical_parity_difference(), 3))

# Confirm the Lab 1 mitigation with this second tool: disparate impact on the
# MITIGATED predictions should move toward 1.0 (perfect parity).
df_mit = df.copy()
df_mit["label"] = mitigated_pred
bld_mit = BinaryLabelDataset(
    df=df_mit, label_names=["label"], protected_attribute_names=["sex_code"],
    favorable_label=1, unfavorable_label=0,
)
di_mitigated = BinaryLabelDatasetMetric(
    bld_mit, privileged_groups=privileged, unprivileged_groups=unprivileged
).disparate_impact()
print("AIF360 disparate_impact, mitigated:", round(di_mitigated, 3),
      "(closer to 1.0 confirms Lab 1 worked, via a second tool)")

# --- LIME: explain the SAME denied applicant we explained with SHAP ---
# LIME, like SHAP, works on the encoded data and wraps the classifier's
# predict_proba. We reuse prep/clf and X_train_enc/X_test_enc from Section 2.
# We down-sample the background to 500 rows: LIME only needs a sample of the
# training distribution, and a smaller background keeps each explanation fast
# (a few seconds instead of minutes on Colab CPU).
bg = X_train_enc.toarray()[:500]
lime_explainer = LimeTabularExplainer(
    training_data=bg,
    feature_names=list(prep.get_feature_names_out()),
    class_names=["deny", "approve"],
    mode="classification",
)
# Re-derive the denied applicant as a guaranteed scalar index, and flatten the
# row to 1-D. LIME's explain_instance needs a single 1-D row; if denied_idx were
# anything other than a plain int (for example left over from a different cell),
# the row could come out 2-D and LIME would raise a broadcast error. ravel() plus
# the assert make this robust no matter what Section 2 left behind.
denied_idx = int(np.where(y_pred == 0)[0][0])
denied_row = np.asarray(X_test_enc.toarray()[denied_idx]).ravel()
assert denied_row.ndim == 1, f"expected a 1-D row, got shape {denied_row.shape}"
lime_exp = lime_explainer.explain_instance(
    data_row=denied_row,
    predict_fn=clf.predict_proba,
    num_features=8,
    num_samples=1000,  # fewer perturbations = faster, still stable for a demo
)
print("\nLIME top factors for the denied applicant (feature, weight):")
for feat, weight in lime_exp.as_list()[:5]:
    print(f"  {feat}: {round(weight, 4)}")
print("\nCompare these to the SHAP factors from Lab 2. Where they agree, the "
      "reason is strong; where they disagree, investigate before writing it down.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Think About It
# MAGIC
# MAGIC You just measured the same disparity and explained the same applicant with two
# MAGIC independent tools.
# MAGIC
# MAGIC - AIF360 made you encode sex as a 1/0 privileged/unprivileged variable. Who
# MAGIC   decides which group is "privileged", and could that labeling choice itself
# MAGIC   carry a value judgment?
# MAGIC - If LIME and SHAP named different top factors for the same denial, which one
# MAGIC   would you put in the adverse-action notice, and how would you decide?
# MAGIC
# MAGIC Hold these as you confirm the mitigation worked in the last lab.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab 3: Write a Model Card - Turning Metrics into Governance (about 10 minutes)
# MAGIC
# MAGIC Fairness metrics and explanations are not governance by themselves. Governance is
# MAGIC the paper trail: a documented, signed record of what the model is, how it was
# MAGIC tested for fairness, who is accountable, and what a human reviewer must check
# MAGIC before it goes live. The industry-standard artifact for this is a MODEL CARD.
# MAGIC
# MAGIC You have already produced every number a model card needs today: the baseline and
# MAGIC mitigated demographic parity difference (Fairlearn), the baseline and mitigated
# MAGIC disparate impact (AIF360), and a per-applicant explanation (SHAP and LIME). Now
# MAGIC package them into a governance artifact and save it to disk, the way a real
# MAGIC responsible-AI workflow logs evidence for an audit.
# MAGIC
# MAGIC **Your task:** write two functions, then use them.
# MAGIC
# MAGIC ```python
# MAGIC def build_model_card():
# MAGIC     # return a dict recording what this model is and how it was governed
# MAGIC     ...
# MAGIC
# MAGIC def save_card(card, path):
# MAGIC     # write the card to disk as JSON, creating the folder if needed
# MAGIC     ...
# MAGIC ```
# MAGIC
# MAGIC `build_model_card` decides WHAT an auditor needs in one place: at minimum the
# MAGIC model name and intended use, the protected attribute audited, the fairness numbers
# MAGIC you computed today (`dpd`, `mitigated_dpd` from Fairlearn and `di_baseline`,
# MAGIC `di_mitigated` from AIF360), the mitigation method, the explainability methods, a
# MAGIC named accountable owner, and the human-oversight rule (every denial gets an
# MAGIC adverse-action notice). `save_card` persists it. Then call them, storing the dict
# MAGIC in `model_card`, and print it.
# MAGIC
# MAGIC You decide the card's structure. A governance artifact is a judgment call about
# MAGIC what evidence matters, not a fixed template.
# MAGIC
# MAGIC **Expected outcome:** a JSON model card on disk that any auditor could read to see,
# MAGIC in one place, what the model is and how it was governed.
# MAGIC
# MAGIC **Hints:**
# MAGIC - The numbers are already in memory: `dpd`, `mitigated_dpd`, `di_baseline`,
# MAGIC   `di_mitigated`.
# MAGIC - `os.makedirs(folder, exist_ok=True)` before writing; `json.dump(card, f, indent=2)`.
# MAGIC
# MAGIC ### Stretch goal (fast finishers)
# MAGIC
# MAGIC Add a `limitations` field noting that demographic parity was enforced on sex
# MAGIC only, so the card does not overclaim fairness on race or intersectional groups,
# MAGIC and a `human_oversight` field naming WHO signs off (for example a risk officer).
# MAGIC Honest limitations are a governance requirement, not an afterthought.
# MAGIC
# MAGIC ### Homework Extension
# MAGIC
# MAGIC Extend the model card into a one-page markdown document with these governance
# MAGIC sections a regulator expects: intended use and out-of-scope use, training-data
# MAGIC provenance and consent, the fairness results you computed, the mitigation and its
# MAGIC accuracy cost, the human-in-the-loop review step, and a monitoring plan (how you
# MAGIC would detect the model drifting back into bias after deployment).

# COMMAND ----------

# Lab 3 SOLUTION: two functions that turn today's metrics into a governance card.
import json, os


def build_model_card():
    """Return the dict an auditor needs in one place.

    The AIF360 numbers (di_baseline, di_mitigated) come from the Section 3 demo.
    If AIF360 did not install or run, fall back to None so the artifact still
    records the Fairlearn numbers. A card of what you DID measure beats no card.
    (We check globals(), not dir(): inside a function dir() lists locals only.)
    """
    di_b = round(float(di_baseline), 4) if "di_baseline" in globals() else None
    di_m = round(float(di_mitigated), 4) if "di_mitigated" in globals() else None
    return {
        "model_name": "Bread Financial loan-approval (Week 23 demo)",
        "intended_use": "Approve or deny a loan application from applicant features",
        "out_of_scope_use": "Not for pricing, collections, or any non-lending decision",
        "protected_attribute_audited": "sex",
        "fairness": {
            "demographic_parity_difference_baseline": round(float(dpd), 4),
            "demographic_parity_difference_mitigated": round(float(mitigated_dpd), 4),
            "disparate_impact_baseline": di_b,
            "disparate_impact_mitigated": di_m,
        },
        "mitigation": "Fairlearn ThresholdOptimizer with demographic_parity constraint",
        "explainability": ["SHAP LinearExplainer (global + local)", "LIME (local)"],
        "accountable_owner": "Model Risk team (named individual in production)",
        "human_oversight": "Every denial issues an ECOA adverse-action notice listing "
                           "the principal reasons from the local explanation",
        "limitations": "Demographic parity enforced on sex only; race and "
                       "intersectional fairness not yet audited",
    }


def save_card(card, path):
    """Persist the card as a governance artifact an audit could pull."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(card, fh, indent=2)


model_card = build_model_card()
save_card(model_card, "artifacts/week23_model_card.json")

print(json.dumps(model_card, indent=2))
print("\nModel card saved to artifacts/week23_model_card.json - this is the "
      "governance evidence an auditor or regulator would ask to see.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Wrap-up: Responsible AI in One Workflow
# MAGIC
# MAGIC Today you wrapped a responsible-AI layer around a model like the ones you have
# MAGIC built all program:
# MAGIC
# MAGIC 1. **Audit** - `MetricFrame` and `demographic_parity_difference` revealed that an
# MAGIC    accurate model can still approve one group far more than another.
# MAGIC 2. **Mitigate** - `ThresholdOptimizer` shrank that gap, and your homework
# MAGIC    measures what it cost in accuracy (the fairness-accuracy tradeoff is a
# MAGIC    business decision, not a purely technical one).
# MAGIC 3. **Explain** - SHAP turned a single denial into a specific, per-applicant list
# MAGIC    of reasons, which is exactly what an ECOA adverse-action notice requires.
# MAGIC 4. **Confirm with a second opinion** - AIF360 measured the same disparity under
# MAGIC    different names, and LIME explained the same applicant with different math.
# MAGIC    Two tools agreeing is stronger evidence than one.
# MAGIC 5. **Govern** - you packaged every number into a model card and saved it as a
# MAGIC    governance artifact. Metrics in a notebook are not governance; a documented,
# MAGIC    accountable, signed record is.
# MAGIC
# MAGIC ### Where this meets regulation
# MAGIC
# MAGIC - **ECOA (US lending)**: every credit denial needs the specific principal reasons.
# MAGIC   Your SHAP or LIME local explanation is the engine behind that notice.
# MAGIC - **GDPR (EU)**: the right to explanation for automated decisions. Same tooling.
# MAGIC - **EU AI Act**: credit scoring is classified as a high-risk use of AI, which
# MAGIC   brings documentation, fairness, and transparency obligations. The audit and
# MAGIC   explanation you ran today are the kind of evidence those obligations expect.
# MAGIC
# MAGIC ### Homework
# MAGIC
# MAGIC 1. **Fairness-accuracy tradeoff (from Lab 1)**: compute the mitigated model's
# MAGIC    accuracy, compare to baseline, and write two sentences on whether the tradeoff
# MAGIC    is acceptable for lending and who should sign off on it.
# MAGIC 2. **Adverse-action notice (from Lab 2)**: draft the plain-English denial letter
# MAGIC    from your top SHAP factors.
# MAGIC 3. **Full model card (from Lab 3)**: extend your saved model card into a
# MAGIC    one-page markdown document with the governance sections a regulator expects:
# MAGIC    intended and out-of-scope use, training-data provenance and consent, the
# MAGIC    fairness results, the mitigation and its accuracy cost, the human-in-the-loop
# MAGIC    review step, and a monitoring plan for detecting drift back into bias.
# MAGIC
# MAGIC ### Looking Ahead to Week 24 (Capstone)
# MAGIC
# MAGIC In the capstone you bring together everything from the program. Add a
# MAGIC responsible-AI checklist to your capstone model: run a fairness audit, mitigate
# MAGIC if you find disparate impact, and be ready to explain any single prediction to a
# MAGIC stakeholder. A model that cannot be audited or explained is not finished.